import SwiftUI

// MARK: - Accessibility Settings for iOS 17+
// Modern accessibility configuration using SwiftUI environment values
// Thread-safe with @MainActor for Swift 6 strict concurrency

@MainActor @Observable
class AccessibilitySettings {
    // Voice narration
    var voiceNarrationEnabled: Bool = true
    
    // Text size
    var largeText: Bool = false
    var textSizeMultiplier: CGFloat = 1.0
    
    // Visual
    var highContrastMode: Bool = false
    var reduceMotion: Bool = false
    
    // Haptics
    var hapticsEnabled: Bool = true
    var hapticsIntensity: HapticIntensity = .medium
    
    // Animation
    var animationSpeed: AnimationSpeed = .normal
}

enum HapticIntensity: String, CaseIterable {
    case light = "Light"
    case medium = "Medium"
    case strong = "Strong"
    case off = "Off"
}

enum AnimationSpeed: String, CaseIterable {
    case slow = "Slow"
    case normal = "Normal"
    case fast = "Fast"
    
    var multiplier: Double {
        switch self {
        case .slow:
            return 1.5
        case .normal:
            return 1.0
        case .fast:
            return 0.7
        }
    }
}
