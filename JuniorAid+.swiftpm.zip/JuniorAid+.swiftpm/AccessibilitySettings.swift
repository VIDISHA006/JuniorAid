import SwiftUI





@MainActor @Observable
class AccessibilitySettings {
    
    var voiceNarrationEnabled: Bool = true
    
    
    var largeText: Bool = false
    var textSizeMultiplier: CGFloat = 1.0
    
    
    var highContrastMode: Bool = false
    var reduceMotion: Bool = false
    
    
    var hapticsEnabled: Bool = true
    var hapticsIntensity: HapticIntensity = .medium
    
    
    var animationSpeed: AnimationSpeed = .normal
}

enum HapticIntensity: String, CaseIterable {
    case light = "Light"
    case medium = "Medium"
    case strong = "Strong"
    case off = "Off"
}

enum AnimationSpeed: String, CaseIterable {
    case slow = "Slow"
    case normal = "Normal"
    case fast = "Fast"
    
    var multiplier: Double {
        switch self {
        case .slow:
            return 1.5
        case .normal:
            return 1.0
        case .fast:
            return 0.7
        }
    }
}
