import SwiftUI

// MARK: - Action-Based Scenario Content
// NO "What should you do?" - Pure action learning

@MainActor
struct ActionScenarioContent {
    static let shared = ActionScenarioContent()
    
    private init() {}
    
    var allScenarios: [ActionScenario] {
        [
            bleedingScenario,
            burnsScenario,
            chokingScenario,
            fireEscapeScenario,
            nosebleedScenario,
            beeStingScenario,
            brokenBoneScenario,
            dogBiteScenario
        ]
    }
    
    // MARK: - Bleeding Scenario
    let bleedingScenario = ActionScenario(
            title: "Bleeding",
            icon: "bandage.fill",
            color: JuniorAidColors.peachMist,
            description: "Learn how to help someone who is bleeding",
            steps: [
                ActionStep(
                    title: "Find Cloth",
                    instruction: "Tap the clean cloth to pick it up",
                    gestureType: .tap,
                    visualCue: "", // Invisible tap area
                    coachGuidance: "Tap the cloth to use it",
                    successEffect: SceneEffect(
                        characterState: .concerned,
                        environmentTone: .alert,
                        colorShift: .neutral,
                        message: "Good! You have a clean cloth."
                    ),
                    voiceNarration: "First, find something clean like a cloth or bandage.",
                    animation: .cleanCloth
                ),
                ActionStep(
                    title: "Apply Pressure",
                    instruction: "Press firmly on the wound",
                    gestureType: .dragAndHold(item: "clean_cloth_tool", duration: 5),
                    visualCue: "hand.point.down.fill",
                    coachGuidance: "Drag the cloth to the wound and hold",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Keep pressing! value pressure stops bleeding."
                    ),
                    voiceNarration: "Put the cloth on the cut and press down hard. Don't let go!",
                    animation: .bleedingHandPress
                ),
                ActionStep(
                    title: "Clean & Call",
                    instruction: "Clean the cut and call an adult",
                    gestureType: .tap,
                    visualCue: "", 
                    coachGuidance: "Tap to clean and call",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Excellent! You followed all steps."
                    ),
                    voiceNarration: "Now that the bleeding stopped, clean the cut and call a grown-up to help.",
                    animation: .cleanCutHand
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Press gently and call for help",
                icon: "bandage.fill",
                scenarioName: "Bleeding"
            )
        )

    
    // MARK: - Burns Scenario
    let burnsScenario = ActionScenario(
            title: "Burns",
            icon: "flame.fill",
            color: JuniorAidColors.peachMist,
            description: "Learn how to treat a burn injury",
            steps: [
                ActionStep(
                    title: "Cool the Burn",
                    instruction: "Run water for 5-10 min on the burnt area",
                    gestureType: .dragAndHold(item: "water_droplet", duration: 5), // Simulated 5s hold
                    visualCue: "drop.fill",
                    coachGuidance: "Drag water to the burn and hold",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .cooler,
                        message: "Good! Cool water helps soothe the burn."
                    ),
                    voiceNarration: "Run cool water over the burn for 5 to 10 minutes straight.",
                    animation: .burnCooling
                ),
                ActionStep(
                    title: "Cover Burn",
                    instruction: "Tap the cloth to cover",
                    gestureType: .dragAndHold(item: "clean_cloth_tool", duration: 0), // Drag then Tap logic handles 0 duration special case
                    visualCue: "bandage.fill",
                    coachGuidance: "Tap cloth to wrap",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Perfect! Covering helps keep it clean."
                    ),
                    voiceNarration: "Tap the clean cloth to gently wrap the burn.",
                    animation: .waterHandBurn
                ),
                ActionStep(
                    title: "Call Adult",
                    instruction: "Call an adult as soon as possible",
                    gestureType: .tap,
                    visualCue: "", // No icon as requested
                    coachGuidance: "Call for help now",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Excellent! You stayed calm and helped."
                    ),
                    voiceNarration: "Call an adult as soon as possible.",
                    animation: .handClothWrapped
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Cool water for 10 minutes",
                icon: "drop.fill",
                scenarioName: "Burns"
            )
        )


    
    // MARK: - Choking Scenario
    let chokingScenario = ActionScenario(
            title: "Choking",
            icon: "exclamationmark.triangle.fill",
            color: JuniorAidColors.lavenderHaze,
            description: "Learn how to help someone who is choking",
            steps: [
                ActionStep(
                    title: "Lean Forward",
                    instruction: "Lean them forward",
                    gestureType: .swipePath(direction: .down),
                    visualCue: "arrow.down",
                    coachGuidance: "Swipe down to lean them forward",
                    successEffect: SceneEffect(
                        characterState: .concerned,
                        environmentTone: .alert,
                        colorShift: .neutral,
                        message: "Good. Gravity helps clear the blockage."
                    ),
                    voiceNarration: "If someone is choking, first lean them forward.",
                    animation: .kneeling
                ),
                ActionStep(
                    title: "The Back Pat",
                    instruction: "Pat hard 5 times on the back",
                    gestureType: .rhythmTap(count: 5, bpm: 80),
                    visualCue: "hand.tap.fill",
                    coachGuidance: "Pat hard between the shoulder blades",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Good strong taps!"
                    ),
                    voiceNarration: "Now give 5 sharp back blows. Hit hard between the shoulder blades.",
                    animation: .backBlows
                ),
                ActionStep(
                    title: "Check Breathing",
                    instruction: "Check if they can breathe",
                    gestureType: .tap,
                    visualCue: "wind",
                    coachGuidance: "Tap to check breathing",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "They're breathing! You did it!"
                    ),
                    voiceNarration: "Check if the object came out and they can breathe.",
                    animation: .stabilizing
                ),
                ActionStep(
                    title: "Call for Help",
                    instruction: "Call for help",
                    gestureType: .tap,
                    visualCue: "", // Removed visual cue to avoid double animation
                    coachGuidance: "Always call after choking",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Perfect! Help is coming."
                    ),
                    voiceNarration: "Even if they seem okay, always call for help to be safe.",
                    animation: .phoneCall
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Lean forward and tap back",
                icon: "hand.tap.fill",
                scenarioName: "Choking"
            )
        )

    
    // MARK: - Fire Escape Scenario
    let fireEscapeScenario = ActionScenario(
            title: "Fire Escape",
            icon: "flame.fill",
            color: JuniorAidColors.peachMist,
            description: "Learn how to escape safely from a fire",
            steps: [
                ActionStep(
                    title: "Stay Low",
                    instruction: "Swipe down to stay low",
                    gestureType: .swipePath(direction: .down),
                    visualCue: "figure.crawl",
                    coachGuidance: "Smoke rises! Stay down low.",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .neutral,
                        colorShift: .neutral,
                        message: "Good! You're below the smoke."
                    ),
                    voiceNarration: "There's smoke! Swipe down to get low.",
                    animation: .fireRoom1
                ),
                ActionStep(
                    title: "Crawl to Exit",
                    instruction: "Crawl to the nearest exit",
                    gestureType: .tap, // Or drag? User didn't specify interaction for step 2, sticking to tap/simple for now or maybe keep prior logic if it was distinct
                    visualCue: "door.left.hand.open",
                    coachGuidance: "Keep crawling to the door",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "You found the way out!"
                    ),
                    voiceNarration: "Crawl fast to the exit.",
                    animation: .fireRoom2
                ),
                ActionStep(
                    title: "Get Safe",
                    instruction: "Get outside and call for help",
                    gestureType: .tap,
                    visualCue: "", // Removed to avoid double animation with .phoneCall
                    coachGuidance: "Once outside, call emergency",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "You're safe! Firefighters are coming."
                    ),
                    voiceNarration: "Once you're outside and safe, call for help.",
                    animation: .phoneCall
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Stay low and crawl out",
                icon: "flame.fill",
                scenarioName: "Fire Escape"
            )
        )

    
    // MARK: - Nosebleed Scenario
    let nosebleedScenario = ActionScenario(
            title: "Nosebleed Hero",
            icon: "drop.fill",
            color: JuniorAidColors.medical,
            description: "Learn how to stop a nosebleed",
            steps: [
                ActionStep(
                    title: "Lean Forward",
                    instruction: "Lean head forward (not back!)",
                    gestureType: .swipePath(direction: .down),
                    visualCue: "arrow.down.circle.fill",
                    coachGuidance: "Swipe down to lean forward",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .neutral,
                        message: "Correct! Leaning forward prevents swallowing blood."
                    ),
                    voiceNarration: "If your nose is bleeding, lean your head forward slightly. Never lean back.",
                    animation: .leaningForward
                ),
                ActionStep(
                    title: "Pinch Nose",
                    instruction: "Hold the soft part of nose",
                    gestureType: .pressAndHold(seconds: 5),
                    visualCue: "",
                    coachGuidance: "Hold nose for 5 sec",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Great! Pressure stops the bleeding."
                    ),
                    voiceNarration: "Pinch the soft part of your nose and hold it. Breathe through your mouth.",
                    animation: .pressingNose
                ),
                ActionStep(
                    title: "Wait",
                    instruction: "Wait patiently",
                    gestureType: .tap,
                    visualCue: "", // Removed clock visual
                    coachGuidance: "Tap to finish",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "You did it! The nosebleed stopped."
                    ),
                    voiceNarration: "Stay clear and calm. If it doesn't stop, tell an adult.",
                    animation: .stabilizing
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Lean forward and pinch",
                icon: "drop.fill",
                scenarioName: "Nosebleed"
            )
        )


    // MARK: - Bee Sting Scenario
    let beeStingScenario = ActionScenario(
            title: "Bee Sting",
            icon: "smallcircle.filled.circle.fill",
            color: JuniorAidColors.encouragementYellow,
            description: "Learn how to treat a bee sting",
            steps: [
                ActionStep(
                    title: "Scrape Stinger",
                    instruction: "Swipe right then left to scrape",
                    gestureType: .swipeSequence(directions: [.right, .left]),
                    visualCue: "hand.draw.fill",
                    coachGuidance: "Scrape sideways - first right, then left",
                    successEffect: SceneEffect(
                        characterState: .concerned,
                        environmentTone: .neutral,
                        colorShift: .neutral,
                        message: "Smart! Scraping prevents more venom."
                    ),
                    voiceNarration: "Ouch, a bee sting! Scrape the stinger sideways with a card or fingernail.",
                    animation: .beeSting1
                ),
                ActionStep(
                    title: "Wash",
                    instruction: "Drag water to wash",
                    gestureType: .dragAndHold(item: "drop.fill", duration: 5),
                    visualCue: "drop.fill",
                    coachGuidance: "Drag water to the sting and hold for 5s",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .cooler,
                        message: "Clean and safe."
                    ),
                    voiceNarration: "Wash the sting with soap and water.",
                    animation: .beeSting2
                ),
                ActionStep(
                    title: "Tell Adult",
                    instruction: "Tell a grown-up",
                    gestureType: .tap,
                    visualCue: "", // Removed to avoid double animation
                    coachGuidance: "Tap to tell an adult",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Perfect. You're safe."
                    ),
                    voiceNarration: "Tell a grown-up right away, especially if you feel sick.",
                    animation: .phoneCall
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Scrape stinger and wash",
                icon: "smallcircle.filled.circle.fill",
                scenarioName: "Bee Sting"
            )
        )

    
    // MARK: - Broken Bone Scenario
    let brokenBoneScenario = ActionScenario(
            title: "Broken Bone",
            icon: "bandage.fill",
            color: JuniorAidColors.lavenderHaze,
            description: "What to do step-by-step for a broken bone",
            steps: [
                ActionStep(
                    title: "Don't Move It",
                    instruction: "Don't move the injured part!",
                    gestureType: .pressAndHold(seconds: 5),
                    visualCue: "hand.raised.slash.fill",
                    coachGuidance: "Hold still - keep them safe",
                    successEffect: SceneEffect(
                        characterState: .concerned,
                        environmentTone: .alert,
                        colorShift: .neutral,
                        message: "Good. Moving it can hurt more."
                    ),
                    voiceNarration: "If someone has a broken arm or leg, tell them not to move it.",
                    animation: .stabilizing
                ),
                ActionStep(
                    title: "Call 911",
                    instruction: "Call 911 immediately",
                    gestureType: .tap,
                    visualCue: "", // Removed per user request
                    coachGuidance: "Tap to call for help",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Help is on the way!"
                    ),
                    voiceNarration: "This hurts a lot. Call for emergency help right away.",
                    animation: .phoneCall
                )
            ],
            memoryCard: MemoryCardData(
                keyAction: "Keep still and call 911",
                icon: "bandage.fill",
                scenarioName: "Broken Bone"
            )
        )


    // MARK: - Dog Bite Scenario
    let dogBiteScenario = ActionScenario(
            title: "Dog Bite",
            icon: "pawprint.fill",
            color: JuniorAidColors.dogBitePastel,
            description: "Learn what to do after a dog bite",
            steps: [
                ActionStep(
                    title: "Wash Bite",
                    instruction: "Wash the cut immediately",
                    gestureType: .dragAndHold(item: "water_droplet", duration: 5), // Added timer as requested
                    visualCue: "drop.fill",
                    coachGuidance: "Drag water to wash - hold 5s",
                    successEffect: SceneEffect(
                        characterState: .concerned,
                        environmentTone: .neutral,
                        colorShift: .cooler,
                        message: "Washing helps stop germs."
                    ),
                    voiceNarration: "If a dog bites, wash the cut with soap and water right away.",
                    animation: .dogBiteWash
                ),
                ActionStep(
                    title: "Stop Bleeding",
                    instruction: "Dry the area and stop bleeding",
                    gestureType: .dragAndHold(item: "clean_cloth_tool", duration: 5),
                    visualCue: "bandage.fill",
                    coachGuidance: "Hold the cloth to stop bleeding - hold 5s",
                    successEffect: SceneEffect(
                        characterState: .breathing,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Good job stopping the bleeding."
                    ),
                    voiceNarration: "Use a clean cloth to dry the area and press to stop bleeding.",
                    animation: .dogBiteDry
                ),
                ActionStep(
                    title: "Tell Adult",
                    instruction: "Call an adult for help",
                    gestureType: .tap,
                    visualCue: "", // No visual cue per user request
                    coachGuidance: "Tap to finish",
                    successEffect: SceneEffect(
                        characterState: .relaxed,
                        environmentTone: .calm,
                        colorShift: .warmer,
                        message: "Doctor will help now."
                    ),
                    voiceNarration: "Tell an adult immediately so a doctor can check it.",
                    animation: .dogBiteWrap
                )

            ],
            memoryCard: MemoryCardData(
                keyAction: "Wash and tell adult",
                icon: "pawprint.fill",
                scenarioName: "Dog Bite"
            )
        )

}

#Preview {
    Text("Action Scenarios Created!")
        .onAppear {
            print("Scenarios: \(ActionScenarioContent.shared.allScenarios.count)")
        }
}
