import SwiftUI




struct ActionScenarioListView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    private let scenarios = ActionScenarioContent.shared.allScenarios
    @State private var appeared = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: AppSpacing.xLarge) {
                
                headerView
                    .padding(.top, AppSpacing.medium)
                
                
                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: AppSpacing.medium),
                        GridItem(.flexible(), spacing: AppSpacing.medium)
                    ],
                    spacing: AppSpacing.medium
                ) {
                    ForEach(Array(scenarios.enumerated()), id: \.element.id) { index, scenario in
                        NavigationLink(value: AppRoute.actionScenarioPlayer(scenario)) {
                            ActionScenarioCard(scenario: scenario)
                        }
                        .buttonStyle(ScenarioCardButtonStyle())
                        .opacity(appeared ? 1 : 0)
                        .offset(y: appeared ? 0 : 20)
                        .animation(
                            reduceMotion ? .none : AppAnimation.spring.delay(Double(index) * 0.05),
                            value: appeared
                        )
                    }
                }
                .padding(.horizontal, AppSpacing.edgePadding)
            }
            .padding(.bottom, AppSpacing.xxxLarge)
        }
        .background(AppColors.background.ignoresSafeArea())
        .onAppear {
            appeared = true
            if accessibility.voiceNarrationEnabled {
                narrator.speak("Emergency scenarios. Choose one to practice.")
            }
        }
    }
    
    private var headerView: some View {
        VStack(spacing: AppSpacing.small) {
            IconBadge(icon: "figure.walk.motion", color: AppColors.info, size: 60)
            
            Text("Learn by Doing")
                .font(AppTypography.title2Rounded.weight(.bold))
                .foregroundStyle(AppColors.label)
            
            Text("Practice real emergency actions")
                .font(AppTypography.callout)
                .foregroundStyle(AppColors.secondaryLabel)
        }
    }
}


struct ActionScenarioCard: View {
    let scenario: ActionScenario
    
    
    private var scenarioImage: String? {
        switch scenario.title {
        case "Bleeding": return "bleeding_scenario"
        case "Burns": return "burns_scenario"
        case "Choking": return "choking_scenario"
        case "Bee Sting": return "bee_sting_scenario"
        case "Broken Bone": return "broken_bone_scenario"
        case "Dog Bite": return "dog_bite_scenario"
        case "Fire Escape": return "fire_escape_scenario"
        case "Nosebleed Hero": return "nose_bleed_scenario"
        default: return nil
        }
    }
    
    var body: some View {
        Group {
            if let imageName = scenarioImage {
                
                VStack(alignment: .leading, spacing: 0) {
                    Image(imageName)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(maxWidth: .infinity)
                        .frame(height: 140)
                        .clipped()
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(scenario.title)
                            .font(AppTypography.headline)
                            .foregroundStyle(AppColors.label)
                        
                        HStack(spacing: 4) {
                            Image(systemName: "hand.tap")
                                .font(.caption)
                            Text("\(scenario.steps.count) actions")
                                .font(AppTypography.caption)
                        }
                        .foregroundStyle(AppColors.secondaryLabel)
                    }
                    .padding(12)
                }
                .background(AppColors.cardBackground)
                .clipShape(RoundedRectangle(cornerRadius: AppCornerRadius.card))
                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
            } else {
                
                VStack(alignment: .leading, spacing: AppSpacing.small) {
                    
                    Image(systemName: scenario.icon)
                        .font(.system(size: 40))
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(scenario.color.gradient)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    Spacer()
                    
                    
                    Text(scenario.title)
                        .font(AppTypography.headline)
                        .foregroundStyle(AppColors.label)
                        .multilineTextAlignment(.leading)
                    
                    
                    HStack(spacing: AppSpacing.xxSmall) {
                        Image(systemName: "hand.tap")
                            .font(.caption)
                        Text("\(scenario.steps.count) actions")
                            .font(AppTypography.caption)
                    }
                    .foregroundStyle(AppColors.secondaryLabel)
                }
                .padding(AppSpacing.cardPadding)
                .frame(height: 150)
                .background {
                    RoundedRectangle(cornerRadius: AppCornerRadius.card)
                        .fill(AppColors.cardBackground)
                        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                }
            }
        }
    }
}



struct ScenarioCardButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1.0)
            .animation(AppAnimation.spring, value: configuration.isPressed)
            .onChange(of: configuration.isPressed) { pressed in
                if pressed {
                    HapticManager.shared.light()
                }
            }
    }
}

#Preview {
    NavigationStack {
        ActionScenarioListView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
            .environment(AccessibilitySettings())
    }
}
