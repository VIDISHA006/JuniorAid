import SwiftUI




struct ActionScenarioPlayerView: View {
    let scenario: ActionScenario
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    @Environment(\.dismiss) private var dismiss
    
    @State private var currentStepIndex = 0
    @State private var showBreathingOrb = true
    @State private var showFreezeFrame = false
    @State private var adaptiveDifficulty = AdaptiveDifficulty()
    
    private var currentStep: ActionStep? {
        guard currentStepIndex < scenario.steps.count else { return nil }
        return scenario.steps[currentStepIndex]
    }
    
    private var isComplete: Bool {
        currentStepIndex >= scenario.steps.count
    }
    
    var body: some View {
        ZStack {
            
            JuniorAidColors.creamBackground
                .ignoresSafeArea()
            
            if showBreathingOrb {
                breathingOrbView
            } else if showFreezeFrame {
                freezeFrameView
            } else {
                mainContent
            }
        }
        .navigationBarHidden(true)
    }
    
    
    private var breathingOrbView: some View {
        BreathingOrb {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                showBreathingOrb = false
            }
            
            
            if let step = currentStep, accessibility.voiceNarrationEnabled {
                narrator.speak(step.voiceNarration)
            }
        }
    }
    
    
    private var mainContent: some View {
        VStack(spacing: 0) {
            
            headerView
                .padding(.horizontal, Spacing.medium)
                .padding(.top, Spacing.small)
            
            if let step = currentStep {
                ScrollView {
                    VStack(spacing: Spacing.large) {
                        
                        instructionCard(step: step)
                        
                        
                        ZStack {
                            
                            visualArea(step: step)
                            
                            
                            gestureArea(for: step)
                        }
                        .frame(maxWidth: .infinity)
                        .aspectRatio(1.0, contentMode: .fit) 
                        .padding(.horizontal, Spacing.medium)
                        
                        
                        bottomProgress(step: step)
                            .padding(.horizontal, Spacing.large)
                            .padding(.bottom, Spacing.large)
                    }
                    .padding(.vertical, Spacing.medium)
                }
            }
        }
    }
    
    
    private var headerView: some View {
        HStack(spacing: 12) {
            
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.1))
                    .frame(width: 40, height: 40)
                Image(systemName: "shield.fill")
                    .foregroundColor(.blue)
                    .font(.system(size: 18))
            }
            
            
            VStack(alignment: .leading, spacing: 2) {
                Text("JuniorAid+ TRAINING")
                    .font(JuniorAidFont.headline.bold())
                    .foregroundColor(.blue)
                    .tracking(1.0)
                
                if let step = currentStep {
                    Text("Step \(currentStepIndex + 1): \(step.title)")
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                }
            }
            
            Spacer()
            
            
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(JuniorAidColors.secondaryText)
                    .padding(8)
                    .background(Color.black.opacity(0.05))
                    .clipShape(Circle())
            }
        }
    }
    
    
    private func instructionCard(step: ActionStep) -> some View {
        VStack(spacing: 8) {
            Text(step.instruction)
                .font(JuniorAidFont.title.bold())
                .foregroundColor(JuniorAidColors.primaryText)
                .multilineTextAlignment(.center)
            
            if let guidance = step.coachGuidance {
                Text(guidance)
                    .font(JuniorAidFont.body)
                    .foregroundColor(JuniorAidColors.secondaryText)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.vertical, 30)
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
        .padding(.horizontal, Spacing.medium)
    }
    
    
    private func visualArea(step: ActionStep) -> some View {
        ZStack {
            
            RoundedRectangle(cornerRadius: 30)
                .fill(step.animation == .none ? Color.clear : scenario.color.opacity(0.2)) 
            
            if step.animation != .none {
                ScenarioAnimationView(type: step.animation, color: scenario.color)
                    .clipShape(RoundedRectangle(cornerRadius: 30))
            }
            
            
            
        }
    }
    
    
    private func bottomProgress(step: ActionStep) -> some View {
        VStack(spacing: 12) {
            HStack {
                Text("Scenario Progress")
                    .font(JuniorAidFont.caption.bold()) 
                    .foregroundColor(.blue)
                
                Spacer()
                
                Text("\(currentStepIndex + 1) of \(scenario.steps.count)")
                    .font(JuniorAidFont.caption.bold())
                    .foregroundColor(JuniorAidColors.secondaryText)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(JuniorAidColors.glassFill)
                    .cornerRadius(8)
            }
            
            
            HStack(spacing: 6) {
                ForEach(0..<scenario.steps.count, id: \.self) { index in
                    Capsule()
                        .fill(index <= currentStepIndex ? Color.blue : JuniorAidColors.glassStroke)
                        .frame(height: 8)
                        .animation(.spring(), value: currentStepIndex)
                }
            }
        }
    }
    
    
    @ViewBuilder
    private func gestureArea(for step: ActionStep) -> some View {
        
        
        
        switch step.gestureType {
        case .pressAndHold(let seconds):
            PressureGesture(duration: seconds) {
                handleStepComplete(step)
            }
            
        case .dragAndHold(let item, let duration):
            DragAndHoldGesture(
                item: item,
                duration: duration
            ) {
                handleStepComplete(step)
            }
            
        case .rhythmTap(let count, let bpm):
            
            
            RhythmTapGesture(count: count, bpm: bpm, color: scenario.color) {
                handleStepComplete(step)
            }
            
        case .swipePath(let direction):
            SwipePathGesture(
                direction: direction,
                instruction: "" 
            ) {
                handleStepComplete(step)
            }
            
        case .swipeSequence(let directions):
            SwipeSequenceGesture(
                directions: directions,
                instruction: ""
            ) {
                handleStepComplete(step)
            }
            
        case .holdToActivate(let seconds):
            HoldToActivateGesture(
                seconds: seconds,
                icon: step.visualCue,
                label: ""
            ) {
                handleStepComplete(step)
            }
            
        case .dragToPosition:
            HoldToActivateGesture(
                seconds: 3,
                icon: step.visualCue,
                label: ""
            ) {
                handleStepComplete(step)
            }
            
        case .tap:
            TapInteraction(
                icon: step.visualCue,
                label: ""
            ) {
                handleStepComplete(step)
            }
        }
    }
    
    
    private var freezeFrameView: some View {
        FreezeFrameView(
            scenarioName: scenario.title,
            keyAction: scenario.memoryCard.keyAction,
            icon: scenario.memoryCard.icon,
            color: scenario.color
        ) {
            
            saveMemoryCard()
            dismiss()
        }
    }
    
    
    private func handleStepComplete(_ step: ActionStep) {
        
        adaptiveDifficulty.recordSuccess()
        
        
        if accessibility.voiceNarrationEnabled {
            narrator.speak(step.successEffect.message)
        }
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            currentStepIndex += 1
            
            if isComplete {
                
                withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                    showFreezeFrame = true
                }
            } else {
                
                if let nextStep = currentStep, accessibility.voiceNarrationEnabled {
                    narrator.speak(nextStep.voiceNarration)
                }
            }
        }
    }
    
    private func saveMemoryCard() {
        
        let card = MemoryCard(
            scenarioName: scenario.title,
            keyAction: scenario.memoryCard.keyAction,
            icon: scenario.memoryCard.icon,
            color: scenario.color
        )
        
        
        print("Saved memory card: \(card.keyAction)")
    }
}

#Preview {
    NavigationStack {
        if #available(iOS 18.0, *) {
            ActionScenarioPlayerView(
                scenario: ActionScenarioContent.shared.bleedingScenario
            )
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
            .environment(AccessibilitySettings())
        }
    }
}

