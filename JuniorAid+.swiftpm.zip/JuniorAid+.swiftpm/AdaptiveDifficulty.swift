import SwiftUI

// MARK: - Adaptive Difficulty System
// Adjusts guidance based on performance (NOT AI, just logic)

@MainActor
@Observable
class AdaptiveDifficulty {
    var mistakeCount = 0
    var scenarioAttempts = 0
    
    var assistanceLevel: AssistanceLevel {
        if mistakeCount >= 2 {
            return .high
        } else if mistakeCount == 1 {
            return .medium
        } else {
            return .low
        }
    }
    
    var animationSpeed: Double {
        switch assistanceLevel {
        case .high: return 0.7  // 30% slower
        case .medium: return 0.85 // 15% slower
        case .low: return 1.0   // Normal speed
        }
    }
    
    var showsCoach: Bool {
        assistanceLevel != .low
    }
    
    var coachFrequency: CoachFrequency {
        switch assistanceLevel {
        case .high: return .frequent
        case .medium: return .occasional
        case .low: return .minimal
        }
    }
    
    func recordMistake() {
        mistakeCount += 1
    }
    
    func recordSuccess() {
        // Success doesn't reduce mistakes, but affects future scenarios
        scenarioAttempts += 1
    }
    
    func reset() {
        mistakeCount = 0
        scenarioAttempts = 0
    }
}

enum AssistanceLevel {
    case low      // Confident user
    case medium   // Some struggles
    case high     // Needs more help
}

enum CoachFrequency {
    case minimal    // Just key moments
    case occasional // Important steps
    case frequent   // Every step
}

// MARK: - Adaptive Coach Component
struct AdaptiveCoach: View {
    let message: String
    let assistanceLevel: AssistanceLevel
    
    @State private var isVisible = false
    
    var body: some View {
        if shouldShow {
            Text(message)
                .font(JuniorAidFont.body)
                .foregroundColor(JuniorAidColors.primaryText)
                .padding(.vertical, Spacing.xxxSmall)
                .padding(.horizontal, Spacing.medium)
                .background(
                    Capsule()
                        .fill(.ultraThinMaterial)
                        .overlay(
                            Capsule()
                                .stroke(JuniorAidColors.softSky.opacity(0.3), lineWidth: 1)
                        )
                )
                .juniorAidShadow(Shadows.soft)
                .transition(.asymmetric(
                    insertion: .move(edge: .top).combined(with: .opacity),
                    removal: .opacity
                ))
        }
    }
    
    private var shouldShow: Bool {
        switch assistanceLevel {
        case .high: return true
        case .medium: return true
        case .low: return false
        }
    }
}

// MARK: - Scene Feedback Component
// Animated cause-effect feedback for actions

struct SceneFeedback: View {
    let isCorrect: Bool
    let characterState: CharacterState
    let environmentTone: EnvironmentTone
    
    var body: some View {
        backgroundGradient
            .ignoresSafeArea()
    }
    
    private var backgroundGradient: LinearGradient {
        switch environmentTone {
        case .calm:
            return LinearGradient(
                colors: [
                    JuniorAidColors.mintWhisper.opacity(0.4),
                    JuniorAidColors.softSky.opacity(0.3),
                    JuniorAidColors.glassSlate
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        case .neutral:
            return JuniorAidColors.backgroundGradient
        case .alert:
            return LinearGradient(
                colors: [
                    JuniorAidColors.peachMist.opacity(0.3),
                    JuniorAidColors.lavenderHaze.opacity(0.2),
                    JuniorAidColors.glassSlate
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        }
    }
    
    @ViewBuilder
    private var characterView: some View {
        switch characterState {
        case .breathing:
            BreathingCharacter()
        case .relaxed:
            RelaxedCharacter()
        case .concerned:
            ConcernedCharacter()
        }
    }
}

enum CharacterState {
    case breathing  // Calm, slow breathing
    case relaxed    // Happy, recovered
    case concerned  // Needs help
}

enum EnvironmentTone {
    case calm    // Success, everything is okay
    case neutral // Normal state
    case alert   // Needs attention
}

// MARK: - Character Views
struct BreathingCharacter: View {
    @State private var breathScale: CGFloat = 1.0
    
    var body: some View {
        Circle()
            .fill(JuniorAidColors.mintWhisper.opacity(0.5))
            .frame(width: 100, height: 100)
            .overlay(
                Image(systemName: "figure.stand")
                    .font(.system(size: 50))
                    .foregroundColor(JuniorAidColors.deepIndigo)
            )
            .scaleEffect(breathScale)
            .onAppear {
                withAnimation(
                    .easeInOut(duration: 3.0)
                    .repeatForever(autoreverses: true)
                ) {
                    breathScale = 1.1
                }
            }
    }
}

struct RelaxedCharacter: View {
    var body: some View {
        Circle()
            .fill(JuniorAidColors.mintWhisper)
            .frame(width: 100, height: 100)
            .overlay(
                Image(systemName: "face.smiling.fill")
                    .font(.system(size: 50))
                    .foregroundColor(JuniorAidColors.deepIndigo)
            )
    }
}

struct ConcernedCharacter: View {
    var body: some View {
        Circle()
            .fill(JuniorAidColors.peachMist.opacity(0.5))
            .frame(width: 100, height: 100)
            .overlay(
                Image(systemName: "figure.arms.open")
                    .font(.system(size: 50))
                    .foregroundColor(JuniorAidColors.deepIndigo)
            )
    }
}

#Preview("Adaptive Coach - High") {
    AdaptiveCoach(message: "Great job! Keep going.", assistanceLevel: .high)
        .padding()
}

#Preview("Scene Feedback - Correct") {
    SceneFeedback(
        isCorrect: true,
        characterState: .breathing,
        environmentTone: .calm
    )
}

#Preview("Scene Feedback - Incorrect") {
    SceneFeedback(
        isCorrect: false,
        characterState: .concerned,
        environmentTone: .alert
    )
}
