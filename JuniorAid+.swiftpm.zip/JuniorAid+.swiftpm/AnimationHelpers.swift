import SwiftUI
import UIKit
import AudioToolbox

// MARK: - Animation Helpers
// Custom animations, transitions, and haptic feedback utilities

/// Predefined spring animations for consistent motion
enum SpringAnimations {
    /// Gentle spring for subtle movements
    static let gentle = Animation.spring(response: 0.5, dampingFraction: 0.7)
    
    /// Bouncy spring for playful interactions
    static let bouncy = Animation.spring(response: 0.4, dampingFraction: 0.6)
    
    /// Quick spring for responsive feedback
    static let quick = Animation.spring(response: 0.3, dampingFraction: 0.8)
    
    /// Smooth spring for calm transitions
    static let smooth = Animation.spring(response: 0.6, dampingFraction: 0.9)
}

// MARK: - Haptic Manager (iOS 26 Premium Feel)
// Centralized haptic feedback using UIKit generators
// Swift 6 compliant with nonisolated access

@MainActor
public final class HapticManager {
    public static let shared = HapticManager()
    
    private let lightGenerator = UIImpactFeedbackGenerator(style: .light)
    private let mediumGenerator = UIImpactFeedbackGenerator(style: .medium)
    private let heavyGenerator = UIImpactFeedbackGenerator(style: .heavy)
    private let selectionGenerator = UISelectionFeedbackGenerator()
    private let notificationGenerator = UINotificationFeedbackGenerator()
    
    private init() {
        // Pre-prepare generators for reduced latency
        Task { @MainActor in
            lightGenerator.prepare()
            mediumGenerator.prepare()
            heavyGenerator.prepare()
            selectionGenerator.prepare()
            notificationGenerator.prepare()
        }
    }
    
    // MARK: - Impact Haptics (nonisolated for cross-context access)
    
    /// Subtle tick (e.g., scroll boundaries, selection changes)
    nonisolated public func tick() {
        Task { @MainActor in
            await self.lightGenerator.impactOccurred()
        }
    }
    
    /// Standard tap (e.g., button press, toggle)
    nonisolated public func tap() {
        Task { @MainActor in
            await self.mediumGenerator.impactOccurred()
        }
    }
    
    /// Strong impact (e.g., gesture pressure applied, critical action)
    nonisolated public func impact() {
        Task { @MainActor in
            await self.heavyGenerator.impactOccurred()
        }
    }
    
    // Legacy aliases
    nonisolated public func light() { tick() }
    nonisolated public func medium() { tap() }
    nonisolated public func heavy() { impact() }
    
    // MARK: - Selection Haptic
    
    /// Selection change (e.g., picker scroll, segment control)
    nonisolated public func selection() {
        Task { @MainActor in
            await self.selectionGenerator.selectionChanged()
        }
    }
    
    // MARK: - Notification Haptics
    
    /// Success feedback (e.g., task completed, payment success)
    nonisolated public func success() {
        Task { @MainActor in
            await self.notificationGenerator.notificationOccurred(.success)
        }
    }
    
    /// Warning feedback (e.g., approaching limit, caution)
    nonisolated public func warning() {
        Task { @MainActor in
            await self.notificationGenerator.notificationOccurred(.warning)
        }
    }
    
    /// Error feedback (e.g., failed action, invalid input)
    nonisolated public func error() {
        Task { @MainActor in
            await self.notificationGenerator.notificationOccurred(.error)
        }
    }
    
    // MARK: - Custom Patterns
    
    /// Shutter-level trust (uses native Camera API for high-stakes actions)
    /// Use for: Payment confirmations, critical emergency actions
    nonisolated public func shutter() {
        AudioServicesPlaySystemSound(1519) // Camera shutter sound ID
    }
    
    /// Gentle pulse (for breathing exercises, meditation)
    nonisolated func pulse() {
        Task { @MainActor in
            await self.lightGenerator.impactOccurred()
            try? await Task.sleep(for: .milliseconds(100))
            await self.lightGenerator.impactOccurred(intensity: 0.5)
        }
    }
}

// MARK: - Sparkle Effect (for correct answers)
struct SparkleEffect: View {
    @State private var isAnimating = false
    
    var body: some View {
        ZStack {
            ForEach(0..<8) { index in
                Circle()
                    .fill(JuniorAidColors.successGreen)
                    .frame(width: 8, height: 8)
                    .offset(
                        x: isAnimating ? cos(Double(index) * .pi / 4) * 80 : 0,
                        y: isAnimating ? sin(Double(index) * .pi / 4) * 80 : 0
                    )
                    .opacity(isAnimating ? 0 : 1)
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.8)) {
                isAnimating = true
            }
        }
    }
}

// MARK: - Celebration Animation
struct CelebrationAnimation: View {
    @State private var isAnimating = false
    
    var body: some View {
        ZStack {
            // Confetti particles
            ForEach(0..<20) { index in
                RoundedRectangle(cornerRadius: 2)
                    .fill(randomColor(for: index))
                    .frame(width: 10, height: 10)
                    .offset(
                        x: isAnimating ? CGFloat.random(in: -150...150) : 0,
                        y: isAnimating ? CGFloat.random(in: -200...100) : -50
                    )
                    .rotationEffect(.degrees(isAnimating ? Double.random(in: 0...360) : 0))
                    .opacity(isAnimating ? 0 : 1)
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 1.2)) {
                isAnimating = true
            }
        }
    }
    
    private func randomColor(for index: Int) -> Color {
        let colors: [Color] = [
            JuniorAidColors.successGreen,
            JuniorAidColors.encouragementYellow,
            JuniorAidColors.bleedingPastel,
            JuniorAidColors.chokingPastel,
            JuniorAidColors.helpPastel
        ]
        return colors[index % colors.count]
    }
}

// MARK: - Gentle Shake Animation (for retry)
struct ShakeEffect: GeometryEffect {
    var amount: CGFloat = 10
    var shakesPerUnit = 3
    var animatableData: CGFloat
    
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(
            CGAffineTransform(
                translationX: amount * sin(animatableData * .pi * CGFloat(shakesPerUnit)),
                y: 0
            )
        )
    }
}

extension View {
    func shake(with shakeNumber: Int) -> some View {
        self.modifier(ShakeEffect(animatableData: CGFloat(shakeNumber)))
    }
}

// MARK: - Progress Ring
struct ProgressRing: View {
    let progress: Double
    let lineWidth: CGFloat
    let color: Color
    
    init(
        progress: Double,
        lineWidth: CGFloat = 12,
        color: Color = JuniorAidColors.successGreen
    ) {
        self.progress = progress
        self.lineWidth = lineWidth
        self.color = color
    }
    
    var body: some View {
        ZStack {
            // Background ring
            Circle()
                .stroke(color.opacity(0.2), lineWidth: lineWidth)
            
            // Progress ring
            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    color,
                    style: StrokeStyle(
                        lineWidth: lineWidth,
                        lineCap: .round
                    )
                )
                .rotationEffect(.degrees(-90))
                .animation(.spring(response: 0.5, dampingFraction: 0.8), value: progress)
        }
    }
}

// MARK: - Countdown Timer Display
struct CountdownTimerView: View {
    let timeRemaining: Int
    let totalTime: Int
    
    var progress: Double {
        Double(timeRemaining) / Double(totalTime)
    }
    
    var body: some View {
        ZStack {
            ProgressRing(progress: progress, lineWidth: 16)
                .frame(width: 200, height: 200)
            
            VStack(spacing: Spacing.small) {
                Text("\(timeRemaining)")
                    .font(JuniorAidFont.largeTitle)
                    .foregroundColor(JuniorAidColors.primaryText)
                
                Text("seconds")
                    .font(JuniorAidFont.caption)
                    .foregroundColor(JuniorAidColors.secondaryText)
            }
        }
    }
}

// MARK: - Breathing Animation (Calming)
struct BreathingCircle: View {
    @State private var isExpanded = false
    let color: Color
    
    init(color: Color = JuniorAidColors.successGreen) {
        self.color = color
    }
    
    var body: some View {
        Circle()
            .fill(
                RadialGradient(
                    colors: [color.opacity(0.6), color.opacity(0.2)],
                    center: .center,
                    startRadius: 20,
                    endRadius: 120
                )
            )
            .frame(width: isExpanded ? 120 : 80, height: isExpanded ? 120 : 80)
            .blur(radius: 10)
            .onAppear {
                withAnimation(
                    .easeInOut(duration: 3.0)
                    .repeatForever(autoreverses: true)
                ) {
                    isExpanded = true
                }
            }
    }
}

// MARK: - Fade In Transition
extension View {
    func fadeInTransition(delay: Double = 0) -> some View {
        self.modifier(FadeInModifier(delay: delay))
    }
}

struct FadeInModifier: ViewModifier {
    let delay: Double
    @State private var opacity: Double = 0
    
    func body(content: Content) -> some View {
        content
            .opacity(opacity)
            .onAppear {
                withAnimation(.easeIn(duration: 0.6).delay(delay)) {
                    opacity = 1
                }
            }
    }
}

// MARK: - Scale In Transition
extension View {
    func scaleInTransition(delay: Double = 0) -> some View {
        self.modifier(ScaleInModifier(delay: delay))
    }
}

struct ScaleInModifier: ViewModifier {
    let delay: Double
    @State private var scale: CGFloat = 0.8
    @State private var opacity: Double = 0
    
    func body(content: Content) -> some View {
        content
            .scaleEffect(scale)
            .opacity(opacity)
            .onAppear {
                withAnimation(SpringAnimations.bouncy.delay(delay)) {
                    scale = 1.0
                    opacity = 1.0
                }
            }
    }
}

// MARK: - Slide In Transition
enum SlideDirection {
    case top, bottom, leading, trailing
}

extension View {
    func slideInTransition(from direction: SlideDirection, delay: Double = 0) -> some View {
        self.modifier(SlideInModifier(direction: direction, delay: delay))
    }
}

struct SlideInModifier: ViewModifier {
    let direction: SlideDirection
    let delay: Double
    
    @State private var offset: CGSize = .zero
    @State private var opacity: Double = 0
    
    func body(content: Content) -> some View {
        content
            .offset(offset)
            .opacity(opacity)
            .onAppear {
                // Set initial offset based on direction
                switch direction {
                case .top:
                    offset = CGSize(width: 0, height: -100)
                case .bottom:
                    offset = CGSize(width: 0, height: 100)
                case .leading:
                    offset = CGSize(width: -100, height: 0)
                case .trailing:
                    offset = CGSize(width: 100, height: 0)
                }
                
                withAnimation(SpringAnimations.smooth.delay(delay)) {
                    offset = .zero
                    opacity = 1.0
                }
            }
    }
}
