import SwiftUI





struct PrimaryButton: View {
    let title: String
    let icon: String?
    let action: () -> Void
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    init(_ title: String, icon: String? = nil, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.action = action
    }
    
    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: AppSpacing.xSmall) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.title3.weight(.semibold))
                }
                Text(title)
                    .font(AppTypography.headline)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56) 
            .foregroundStyle(.white)
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.large)
        .tint(AppColors.primary)
    }
}


struct SecondaryButton: View {
    let title: String
    let icon: String?
    let action: () -> Void
    
    init(_ title: String, icon: String? = nil, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.action = action
    }
    
    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: AppSpacing.xSmall) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.title3.weight(.semibold))
                }
                Text(title)
                    .font(AppTypography.headline)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
        }
        .buttonStyle(.bordered)
        .controlSize(.large)
        .tint(AppColors.primary)
    }
}


struct HIGScenarioCard: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button {
            action()
        } label: {
            VStack(alignment: .leading, spacing: AppSpacing.small) {
                
                Image(systemName: icon)
                    .font(.system(size: 40))
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(color.gradient)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer()
                
                
                Text(title)
                    .font(AppTypography.title3Rounded.weight(.semibold))
                    .foregroundStyle(AppColors.label)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
            }
            .padding(AppSpacing.cardPadding)
            .frame(height: 140)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.card)
                    .fill(AppColors.cardBackground)
                    .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
            }
            .overlay {
                RoundedRectangle(cornerRadius: AppCornerRadius.card)
                    .strokeBorder(AppColors.separator, lineWidth: 0.5)
            }
            .scaleEffect(isPressed ? 0.96 : 1.0)
            .buttonStyle(.plain)
            .simultaneousGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        withAnimation(AppAnimation.spring) {
                            isPressed = true
                        }
                    }
                    .onEnded { _ in
                        withAnimation(AppAnimation.spring) {
                            isPressed = false
                        }
                    }
            )
            .sensoryFeedback(.selection, trigger: isPressed)
        }
    }
}


struct InfoCard<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(AppSpacing.cardPadding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.card)
                    .fill(AppColors.cardBackground)
                    .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
            }
    }
}


struct SectionHeader: View {
    let title: String
    let subtitle: String?
    
    init(_ title: String, subtitle: String? = nil) {
        self.title = title
        self.subtitle = subtitle
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: AppSpacing.xxSmall) {
            Text(title)
                .font(AppTypography.title2Rounded.weight(.bold))
                .foregroundStyle(AppColors.label)
            
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(AppTypography.callout)
                    .foregroundStyle(AppColors.secondaryLabel)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}


struct ProgressDots: View {
    let total: Int
    let current: Int
    
    var body: some View {
        HStack(spacing: AppSpacing.xxSmall) {
            ForEach(0..<total, id: \.self) { index in
                Circle()
                    .fill(index == current ? AppColors.primary : AppColors.separator)
                    .frame(width: 8, height: 8)
                    .scaleEffect(index == current ? 1.2 : 1.0)
                    .animation(AppAnimation.spring, value: current)
            }
        }
    }
}


struct IconBadge: View {
    let icon: String
    let color: Color
    let size: CGFloat
    
    init(icon: String, color: Color = AppColors.primary, size: CGFloat = 60) {
        self.icon = icon
        self.color = color
        self.size = size
    }
    
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: size))
            .symbolRenderingMode(.hierarchical)
            .foregroundStyle(color.gradient)
    }
}


struct EmptyState: View {
    let icon: String
    let title: String
    let message: String
    let actionTitle: String?
    let action: (() -> Void)?
    
    init(
        icon: String,
        title: String,
        message: String,
        actionTitle: String? = nil,
        action: (() -> Void)? = nil
    ) {
        self.icon = icon
        self.title = title
        self.message = message
        self.actionTitle = actionTitle
        self.action = action
    }
    
    var body: some View {
        VStack(spacing: AppSpacing.large) {
            IconBadge(icon: icon, color: AppColors.secondaryLabel, size: 80)
            
            VStack(spacing: AppSpacing.xSmall) {
                Text(title)
                    .font(AppTypography.title2Bold)
                    .foregroundStyle(AppColors.label)
                
                Text(message)
                    .font(AppTypography.body)
                    .foregroundStyle(AppColors.secondaryLabel)
                    .multilineTextAlignment(.center)
            }
            
            if let actionTitle = actionTitle, let action = action {
                PrimaryButton(actionTitle, action: action)
                    .frame(maxWidth: 280)
            }
        }
        .padding(AppSpacing.large)
    }
}


struct LoadingView: View {
    let message: String
    
    var body: some View {
        VStack(spacing: AppSpacing.medium) {
            ProgressView()
                .scaleEffect(1.2)
            
            Text(message)
                .font(AppTypography.callout)
                .foregroundStyle(AppColors.secondaryLabel)
        }
    }
}

#Preview("Buttons") {
    VStack(spacing: 20) {
        PrimaryButton("Continue", icon: "arrow.right") {}
        SecondaryButton("Cancel", icon: "xmark") {}
    }
    .padding()
}

#Preview("Cards") {
    VStack {
        HIGScenarioCard(
            title: "Bleeding",
            icon: "drop.fill",
            color: .red
        ) {}
        
        InfoCard {
            Text("This is an info card with important information.")
        }
    }
    .padding()
}
