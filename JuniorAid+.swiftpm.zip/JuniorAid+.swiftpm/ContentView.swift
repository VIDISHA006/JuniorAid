import SwiftUI

struct ContentView: View {
    @State private var navigator = NavigationCoordinator()
    @State private var narrator = VoiceNarrator()
    @State private var accessibility = AccessibilitySettings()
    
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOverEnabled
    @Environment(\.legibilityWeight) private var legibilityWeight
    
    @State private var showSplash = true

    var body: some View {
        ZStack {
            if showSplash {
                SplashScreenView()
                    .transition(.opacity)
                    .zIndex(1) 
            } else {
                NavigationStack(path: $navigator.path) {
                    ZStack {
                        HomeView()
                            .navigationDestination(for: AppRoute.self) { route in
                                routeView(for: route)
                            }
                        

                    }
                }
                .transition(.opacity)
            }
        }
        .environment(navigator)
        .environment(narrator)
        .environment(accessibility)
        .onAppear {
            
            accessibility.reduceMotion = reduceMotion
            accessibility.voiceNarrationEnabled = voiceOverEnabled
            accessibility.largeText = legibilityWeight == .bold
            
            
            if showSplash {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    withAnimation(AppAnimation.standardTransition) {
                        showSplash = false
                    }
                }
            }
        }
    }
    
    @ViewBuilder
    private func routeView(for route: AppRoute) -> some View {
        switch route {
        case .home:
            HomeView()
            
        case .actionScenarioList:
            ActionScenarioListView()  
            
        case .actionScenarioPlayer(let scenario):
            ActionScenarioPlayerView(scenario: scenario)  
            

            
        case .sos:
            SOSView()
            
        case .countrySelector:
            CountrySelectorView()
            
        case .touchSafety:
            TouchSafetyView()
            
        case .touchScenarioPlayer(let questions, let index):
            TouchScenarioPlayer(questions: questions, currentIndex: index)
            
        case .mannersSafety:
            MannersSafetyView()
            
        case .mannerScenarioPlayer(let scenario):
            MannerScenarioPlayer(scenario: scenario)
            
        case .memoryGallery:
            MemoryGalleryView()  
            
        case .settings:
            Text("Settings - Coming Soon")
                .font(JuniorAidFont.title)
        }
    }
}

#Preview {
    ContentView()
}
