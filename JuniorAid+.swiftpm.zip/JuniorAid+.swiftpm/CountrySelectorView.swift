import SwiftUI




struct CountrySelectorView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    
    @State private var searchQuery = ""
    @State private var selectedCountry: Country?
    
    private var filteredCountries: [Country] {
        EmergencyData.shared.searchCountries(query: searchQuery)
    }
    
    var body: some View {
        ZStack {
            
            LinearGradient(
                colors: [
                    JuniorAidColors.sosRed.opacity(0.2),
                    JuniorAidColors.helpPastel.opacity(0.3),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(spacing: Spacing.large) {
                
                header
                    .padding(.top, Spacing.medium)
                
                
                ScrollView {
                    LazyVGrid(
                        columns: [
                            GridItem(.flexible(), spacing: Spacing.medium),
                            GridItem(.flexible(), spacing: Spacing.medium)
                        ],
                        spacing: Spacing.medium
                    ) {
                        ForEach(Array(filteredCountries.enumerated()), id: \.element.id) { index, country in
                            countryCard(country)
                                .scaleInTransition(delay: Double(index) * 0.05)
                        }
                    }
                    .padding(Spacing.large)
                }
            }
        }
        .navigationDestination(item: $selectedCountry) { country in
            EmergencyNumbersView(country: country)
        }
        .onAppear {
            if accessibility.voiceNarrationEnabled {
                narrator.speak("Choose your country to see emergency numbers")
            }
        }
    }
    
    private var header: some View {
        VStack(spacing: Spacing.small) {
            Text("Choose Your Country")
                .font(JuniorAidFont.title)
                .foregroundColor(JuniorAidColors.primaryText)
            
            Text("To see emergency numbers")
                .font(JuniorAidFont.body)
                .foregroundColor(JuniorAidColors.secondaryText)
        }
    }
    
    private func countryCard(_ country: Country) -> some View {
        Button {
            HapticManager.shared.medium()
            selectedCountry = country
            if accessibility.voiceNarrationEnabled {
                narrator.speak("\(country.name) selected")
            }
        } label: {
            VStack(spacing: Spacing.medium) {
                
                Text(country.flagEmoji)
                    .font(.system(size: 60))
                
                
                Text(country.name)
                    .font(JuniorAidFont.headline)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 140)
            .padding(Spacing.medium)
            .background(
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: CornerRadius.large)
                            .stroke(JuniorAidColors.glassStroke, lineWidth: 1.5)
                    )
            )
            .juniorAidShadow(Shadows.medium)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    NavigationStack {
        CountrySelectorView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
            .environment(AccessibilitySettings())
    }
}
