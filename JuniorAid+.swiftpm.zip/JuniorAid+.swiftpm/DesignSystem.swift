import SwiftUI

// MARK: - Apple HIG-Compliant Design System
// Following Apple Human Interface Guidelines with WCAG AA contrast

// MARK: - Colors
struct AppColors {
    // MARK: Semantic Colors (WCAG AA Compliant)
    // Primary brand colors with guaranteed contrast
    static let primary = Color.blue                    // 7:1 contrast on white
    static let accent = Color.orange                   // 5:1 contrast
    
    // Scenario-specific colors (semantic)
    static let medical = Color.red                     // Emergency scenarios
    static let safety = Color.green                    // Success states
    static let warning = Color.yellow                  // Warnings
    static let info = Color.blue                       // Information
    
    // System Backgrounds (Adaptive)
    static let background = Color(red: 253/255, green: 249/255, blue: 243/255) // #FDF9F3
    static let secondaryBackground = Color(red: 253/255, green: 249/255, blue: 243/255) // Match main bg
    static let tertiaryBackground = Color(red: 253/255, green: 249/255, blue: 243/255) // Match main bg
    static let groupedBackground = Color(red: 253/255, green: 249/255, blue: 243/255) // Match main bg
    
    // Card Backgrounds
    static let cardBackground = Color.white
    
    // Text Colors (Adaptive, WCAG AA)
    static let label = Color(.label)                   // Primary text (4.5:1)
    static let secondaryLabel = Color(.secondaryLabel) // Secondary text
    static let tertiaryLabel = Color(.tertiaryLabel)   // Tertiary text
    static let placeholder = Color(.placeholderText)   // Placeholder text
    
    // Fill Colors (Adaptive)
    static let fill = Color(.systemFill)
    static let secondaryFill = Color(.secondarySystemFill)
    static let tertiaryFill = Color(.tertiarySystemFill)
    
    // Separator
    static let separator = Color(.separator)
    
    // Grouped Backgrounds
    static let groupedPrimary = Color(.systemGroupedBackground)
    static let groupedSecondary = Color(.secondarySystemGroupedBackground)
}

// MARK: - Typography
struct AppTypography {
    // MARK: Dynamic Type Styles
    // All styles automatically scale with user preferences
    
    static let largeTitle = Font.largeTitle              // 34pt
    static let title = Font.title                        // 28pt
    static let title2 = Font.title2                      // 22pt
    static let title3 = Font.title3                      // 20pt
    static let headline = Font.headline                  // 17pt semibold
    static let body = Font.body                          // 17pt regular
    static let callout = Font.callout                    // 16pt regular
    static let subheadline = Font.subheadline           // 15pt regular
    static let footnote = Font.footnote                  // 13pt regular
    static let caption = Font.caption                    // 12pt regular
    static let caption2 = Font.caption2                  // 11pt regular
    
    // MARK: Rounded Design (Friendly)
    static let largeTitleRounded = Font.system(.largeTitle, design: .rounded)
    static let titleRounded = Font.system(.title, design: .rounded)
    static let title2Rounded = Font.system(.title2, design: .rounded)
    static let title3Rounded = Font.system(.title3, design: .rounded)
    static let bodyRounded = Font.system(.body, design: .rounded)
    
    // MARK: Emphasized Weights
    static let largeTitleBold = Font.largeTitle.weight(.bold)
    static let titleBold = Font.title.weight(.bold)
    static let title2Bold = Font.title2.weight(.semibold)
    static let headlineBold = Font.headline.weight(.bold)
    
    // MARK: Button Styles
    static let buttonLarge = Font.headline.weight(.bold)
    static let buttonMedium = Font.body.weight(.semibold)
}

// MARK: - Spacing (8pt Grid System)
struct AppSpacing {
    static let xxxSmall: CGFloat = 4
    static let xxSmall: CGFloat = 8
    static let xSmall: CGFloat = 12
    static let small: CGFloat = 16        // Standard padding
    static let medium: CGFloat = 20       // Medium spacing
    static let large: CGFloat = 24        // Section spacing
    static let xLarge: CGFloat = 32
    static let xxLarge: CGFloat = 40
    static let xxxLarge: CGFloat = 48
    
    // MARK: Standard Values
    static let edgePadding: CGFloat = 16
    static let cardPadding: CGFloat = 16
    static let sectionSpacing: CGFloat = 24
    static let itemSpacing: CGFloat = 12
    
    // MARK: Minimum Tap Target (Apple HIG)
    static let minimumTapTarget: CGFloat = 44
}

// MARK: - Corner Radius
struct AppCornerRadius {
    static let small: CGFloat = 8
    static let medium: CGFloat = 12
    static let large: CGFloat = 16
    static let xLarge: CGFloat = 20
    
    // MARK: Standard Values
    static let button: CGFloat = 12
    static let card: CGFloat = 16
    static let sheet: CGFloat = 20
}

// MARK: - Shadows
struct AppShadows {
    static let small = Shadow(
        color: Color.black.opacity(0.08),
        radius: 4,
        x: 0,
        y: 2
    )
    
    static let medium = Shadow(
        color: Color.black.opacity(0.12),
        radius: 8,
        x: 0,
        y: 4
    )
    
    static let large = Shadow(
        color: Color.black.opacity(0.16),
        radius: 16,
        x: 0,
        y: 8
    )
    
    // Alias for deprecated 'strong' shadow in old components
    static let strong = large
    // Alias for deprecated 'soft' shadow
    static let soft = small
}

struct Shadow {
    let color: Color
    let radius: CGFloat
    let x: CGFloat
    let y: CGFloat
}

// MARK: - Animation Durations (iOS 26)
struct AppAnimation {
    // DEPRECATED: Use spring presets instead
    static let quick: Double = 0.2
    static let standard: Double = 0.3
    static let slow: Double = 0.5
    
    // iOS 26: Native Spring Presets (RECOMMENDED)
    // https://developer.apple.com/documentation/swiftui/animation
    
    /// Fast, clean spring for UI toggles and reveals
    /// Response: ~0.2s, Damping: High
    static let spring: Animation = .snappy
    
    /// Lively spring for celebrations and mascot animations
    /// Response: ~0.4s, Damping: Low (bounces)
    static let springBouncy: Animation = .bouncy
    
    /// Smooth spring for page transitions and large movements  
    /// Response: ~0.5s, Damping: Maximum (no overshoot)
    static let springSmooth: Animation = .smooth
    
    // MARK: Custom Presets
    
    /// Micro-interactions (selection, ticks)
    static var microInteraction: Animation {
        .snappy(duration: 0.2)
    }
    
    /// Standard transitions
    static var standardTransition: Animation {
        .snappy(duration: 0.3)
    }
    
    /// Emphasized animations
    static var emphasized: Animation {
        .bouncy(duration: 0.5)
    }
}

// MARK: - View Extensions
extension View {
    // MARK: Apply Shadow
    func appShadow(_ shadow: Shadow) -> some View {
        self.shadow(
            color: shadow.color,
            radius: shadow.radius,
            x: shadow.x,
            y: shadow.y
        )
    }
    
    // MARK: Standard Card Style
    func cardStyle() -> some View {
        self
            .padding(AppSpacing.cardPadding)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: AppCornerRadius.card))
            .appShadow(AppShadows.small)
    }
    
    // MARK: Minimum Tap Target
    func minimumTapTarget() -> some View {
        self.frame(minWidth: AppSpacing.minimumTapTarget, minHeight: AppSpacing.minimumTapTarget)
    }
}

// MARK: - Backward Compatibility Aliases
// For gradual migration from old design system
typealias JuniorAidColors = AppColors
typealias Spacing = AppSpacing
typealias CornerRadius = AppCornerRadius
typealias Shadows = AppShadows

// MARK: - Old Color System Compatibility
extension AppColors {
    // Core backgrounds
    static let backgroundGradient = LinearGradient(
        colors: [background, secondaryBackground],
        startPoint: .top,
        endPoint: .bottom
    )
    
    //Old custom colors (mapped to system equivalents)
    static let softSky = Color.blue.opacity(0.3)
    static let peachMist = Color.orange.opacity(0.3)
    static let mintWhisper = Color.green
    static let lavenderHaze = Color.purple.opacity(0.3)
    static let glassSlate = Color.gray.opacity(0.3)
    static let deepIndigo = Color.indigo
    static let glassStroke = separator
    
    // Old pastel colors for scenarios
    static let bleedingPastel = Color.red.opacity(0.7)
    static let burnsPastel = Color.orange.opacity(0.7)
    static let chokingPastel = Color.purple.opacity(0.7)
    static let electricPastel = Color.yellow.opacity(0.7)
    static let dogBitePastel = Color.brown.opacity(0.7)
    static let firePastel = Color.orange.opacity(0.7)
    static let helpPastel = Color.green.opacity(0.7)
    static let lostPastel = Color.blue.opacity(0.7)
    
    // Old semantic colors
    static let successGreen = safety
    static let encouragementYellow = Color.yellow
    static let sosRed = medical
    static let primaryText = label
    static let secondaryText = secondaryLabel
    
    // Touch Safety specific colors
    static let safeTouchColor = Color.green
    static let unsafeTouchColor = Color.red
    static let confusingTouchColor = Color.orange
    static let safeTouch = Color.green
    static let unsafeTouch = Color.red
    static let confusingTouch = Color.orange
    
    // SOS Overlay
    static let sosGlow = Color.red.opacity(0.6)
    
    // Emotion Regulation
    static let breathingOrbGradient = LinearGradient(
        colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.6)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    // Character Colors
    static let characterSkin1 = Color.orange.opacity(0.4)
    static let characterOutfit = Color.blue
    
    // New Design System Additions
    static let creamBackground = background
    static let glassFill = Material.regular
}

// MARK: - Font System Alias
struct JuniorAidFont {
    static let largeTitle = AppTypography.largeTitleRounded
    static let title = AppTypography.titleRounded
    static let title2 = AppTypography.title2Rounded
    static let title3 = AppTypography.title3Rounded
    static let headline = AppTypography.headline
    static let body = AppTypography.bodyRounded
    static let bodyLarge = AppTypography.bodyRounded.weight(.medium)
    static let callout = AppTypography.callout
    static let caption = AppTypography.caption
    static let buttonLarge = AppTypography.headline
    static let buttonMedium = AppTypography.body.weight(.semibold)
}

extension View {
    func juniorAidShadow(_ shadow: Shadow) -> some View {
        appShadow(shadow)
    }
}
