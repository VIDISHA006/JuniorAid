import SwiftUI





struct AppColors {
    
    
    static let primary = Color.blue                    
    static let accent = Color.orange                   
    
    
    static let medical = Color.red                     
    static let safety = Color.green                    
    static let warning = Color.yellow                  
    static let info = Color.blue                       
    
    
    static let background = Color(red: 253/255, green: 249/255, blue: 243/255) 
    static let secondaryBackground = Color(red: 253/255, green: 249/255, blue: 243/255) 
    static let tertiaryBackground = Color(red: 253/255, green: 249/255, blue: 243/255) 
    static let groupedBackground = Color(red: 253/255, green: 249/255, blue: 243/255) 
    
    
    static let cardBackground = Color.white
    
    
    static let label = Color(.label)                   
    static let secondaryLabel = Color(.secondaryLabel) 
    static let tertiaryLabel = Color(.tertiaryLabel)   
    static let placeholder = Color(.placeholderText)   
    
    
    static let fill = Color(.systemFill)
    static let secondaryFill = Color(.secondarySystemFill)
    static let tertiaryFill = Color(.tertiarySystemFill)
    
    
    static let separator = Color(.separator)
    
    
    static let groupedPrimary = Color(.systemGroupedBackground)
    static let groupedSecondary = Color(.secondarySystemGroupedBackground)
}


struct AppTypography {
    
    
    
    static let largeTitle = Font.largeTitle              
    static let title = Font.title                        
    static let title2 = Font.title2                      
    static let title3 = Font.title3                      
    static let headline = Font.headline                  
    static let body = Font.body                          
    static let callout = Font.callout                    
    static let subheadline = Font.subheadline           
    static let footnote = Font.footnote                  
    static let caption = Font.caption                    
    static let caption2 = Font.caption2                  
    
    
    static let largeTitleRounded = Font.system(.largeTitle, design: .rounded)
    static let titleRounded = Font.system(.title, design: .rounded)
    static let title2Rounded = Font.system(.title2, design: .rounded)
    static let title3Rounded = Font.system(.title3, design: .rounded)
    static let bodyRounded = Font.system(.body, design: .rounded)
    
    
    static let largeTitleBold = Font.largeTitle.weight(.bold)
    static let titleBold = Font.title.weight(.bold)
    static let title2Bold = Font.title2.weight(.semibold)
    static let headlineBold = Font.headline.weight(.bold)
    
    
    static let buttonLarge = Font.headline.weight(.bold)
    static let buttonMedium = Font.body.weight(.semibold)
}


struct AppSpacing {
    static let xxxSmall: CGFloat = 4
    static let xxSmall: CGFloat = 8
    static let xSmall: CGFloat = 12
    static let small: CGFloat = 16        
    static let medium: CGFloat = 20       
    static let large: CGFloat = 24        
    static let xLarge: CGFloat = 32
    static let xxLarge: CGFloat = 40
    static let xxxLarge: CGFloat = 48
    
    
    static let edgePadding: CGFloat = 16
    static let cardPadding: CGFloat = 16
    static let sectionSpacing: CGFloat = 24
    static let itemSpacing: CGFloat = 12
    
    
    static let minimumTapTarget: CGFloat = 44
}


struct AppCornerRadius {
    static let small: CGFloat = 8
    static let medium: CGFloat = 12
    static let large: CGFloat = 16
    static let xLarge: CGFloat = 20
    
    
    static let button: CGFloat = 12
    static let card: CGFloat = 16
    static let sheet: CGFloat = 20
}


struct AppShadows {
    static let small = Shadow(
        color: Color.black.opacity(0.08),
        radius: 4,
        x: 0,
        y: 2
    )
    
    static let medium = Shadow(
        color: Color.black.opacity(0.12),
        radius: 8,
        x: 0,
        y: 4
    )
    
    static let large = Shadow(
        color: Color.black.opacity(0.16),
        radius: 16,
        x: 0,
        y: 8
    )
    
    
    static let strong = large
    
    static let soft = small
}

struct Shadow {
    let color: Color
    let radius: CGFloat
    let x: CGFloat
    let y: CGFloat
}


struct AppAnimation {
    
    static let quick: Double = 0.2
    static let standard: Double = 0.3
    static let slow: Double = 0.5
    
    
    
    
    
    
    static let spring: Animation = .snappy
    
    
    
    static let springBouncy: Animation = .bouncy
    
    
    
    static let springSmooth: Animation = .smooth
    
    
    
    
    static var microInteraction: Animation {
        .snappy(duration: 0.2)
    }
    
    
    static var standardTransition: Animation {
        .snappy(duration: 0.3)
    }
    
    
    static var emphasized: Animation {
        .bouncy(duration: 0.5)
    }
}


extension View {
    
    func appShadow(_ shadow: Shadow) -> some View {
        self.shadow(
            color: shadow.color,
            radius: shadow.radius,
            x: shadow.x,
            y: shadow.y
        )
    }
    
    
    func cardStyle() -> some View {
        self
            .padding(AppSpacing.cardPadding)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: AppCornerRadius.card))
            .appShadow(AppShadows.small)
    }
    
    
    func minimumTapTarget() -> some View {
        self.frame(minWidth: AppSpacing.minimumTapTarget, minHeight: AppSpacing.minimumTapTarget)
    }
}



typealias JuniorAidColors = AppColors
typealias Spacing = AppSpacing
typealias CornerRadius = AppCornerRadius
typealias Shadows = AppShadows


extension AppColors {
    
    static let backgroundGradient = LinearGradient(
        colors: [background, secondaryBackground],
        startPoint: .top,
        endPoint: .bottom
    )
    
    
    static let softSky = Color.blue.opacity(0.3)
    static let peachMist = Color.orange.opacity(0.3)
    static let mintWhisper = Color.green
    static let lavenderHaze = Color.purple.opacity(0.3)
    static let glassSlate = Color.gray.opacity(0.3)
    static let deepIndigo = Color.indigo
    static let glassStroke = separator
    
    
    static let bleedingPastel = Color.red.opacity(0.7)
    static let burnsPastel = Color.orange.opacity(0.7)
    static let chokingPastel = Color.purple.opacity(0.7)
    static let electricPastel = Color.yellow.opacity(0.7)
    static let dogBitePastel = Color.brown.opacity(0.7)
    static let firePastel = Color.orange.opacity(0.7)
    static let helpPastel = Color.green.opacity(0.7)
    static let lostPastel = Color.blue.opacity(0.7)
    
    
    static let successGreen = safety
    static let encouragementYellow = Color.yellow
    static let sosRed = medical
    static let primaryText = label
    static let secondaryText = secondaryLabel
    
    
    static let safeTouchColor = Color.green
    static let unsafeTouchColor = Color.red
    static let confusingTouchColor = Color.orange
    static let safeTouch = Color.green
    static let unsafeTouch = Color.red
    static let confusingTouch = Color.orange
    
    
    static let sosGlow = Color.red.opacity(0.6)
    
    
    static let breathingOrbGradient = LinearGradient(
        colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.6)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    
    static let characterSkin1 = Color.orange.opacity(0.4)
    static let characterOutfit = Color.blue
    
    
    static let creamBackground = background
    static let glassFill = Material.regular
}


struct JuniorAidFont {
    static let largeTitle = AppTypography.largeTitleRounded
    static let title = AppTypography.titleRounded
    static let title2 = AppTypography.title2Rounded
    static let title3 = AppTypography.title3Rounded
    static let headline = AppTypography.headline
    static let body = AppTypography.bodyRounded
    static let bodyLarge = AppTypography.bodyRounded.weight(.medium)
    static let callout = AppTypography.callout
    static let caption = AppTypography.caption
    static let buttonLarge = AppTypography.headline
    static let buttonMedium = AppTypography.body.weight(.semibold)
}

extension View {
    func juniorAidShadow(_ shadow: Shadow) -> some View {
        appShadow(shadow)
    }
}
