import SwiftUI

// MARK: - Emergency Data Models
// Offline emergency numbers for global use

/// Emergency contact information for a country
struct Country: Identifiable, Hashable {
    let id: String  // Country code
    let name: String
    let flagEmoji: String
    let emergencyNumbers: EmergencyNumbers
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Country, rhs: Country) -> Bool {
        lhs.id == rhs.id
    }
}

/// Emergency service numbers
struct EmergencyNumbers {
    let police: EmergencyService
    let ambulance: EmergencyService
    let fire: EmergencyService
    let childHelpline: EmergencyService?
    let general: EmergencyService?  // Universal emergency number (e.g., 112 in EU)
}

/// Individual emergency service
struct EmergencyService: Identifiable {
    let id = UUID()
    let name: String
    let number: String
    let icon: String
    let color: Color
    let description: String  // What this number is for
}

// MARK: - Emergency Data Source (OFFLINE)
/// All emergency numbers stored locally - NO INTERNET REQUIRED
class EmergencyData {
    @MainActor static let shared = EmergencyData()
    
    private init() {}
    
    /// All supported countries with emergency numbers
    let countries: [Country] = [
        // India 🇮🇳
        Country(
            id: "IN",
            name: "India",
            flagEmoji: "🇮🇳",
            emergencyNumbers: EmergencyNumbers(
                police: EmergencyService(
                    name: "Police",
                    number: "100",
                    icon: "shield.fill",
                    color: JuniorAidColors.bleedingPastel,
                    description: "Call police for crimes, theft, or danger"
                ),
                ambulance: EmergencyService(
                    name: "Ambulance",
                    number: "102",
                    icon: "cross.case.fill",
                    color: JuniorAidColors.successGreen,
                    description: "Call ambulance for medical emergencies"
                ),
                fire: EmergencyService(
                    name: "Fire",
                    number: "101",
                    icon: "flame.fill",
                    color: JuniorAidColors.burnsPastel,
                    description: "Call fire service for fires or gas leaks"
                ),
                childHelpline: EmergencyService(
                    name: "Child Helpline",
                    number: "1098",
                    icon: "person.fill.checkmark",
                    color: JuniorAidColors.safeTouchColor,
                    description: "Call if you need help or feel unsafe"
                ),
                general: EmergencyService(
                    name: "Women Helpline",
                    number: "1091",
                    icon: "phone.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Emergency helpline for women and children"
                )
            )
        ),
        
        // USA 🇺🇸
        Country(
            id: "US",
            name: "United States",
            flagEmoji: "🇺🇸",
            emergencyNumbers: EmergencyNumbers(
                police: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "shield.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                ambulance: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "cross.case.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                fire: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "flame.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                childHelpline: EmergencyService(
                    name: "Child Help",
                    number: "1-800-422-4453",
                    icon: "person.fill.checkmark",
                    color: JuniorAidColors.safeTouchColor,
                    description: "National child abuse hotline"
                ),
                general: nil
            )
        ),
        
        // UK 🇬🇧
        Country(
            id: "GB",
            name: "United Kingdom",
            flagEmoji: "🇬🇧",
            emergencyNumbers: EmergencyNumbers(
                police: EmergencyService(
                    name: "Emergency Services",
                    number: "999",
                    icon: "shield.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 999 for police, fire, or ambulance"
                ),
                ambulance: EmergencyService(
                    name: "Emergency Services",
                    number: "999",
                    icon: "cross.case.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 999 for police, fire, or ambulance"
                ),
                fire: EmergencyService(
                    name: "Emergency Services",
                    number: "999",
                    icon: "flame.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 999 for police, fire, or ambulance"
                ),
                childHelpline: EmergencyService(
                    name: "Childline",
                    number: "0800 1111",
                    icon: "person.fill.checkmark",
                    color: JuniorAidColors.safeTouchColor,
                    description: "Free helpline for children"
                ),
                general: EmergencyService(
                    name: "EU Emergency",
                    number: "112",
                    icon: "phone.fill",
                    color: JuniorAidColors.helpPastel,
                    description: "European emergency number"
                )
            )
        ),
        
        // Australia 🇦🇺
        Country(
            id: "AU",
            name: "Australia",
            flagEmoji: "🇦🇺",
            emergencyNumbers: EmergencyNumbers(
                police: EmergencyService(
                    name: "Emergency Services",
                    number: "000",
                    icon: "shield.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 000 for police, fire, or ambulance"
                ),
                ambulance: EmergencyService(
                    name: "Emergency Services",
                    number: "000",
                    icon: "cross.case.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 000 for police, fire, or ambulance"
                ),
                fire: EmergencyService(
                    name: "Emergency Services",
                    number: "000",
                    icon: "flame.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 000 for police, fire, or ambulance"
                ),
                childHelpline: EmergencyService(
                    name: "Kids Helpline",
                    number: "1800 55 1800",
                    icon: "person.fill.checkmark",
                    color: JuniorAidColors.safeTouchColor,
                    description: "Free counselling for kids"
                ),
                general: nil
            )
        ),
        
        // Canada 🇨🇦
        Country(
            id: "CA",
            name: "Canada",
            flagEmoji: "🇨🇦",
            emergencyNumbers: EmergencyNumbers(
                police: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "shield.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                ambulance: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "cross.case.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                fire: EmergencyService(
                    name: "Emergency Services",
                    number: "911",
                    icon: "flame.fill",
                    color: JuniorAidColors.sosRed,
                    description: "Call 911 for police, fire, or ambulance"
                ),
                childHelpline: EmergencyService(
                    name: "Kids Help Phone",
                    number: "1-800-668-6868",
                    icon: "person.fill.checkmark",
                    color: JuniorAidColors.safeTouchColor,
                    description: "Free support for young people"
                ),
                general: nil
            )
        )
    ]
    
    /// Get country by code
    func country(for code: String) -> Country? {
        countries.first { $0.id == code }
    }
    
    /// Search countries by name
    func searchCountries(query: String) -> [Country] {
        guard !query.isEmpty else { return countries }
        return countries.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }
}
