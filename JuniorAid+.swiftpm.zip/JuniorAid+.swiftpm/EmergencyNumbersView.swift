import SwiftUI

// MARK: - Emergency Numbers View
// Display emergency numbers for selected country (OFFLINE)

struct EmergencyNumbersView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    
    let country: Country
    
    @State private var showingExplanation: EmergencyService?
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                colors: [
                    JuniorAidColors.sosRed.opacity(0.15),
                    JuniorAidColors.helpPastel.opacity(0.2),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: Spacing.xLarge) {
                    // Header
                    header
                        .padding(.top, Spacing.medium)
                    
                    // Emergency services
                    emergencyServicesList
                        .padding(.horizontal, Spacing.large)
                    
                    // Safety note
                    safetyNote
                        .padding(.horizontal, Spacing.large)
                        .padding(.bottom, Spacing.xxxLarge)
                }
            }
        }
        .onAppear {
            if accessibility.voiceNarrationEnabled {
                narrator.speak("Emergency numbers for \(country.name)")
            }
        }
        .sheet(item: $showingExplanation) { service in
            serviceExplanationSheet(service)
        }
    }
    
    private var header: some View {
        VStack(spacing: Spacing.small) {
            Text(country.flagEmoji)
                .font(.system(size: 80))
            
            Text(country.name)
                .font(JuniorAidFont.largeTitle)
                .foregroundColor(JuniorAidColors.primaryText)
            
            Text("Emergency Numbers")
                .font(JuniorAidFont.body)
                .foregroundColor(JuniorAidColors.secondaryText)
        }
    }
    
    private var emergencyServicesList: some View {
        VStack(spacing: Spacing.medium) {
            // Police
            emergencyServiceButton(country.emergencyNumbers.police)
                .scaleInTransition(delay: 0.1)
            
            // Ambulance
            emergencyServiceButton(country.emergencyNumbers.ambulance)
                .scaleInTransition(delay: 0.2)
            
            // Fire
            emergencyServiceButton(country.emergencyNumbers.fire)
                .scaleInTransition(delay: 0.3)
            
            // Child Helpline (if available)
            if let childHelpline = country.emergencyNumbers.childHelpline {
                emergencyServiceButton(childHelpline)
                    .scaleInTransition(delay: 0.4)
            }
            
            // General Emergency (if available)
            if let general = country.emergencyNumbers.general {
                emergencyServiceButton(general)
                    .scaleInTransition(delay: 0.5)
            }
        }
    }
    
    private func emergencyServiceButton(_ service: EmergencyService) -> some View {
        Button {
            // DO NOT actually dial in Playground - just show explanation
            HapticManager.shared.heavy()
            showingExplanation = service
            if accessibility.voiceNarrationEnabled {
                narrator.speak("\(service.name): \(service.number)")
            }
        } label: {
            HStack(spacing: Spacing.large) {
                // Icon
                Image(systemName: service.icon)
                    .font(.system(size: 40))
                    .foregroundColor(service.color)
                    .frame(width: 60)
                
                // Service info
                VStack(alignment: .leading, spacing: Spacing.xSmall) {
                    Text(service.name)
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                    
                    Text(service.number)
                        .font(JuniorAidFont.largeTitle)
                        .foregroundColor(service.color)
                }
                
                Spacer()
                
                // Info icon
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(JuniorAidColors.secondaryText.opacity(0.5))
            }
            .padding(Spacing.large)
            .background(
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: CornerRadius.large)
                            .stroke(service.color.opacity(0.3), lineWidth: 2)
                    )
            )
            .juniorAidShadow(Shadows.medium)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private var safetyNote: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: Spacing.small) {
                HStack {
                    Image(systemName: "info.circle.fill")
                        .foregroundColor(JuniorAidColors.helpPastel)
                    Text("Remember")
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                }
                
                Text("Only call these numbers in a real emergency. Stay calm and tell them where you are.")
                    .font(JuniorAidFont.body)
                    .foregroundColor(JuniorAidColors.secondaryText)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
    
    private func serviceExplanationSheet(_ service: EmergencyService) -> some View {
        ZStack {
            JuniorAidColors.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: Spacing.xLarge) {
                // Icon
                Image(systemName: service.icon)
                    .font(.system(size: 100))
                    .foregroundColor(service.color)
                    .scaleInTransition()
                
                // Service name
                Text(service.name)
                    .font(JuniorAidFont.largeTitle)
                    .foregroundColor(JuniorAidColors.primaryText)
                
                // Number
                Text(service.number)
                    .font(JuniorAidFont.title)
                    .foregroundColor(service.color)
                
                // Description
                LiquidGlassCard {
                    Text(service.description)
                        .font(JuniorAidFont.bodyLarge)
                        .foregroundColor(JuniorAidColors.primaryText)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, Spacing.large)
                
                Spacer()
                
                // Close button
                Button {
                    showingExplanation = nil
                } label: {
                    Text("Got it!")
                        .font(JuniorAidFont.buttonLarge)
                        .foregroundColor(.white)
                        .padding(.horizontal, Spacing.xxLarge)
                        .padding(.vertical, Spacing.large)
                        .background(
                            Capsule()
                                .fill(service.color)
                        )
                }
            }
            .padding(Spacing.xLarge)
        }
        .onAppear {
            if accessibility.voiceNarrationEnabled {
                narrator.speak(service.description)
            }
        }
    }
}

#Preview {
    EmergencyNumbersView(country: EmergencyData.shared.countries[0])
        .environment(NavigationCoordinator())
        .environment(VoiceNarrator())
        .environment(AccessibilitySettings())
}
