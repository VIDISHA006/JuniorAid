import SwiftUI

// MARK: - Breathing Orb Component
// Emotion regulation before emergency scenarios

struct BreathingOrb: View {
    @State private var scale: CGFloat = 1.0
    @State private var tapCount = 0
    @State private var isComplete = false
    
    let onComplete: () -> Void
    
    private var breathingDuration: Double {
        // Slows down with each tap: 4s → 5s → 6s → 7s
        return 4.0 + Double(tapCount) * 0.5
    }
    
    private var requiredTaps: Int { 5 }
    
    var body: some View {
        ZStack {
            // Background
            JuniorAidColors.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: Spacing.xLarge) {
                Spacer()
                
                // Instructions
                Text("Take a deep breath")
                    .font(JuniorAidFont.title)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .opacity(isComplete ? 0 : 1)
                
                Text("Tap the orb \(requiredTaps - tapCount) more times")
                    .font(JuniorAidFont.body)
                    .foregroundColor(JuniorAidColors.secondaryText)
                    .opacity(isComplete ? 0 : 1)
                
                // Breathing Orb
                ZStack {
                    // Outer glow
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    JuniorAidColors.mintWhisper.opacity(0.6),
                                    JuniorAidColors.softSky.opacity(0.4),
                                    Color.clear
                                ],
                                center: .center,
                                startRadius: 50,
                                endRadius: 200
                            )
                        )
                        .frame(width: 400, height: 400)
                        .scaleEffect(scale)
                        .blur(radius: 20)
                    
                    // Main orb
                    Circle()
                        .fill(JuniorAidColors.breathingOrbGradient)
                        .frame(width: 180, height: 180)
                        .scaleEffect(scale)
                        .overlay(
                            Circle()
                                .stroke(JuniorAidColors.softSky, lineWidth: 3)
                                .scaleEffect(scale)
                        )
                        .shadow(
                            color: JuniorAidColors.softSky.opacity(0.5),
                            radius: 30,
                            y: 10
                        )
                    
                    // Tap count indicator
                    VStack(spacing: Spacing.xSmall) {
                        ForEach(0..<requiredTaps, id: \.self) { index in
                            Circle()
                                .fill(index < tapCount ?
                                     JuniorAidColors.mintWhisper :
                                     JuniorAidColors.glassStroke)
                                .frame(width: 12, height: 12)
                        }
                    }
                }
                .onTapGesture {
                    handleTap()
                }
                
                Spacer()
                
                // Completion message
                if isComplete {
                    VStack(spacing: Spacing.medium) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 60))
                            .foregroundColor(JuniorAidColors.mintWhisper)
                        
                        Text("You're calm and ready")
                            .font(JuniorAidFont.title)
                            .foregroundColor(JuniorAidColors.primaryText)
                    }
                    .transition(.scale.combined(with: .opacity))
                }
                
                Spacer()
            }
            .padding(Spacing.large)
        }
        .onAppear {
            startBreathing()
        }
    }
    
    private func startBreathing() {
        withAnimation(
            .easeInOut(duration: breathingDuration)
            .repeatForever(autoreverses: true)
        ) {
            scale = 1.3
        }
    }
    
    private func handleTap() {
        guard tapCount < requiredTaps else { return }
        
        // Haptic feedback
        HapticManager.shared.light()
        
        // Increment tap count
        tapCount += 1
        
        // Restart breathing with slower duration
        scale = 1.0
        withAnimation(
            .easeInOut(duration: breathingDuration)
            .repeatForever(autoreverses: true)
        ) {
            scale = 1.3
        }
        
        // Check if complete
        if tapCount >= requiredTaps {
            completeExercise()
        }
    }
    
    private func completeExercise() {
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            isComplete = true
            scale = 1.0
        }
        
        // Proceed after short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            onComplete()
        }
    }
}

// MARK: - Calm Check Component
// Simple breathing prompt before scenarios

struct CalmCheck: View {
    @State private var isBreathing = false
    @State private var breathScale: CGFloat = 1.0
    
    let onContinue: () -> Void
    
    var body: some View {
        VStack(spacing: Spacing.xLarge) {
            Spacer()
            
            // Breathing circle
            ZStack {
                Circle()
                    .fill(JuniorAidColors.breathingOrbGradient)
                    .frame(width: 150, height: 150)
                    .scaleEffect(breathScale)
                    .shadow(
                        color: JuniorAidColors.softSky.opacity(0.4),
                        radius: 20,
                        y: 10
                    )
                
                Text(breathScale > 1.1 ? "Breathe Out" : "Breathe In")
                    .font(JuniorAidFont.body)
                    .foregroundColor(JuniorAidColors.primaryText)
            }
            .onAppear {
                withAnimation(
                    .easeInOut(duration: 4.0)
                    .repeatForever(autoreverses: true)
                ) {
                    breathScale = 1.3
                }
            }
            
            Text("Take a deep breath")
                .font(JuniorAidFont.title)
                .foregroundColor(JuniorAidColors.primaryText)
            
            Spacer()
            
            // Continue button
            Button {
                onContinue()
            } label: {
                Text("I'm Ready")
                    .font(JuniorAidFont.buttonLarge)
                    .foregroundColor(JuniorAidColors.deepIndigo)
                    .padding(.horizontal, Spacing.xxLarge)
                    .padding(.vertical, Spacing.large)
                    .background(
                        Capsule()
                            .fill(JuniorAidColors.mintWhisper)
                    )
                    .shadow(
                        color: .black.opacity(0.08),
                        radius: 20,
                        y: 10
                    )
            }
            .padding(.bottom, Spacing.xxxLarge)
        }
        .padding(Spacing.large)
        .background(JuniorAidColors.backgroundGradient.ignoresSafeArea())
    }
}

#Preview("Breathing Orb") {
    BreathingOrb {
        print("Breathing complete")
    }
}

#Preview("Calm Check") {
    CalmCheck {
        print("Continue")
    }
}
