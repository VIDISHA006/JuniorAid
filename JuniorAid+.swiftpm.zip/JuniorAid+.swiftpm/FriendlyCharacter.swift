import SwiftUI

// MARK: - Friendly Character
// Gender-neutral, animated mascot for JuniorAid+

struct FriendlyCharacter: View {
    @State private var isWaving = false
    @State private var isBlinking = false
    @State private var isCelebrating = false
    @State private var blinkTask: Task<Void, Never>?
    
    let mood: CharacterMood
    let size: CGFloat
    
    init(mood: CharacterMood = .happy, size: CGFloat = 180) {
        self.mood = mood
        self.size = size
    }
    
    var body: some View {
        ZStack {
            // Body
            characterBody
            
            // Face
            characterFace
            
            // Accessories (based on mood)
            if isCelebrating {
                celebrationStars
            }
        }
        .frame(width: size, height: size)
        .onAppear {
            startIdleAnimations()
        }
        .onDisappear {
            // CRITICAL FIX: Cancel infinite loop Task to prevent memory leaks
            blinkTask?.cancel()
        }
    }
    
    private var characterBody: some View {
        ZStack {
            // Main body circle
            Circle()
                .fill(
                    LinearGradient(
                        colors: [
                            JuniorAidColors.characterSkin1,
                            JuniorAidColors.characterSkin1.opacity(0.8)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size * 0.7, height: size * 0.7)
                .juniorAidShadow(Shadows.soft)
            
            // Outfit
            RoundedRectangle(cornerRadius: size * 0.15)
                .fill(JuniorAidColors.characterOutfit)
                .frame(width: size * 0.5, height: size * 0.35)
                .offset(y: size * 0.25)
        }
    }
    
    private var characterFace: some View {
        VStack(spacing: size * 0.08) {
            // Eyes
            HStack(spacing: size * 0.15) {
                eye
                eye
            }
            .offset(y: -size * 0.1)
            
            // Mouth (changes with mood)
            mouth
                .offset(y: -size * 0.05)
        }
    }
    
    private var eye: some View {
        Circle()
            .fill(JuniorAidColors.primaryText)
            .frame(
                width: isBlinking ? size * 0.08 : size * 0.08,
                height: isBlinking ? size * 0.02 : size * 0.08
            )
            .animation(.snappy(duration: 0.15), value: isBlinking) // iOS 26: Spring physics
    }
    
    private var mouth: some View {
        Group {
            switch mood {
            case .happy:
                // Smiling arc
                Arc(startAngle: .degrees(0), endAngle: .degrees(180))
                    .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                    .frame(width: size * 0.25, height: size * 0.15)
                    .rotationEffect(.degrees(180))
                
            case .encouraging:
                // Gentle smile
                Arc(startAngle: .degrees(20), endAngle: .degrees(160))
                    .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                    .frame(width: size * 0.22, height: size * 0.12)
                    .rotationEffect(.degrees(180))
                
            case .celebrating:
                // Wide smile
                ZStack {
                    Arc(startAngle: .degrees(0), endAngle: .degrees(180))
                        .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                        .frame(width: size * 0.28, height: size * 0.18)
                        .rotationEffect(.degrees(180))
                }
            }
        }
    }
    
    private var celebrationStars: some View {
        ZStack {
            ForEach(0..<6) { index in
                Image(systemName: "star.fill")
                    .font(.system(size: size * 0.12))
                    .foregroundColor(JuniorAidColors.encouragementYellow)
                    .offset(
                        x: cos(Double(index) * .pi / 3) * size * 0.6,
                        y: sin(Double(index) * .pi / 3) * size * 0.6
                    )
                    .rotationEffect(.degrees(isCelebrating ? 360 : 0))
            }
        }
    }
    
    private func startIdleAnimations() {
        // Gentle wave animation - iOS 26: Spring physics
        withAnimation(
            .smooth(duration: 2.0)
            .repeatForever(autoreverses: true)
        ) {
            isWaving = true
        }
        
        // Blinking animation with proper Task management
        blinkTask = Task { @MainActor in
            while !Task.isCancelled {
                do {
                    // Wait for random interval between 3-5 seconds
                    let interval = UInt64(Double.random(in: 3.0...5.0) * 1_000_000_000)
                    try await Task.sleep(nanoseconds: interval)
                    
                    guard !Task.isCancelled else { break }
                    
                    // Blink close
                    withAnimation(.snappy(duration: 0.15)) {
                        isBlinking = true
                    }
                    
                    // Keep closed briefly
                    try await Task.sleep(nanoseconds: 150_000_000) // 0.15s
                    
                    guard !Task.isCancelled else { break }
                    
                    // Blink open
                    withAnimation(.snappy(duration: 0.15)) {
                        isBlinking = false
                    }
                } catch {
                    // Task was cancelled
                    break
                }
            }
        }
        
        // Celebration animation if celebrating - iOS 26: Spring physics
        if mood == .celebrating {
            withAnimation(
                .bouncy(duration: 4.0)
                .repeatForever(autoreverses: false)
            ) {
                isCelebrating = true
            }
        }
    }
    
    func celebrate() {
        withAnimation(.bouncy) { // iOS 26: Use preset instead of custom
            isCelebrating = true
        }
        
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(2))
            withAnimation(.smooth) {
                isCelebrating = false
            }
        }
    }
}

// MARK: - Character Mood
enum CharacterMood {
    case happy
    case encouraging
    case celebrating
}

// MARK: - Arc Shape
struct Arc: Shape {
    var startAngle: Angle
    var endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addArc(
            center: CGPoint(x: rect.midX, y: rect.midY),
            radius: rect.width / 2,
            startAngle: startAngle,
            endAngle: endAngle,
            clockwise: false
        )
        return path
    }
}
