import SwiftUI




struct FriendlyCharacter: View {
    @State private var isWaving = false
    @State private var isBlinking = false
    @State private var isCelebrating = false
    @State private var blinkTask: Task<Void, Never>?
    
    let mood: CharacterMood
    let size: CGFloat
    
    init(mood: CharacterMood = .happy, size: CGFloat = 180) {
        self.mood = mood
        self.size = size
    }
    
    var body: some View {
        ZStack {
            
            characterBody
            
            
            characterFace
            
            
            if isCelebrating {
                celebrationStars
            }
        }
        .frame(width: size, height: size)
        .onAppear {
            startIdleAnimations()
        }
        .onDisappear {
            
            blinkTask?.cancel()
        }
    }
    
    private var characterBody: some View {
        ZStack {
            
            Circle()
                .fill(
                    LinearGradient(
                        colors: [
                            JuniorAidColors.characterSkin1,
                            JuniorAidColors.characterSkin1.opacity(0.8)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size * 0.7, height: size * 0.7)
                .juniorAidShadow(Shadows.soft)
            
            
            RoundedRectangle(cornerRadius: size * 0.15)
                .fill(JuniorAidColors.characterOutfit)
                .frame(width: size * 0.5, height: size * 0.35)
                .offset(y: size * 0.25)
        }
    }
    
    private var characterFace: some View {
        VStack(spacing: size * 0.08) {
            
            HStack(spacing: size * 0.15) {
                eye
                eye
            }
            .offset(y: -size * 0.1)
            
            
            mouth
                .offset(y: -size * 0.05)
        }
    }
    
    private var eye: some View {
        Circle()
            .fill(JuniorAidColors.primaryText)
            .frame(
                width: isBlinking ? size * 0.08 : size * 0.08,
                height: isBlinking ? size * 0.02 : size * 0.08
            )
            .animation(.snappy(duration: 0.15), value: isBlinking) 
    }
    
    private var mouth: some View {
        Group {
            switch mood {
            case .happy:
                
                Arc(startAngle: .degrees(0), endAngle: .degrees(180))
                    .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                    .frame(width: size * 0.25, height: size * 0.15)
                    .rotationEffect(.degrees(180))
                
            case .encouraging:
                
                Arc(startAngle: .degrees(20), endAngle: .degrees(160))
                    .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                    .frame(width: size * 0.22, height: size * 0.12)
                    .rotationEffect(.degrees(180))
                
            case .celebrating:
                
                ZStack {
                    Arc(startAngle: .degrees(0), endAngle: .degrees(180))
                        .stroke(JuniorAidColors.primaryText, lineWidth: 3)
                        .frame(width: size * 0.28, height: size * 0.18)
                        .rotationEffect(.degrees(180))
                }
            }
        }
    }
    
    private var celebrationStars: some View {
        ZStack {
            ForEach(0..<6) { index in
                Image(systemName: "star.fill")
                    .font(.system(size: size * 0.12))
                    .foregroundColor(JuniorAidColors.encouragementYellow)
                    .offset(
                        x: cos(Double(index) * .pi / 3) * size * 0.6,
                        y: sin(Double(index) * .pi / 3) * size * 0.6
                    )
                    .rotationEffect(.degrees(isCelebrating ? 360 : 0))
            }
        }
    }
    
    private func startIdleAnimations() {
        
        withAnimation(
            .smooth(duration: 2.0)
            .repeatForever(autoreverses: true)
        ) {
            isWaving = true
        }
        
        
        blinkTask = Task { @MainActor in
            while !Task.isCancelled {
                do {
                    
                    let interval = UInt64(Double.random(in: 3.0...5.0) * 1_000_000_000)
                    try await Task.sleep(nanoseconds: interval)
                    
                    guard !Task.isCancelled else { break }
                    
                    
                    withAnimation(.snappy(duration: 0.15)) {
                        isBlinking = true
                    }
                    
                    
                    try await Task.sleep(nanoseconds: 150_000_000) 
                    
                    guard !Task.isCancelled else { break }
                    
                    
                    withAnimation(.snappy(duration: 0.15)) {
                        isBlinking = false
                    }
                } catch {
                    
                    break
                }
            }
        }
        
        
        if mood == .celebrating {
            withAnimation(
                .bouncy(duration: 4.0)
                .repeatForever(autoreverses: false)
            ) {
                isCelebrating = true
            }
        }
    }
    
    func celebrate() {
        withAnimation(.bouncy) { 
            isCelebrating = true
        }
        
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(2))
            withAnimation(.smooth) {
                isCelebrating = false
            }
        }
    }
}


enum CharacterMood {
    case happy
    case encouraging
    case celebrating
}


struct Arc: Shape {
    var startAngle: Angle
    var endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addArc(
            center: CGPoint(x: rect.midX, y: rect.midY),
            radius: rect.width / 2,
            startAngle: startAngle,
            endAngle: endAngle,
            clockwise: false
        )
        return path
    }
}
