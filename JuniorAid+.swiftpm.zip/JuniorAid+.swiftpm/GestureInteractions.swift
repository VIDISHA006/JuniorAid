import SwiftUI





enum GestureType: Equatable {
    case pressAndHold(seconds: Int)
    case rhythmTap(count: Int, bpm: Int)
    case swipePath(direction: SwipeDirection)
    case swipeSequence(directions: [SwipeDirection])
    case holdToActivate(seconds: Int)
    case dragToPosition(targetArea: String)
    case dragAndHold(item: String, duration: Double)
    case tap
}

enum SwipeDirection {
    case down    
    case up      
    case left    
    case right   
}




struct PressureGesture: View {
    let duration: Int 
    let onComplete: () -> Void
    
    @State private var isPressed = false
    @State private var pressProgress: CGFloat = 0
    @State private var timer: Timer?
    
    var body: some View {
        VStack(spacing: Spacing.medium) {
            
            
            ZStack {
                
                Circle()
                    .fill(Color.white.opacity(0.001)) 
                    .contentShape(Circle()) 
                    .frame(width: 220, height: 220) 
                
                
                Circle()
                    .trim(from: 0, to: pressProgress)
                    .stroke(
                        JuniorAidColors.mintWhisper,
                        style: StrokeStyle(lineWidth: 10, lineCap: .round)
                    )
                    .frame(width: 180, height: 180)
                    .rotationEffect(.degrees(-90))
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        if !isPressed {
                            startPressing()
                        }
                    }
                    .onEnded { _ in
                        stopPressing()
                    }
            )
            
            Spacer()
            
            
            if isPressed {
                Text("\(Int((1.0 - pressProgress) * Double(duration)))s")
                    .font(JuniorAidFont.largeTitle) 
                    .foregroundColor(JuniorAidColors.primaryText)
                    .transition(.opacity)
            } else {
                Text(" ") 
                    .font(JuniorAidFont.largeTitle)
            }
        }
        .frame(height: 300) 
        .frame(maxWidth: .infinity)
    }
    
    private func startPressing() {
        isPressed = true
        HapticManager.shared.light()
        
        
        Task { @MainActor in
            
            try? await Task.sleep(for: .milliseconds(100))
            
            while isPressed && pressProgress < 1.0 {
                withAnimation(.linear(duration: 0.1)) {
                    pressProgress += 0.1 / Double(duration)
                }
                
                if pressProgress >= 1.0 {
                    completeGesture()
                    break
                }
                
                try? await Task.sleep(for: .milliseconds(100))
            }
        }
    }
    
    private func stopPressing() {
        isPressed = false
        timer?.invalidate()
        timer = nil
        
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            pressProgress = 0
        }
    }
    
    private func completeGesture() {
        timer?.invalidate()
        timer = nil
        HapticManager.shared.success()
        
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            pressProgress = 1.0
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            onComplete()
        }
    }
}




struct RhythmTapGesture: View {
    let count: Int
    let bpm: Int
    var color: Color = JuniorAidColors.softSky 
    let onComplete: () -> Void
    
    @State private var taps = 0
    @State private var isAnimating = false
    @State private var showMetronome = true
    
    private var interval: Double {
        60.0 / Double(bpm)
    }
    
    var body: some View {
        VStack(spacing: Spacing.large) {
            
            Text("Tap \(count) times with the rhythm")
                .font(JuniorAidFont.headline)
                .foregroundColor(JuniorAidColors.primaryText)
                .multilineTextAlignment(.center)
            
            
            MetronomeView(bpm: bpm)
                .frame(height: 30)
                .opacity(showMetronome ? 1 : 0)
            
            
            Button {
                handleTap()
            } label: {
                ZStack(alignment: .bottomTrailing) {
                    
                    Color.white.opacity(0.01)
                        .frame(width: 250, height: 250)
                    
                    
                    Text("\(taps)/\(count)")
                        .font(JuniorAidFont.title)
                        .foregroundColor(JuniorAidColors.primaryText)
                        .padding()
                }
            }
            .buttonStyle(PlainButtonStyle())
        }
        .frame(height: 300)
        .frame(maxWidth: .infinity)
    }
    
    private func handleTap() {
        HapticManager.shared.light()
        
        withAnimation(.spring(response: 0.2, dampingFraction: 0.5)) {
            isAnimating = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                isAnimating = false
            }
        }
        
        taps += 1
        
        if taps >= count {
            completeGesture()
        }
    }
    
    private func completeGesture() {
        HapticManager.shared.success()
        showMetronome = false
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            onComplete()
        }
    }
}


struct MetronomeView: View {
    let bpm: Int
    @State private var beat = false
    
    var body: some View {
        HStack(spacing: Spacing.medium) {
            ForEach(0..<5, id: \.self) { index in
                Circle()
                    .fill(beat && index % 2 == 0 ? JuniorAidColors.mintWhisper : JuniorAidColors.glassSlate)
                    .frame(width: 16, height: 16)
            }
        }
        .onAppear {
            startMetronome()
        }
    }
    
    private func startMetronome() {
        let intervalInSeconds = 60.0 / Double(bpm)
        let intervalInNanoseconds = UInt64(intervalInSeconds * 1_000_000_000)
        
        Task { @MainActor in
            while true { 
                try? await Task.sleep(nanoseconds: intervalInNanoseconds)
                withAnimation(.easeInOut(duration: 0.1)) {
                    beat.toggle()
                }
            }
        }
    }
}




struct SwipePathGesture: View {
    let direction: SwipeDirection
    let instruction: String
    let onComplete: () -> Void
    
    @State private var swipeProgress: CGFloat = 0
    @State private var particleOffset: CGFloat = 0
    
    var body: some View {
        VStack(spacing: Spacing.large) {
            
            Text(instruction)
                .font(JuniorAidFont.headline)
                .foregroundColor(JuniorAidColors.primaryText)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            
            ZStack {
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .fill(JuniorAidColors.glassSlate.opacity(0.5))
                    .frame(width: 260, height: 200)
                
                
                if direction == .down {
                    VStack {
                        Rectangle()
                            .fill(JuniorAidColors.softSky.opacity(0.6))
                            .frame(height: 200 * swipeProgress)
                        Spacer()
                    }
                    .frame(width: 260, height: 200)
                }
                
                
                VStack(spacing: Spacing.medium) {
                    if direction == .down {
                        ForEach(0..<2, id: \.self) { index in
                            Image(systemName: "chevron.down")
                                .font(.system(size: 30))
                                .foregroundColor(JuniorAidColors.deepIndigo.opacity(0.3))
                                .offset(y: particleOffset)
                        }
                    }
                }
            }
            .frame(width: 260, height: 200)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        handleSwipe(value)
                    }
                    .onEnded { _ in
                        checkCompletion()
                    }
            )
        }
        .frame(height: 300)
        .frame(maxWidth: .infinity)
        .onAppear {
            startParticleAnimation()
        }
    }
    
    private func handleSwipe(_ value: DragGesture.Value) {
        switch direction {
        case .down:
            let progress = max(0, min(1, value.translation.height / 120))
            withAnimation(.linear(duration: 0.1)) {
                swipeProgress = progress
            }
        case .up:
            let progress = max(0, min(1, -value.translation.height / 120))
            withAnimation(.linear(duration: 0.1)) {
                swipeProgress = progress
            }
        case .right:
            let progress = max(0, min(1, value.translation.width / 120))
            withAnimation(.linear(duration: 0.1)) {
                swipeProgress = progress
            }
        case .left:
            let progress = max(0, min(1, -value.translation.width / 120))
            withAnimation(.linear(duration: 0.1)) {
                swipeProgress = progress
            }
        }
    }
    
    private func checkCompletion() {
        if swipeProgress >= 0.9 {
            completeGesture()
        } else {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                swipeProgress = 0
            }
        }
    }
    
    private func completeGesture() {
        HapticManager.shared.success()
        onComplete()
    }
    
    private func startParticleAnimation() {
        withAnimation(
            .easeInOut(duration: 1.5)
            .repeatForever(autoreverses: false)
        ) {
            particleOffset = 100
        }
    }
}




struct SwipeSequenceGesture: View {
    let directions: [SwipeDirection]
    let instruction: String
    let onComplete: () -> Void
    
    @State private var currentStep = 0
    @State private var swipeProgress: CGFloat = 0
    @State private var particleOffset: CGFloat = 0
    
    private var currentDirection: SwipeDirection {
        directions[currentStep]
    }
    
    var body: some View {
        VStack(spacing: Spacing.large) {
            
            VStack(spacing: Spacing.xSmall) {
                Text(instruction)
                    .font(JuniorAidFont.headline)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .multilineTextAlignment(.center)
                
                Text("Step \(currentStep + 1) of \(directions.count)")
                    .font(JuniorAidFont.caption)
                    .foregroundColor(JuniorAidColors.secondaryText)
            }
            .padding(.horizontal)
            .padding(.bottom, Spacing.medium) 
            
            
            ZStack {
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .fill(JuniorAidColors.glassSlate.opacity(0.3)) 
                    .frame(width: 200, height: 140) 
                
                
                progressView
                
                
                arrowGuideView
            }
            .frame(width: 260, height: 200)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        handleSwipe(value)
                    }
                    .onEnded { _ in
                        checkCompletion()
                    }
            )
        }
        .frame(height: 300)
        .frame(maxWidth: .infinity)
        .onAppear {
            startParticleAnimation()
        }
    }
    
    @ViewBuilder
    private var progressView: some View {
        Group {
            if currentDirection == .down {
                VStack {
                    Rectangle()
                        .fill(JuniorAidColors.softSky.opacity(0.6))
                        .frame(height: 200 * swipeProgress)
                    Spacer()
                }
                .frame(width: 260, height: 200)
            } else if currentDirection == .up {
                VStack {
                    Spacer()
                    Rectangle()
                        .fill(JuniorAidColors.softSky.opacity(0.6))
                        .frame(height: 200 * swipeProgress)
                }
                .frame(width: 260, height: 200)
            } else if currentDirection == .right {
                HStack {
                    Rectangle()
                        .fill(JuniorAidColors.softSky.opacity(0.6))
                        .frame(width: 260 * swipeProgress)
                    Spacer()
                }
                .frame(width: 260, height: 200)
            } else if currentDirection == .left {
                HStack {
                    Spacer()
                    Rectangle()
                        .fill(JuniorAidColors.softSky.opacity(0.6))
                        .frame(width: 260 * swipeProgress)
                }
                .frame(width: 260, height: 200)
            }
        }
    }
    
    @ViewBuilder
    private var arrowGuideView: some View {
        let arrowIcon: String = {
            switch currentDirection {
            case .down: return "chevron.down"
            case .up: return "chevron.up"
            case .right: return "chevron.right"
            case .left: return "chevron.left"
            }
        }()
        
        let isVertical = currentDirection == .up || currentDirection == .down
        
        if isVertical {
            VStack(spacing: Spacing.medium) {
                ForEach(0..<2, id: \.self) { index in
                    Image(systemName: arrowIcon)
                        .font(.system(size: 30))
                        .foregroundColor(JuniorAidColors.deepIndigo.opacity(0.3))
                        .offset(y: particleOffset)
                }
            }
        } else {
            HStack(spacing: Spacing.medium) {
                ForEach(0..<2, id: \.self) { index in
                    Image(systemName: arrowIcon)
                        .font(.system(size: 30))
                        .foregroundColor(JuniorAidColors.deepIndigo.opacity(0.3))
                        .offset(x: particleOffset)
                }
            }
            .offset(y: -40) 
        }
    }
    
    private func handleSwipe(_ value: DragGesture.Value) {
        switch currentDirection {
        case .down:
            let progress = max(0, min(1, value.translation.height / 150))
            withAnimation(.linear(duration: 0.1)) { swipeProgress = progress }
        case .up:
            let progress = max(0, min(1, -value.translation.height / 150))
            withAnimation(.linear(duration: 0.1)) { swipeProgress = progress }
        case .right:
            let progress = max(0, min(1, value.translation.width / 150))
            withAnimation(.linear(duration: 0.1)) { swipeProgress = progress }
        case .left:
            let progress = max(0, min(1, -value.translation.width / 150))
            withAnimation(.linear(duration: 0.1)) { swipeProgress = progress }
        }
    }
    
    private func checkCompletion() {
        if swipeProgress >= 0.8 {
            HapticManager.shared.light()
            
            if currentStep < directions.count - 1 {
                
                withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                    currentStep += 1
                    swipeProgress = 0
                }
            } else {
                
                completeGesture()
            }
        } else {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                swipeProgress = 0
            }
        }
    }
    
    private func completeGesture() {
        HapticManager.shared.success()
        onComplete()
    }
    
    private func startParticleAnimation() {
        withAnimation(
            .easeInOut(duration: 1.5)
            .repeatForever(autoreverses: false)
        ) {
            particleOffset = 60
        }
    }
}




struct HoldToActivateGesture: View {
    let seconds: Int
    let icon: String
    let label: String
    let onComplete: () -> Void
    
    @State private var isHolding = false
    @State private var progress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: Spacing.large) {
            Text("Hold to \(label)")
                .font(JuniorAidFont.headline)
                .foregroundColor(JuniorAidColors.primaryText)
                .multilineTextAlignment(.center)
            
            ZStack {
                
                Circle()
                    .stroke(JuniorAidColors.glassSlate, lineWidth: 8)
                    .frame(width: 160, height: 160)
                
                
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(
                        JuniorAidColors.mintWhisper,
                        style: StrokeStyle(lineWidth: 8, lineCap: .round)
                    )
                    .frame(width: 160, height: 160)
                    .rotationEffect(.degrees(-90))
                
                
                VStack(spacing: Spacing.small) {
                    Image(systemName: icon)
                        .font(.system(size: 50))
                        .foregroundColor(JuniorAidColors.deepIndigo)
                        .scaleEffect(isHolding ? 0.95 : 1.0)
                    
                    if isHolding {
                        Text("\(Int((1.0 - progress) * Double(seconds)))s")
                            .font(JuniorAidFont.bodyLarge)
                            .foregroundColor(JuniorAidColors.secondaryText)
                    }
                }
            }
            .contentShape(Circle())
            .onLongPressGesture(minimumDuration: Double(seconds), maximumDistance: 50) {
                completeGesture()
            } onPressingChanged: { pressing in
                handlePressChange(pressing)
            }
        }
        .frame(height: 300)
        .frame(maxWidth: .infinity)
    }
    
    private func handlePressChange(_ pressing: Bool) {
        if pressing {
            isHolding = true
            HapticManager.shared.light()
            
            withAnimation(.linear(duration: Double(seconds))) {
                progress = 1.0
            }
        } else {
            isHolding = false
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                progress = 0
            }
        }
    }
    
    private func completeGesture() {
        HapticManager.shared.success()
        onComplete()
    }
}




struct TapInteraction: View {
    let icon: String
    let label: String
    let onComplete: () -> Void
    
    @State private var isAnimating = false
    
    var body: some View {
        Button(action: {
            HapticManager.shared.success()
            onComplete()
        }) {
            ZStack {
                
                Color.black.opacity(0.001)
                
                if !icon.isEmpty {
                    VStack(spacing: Spacing.large) {
                        if !label.isEmpty {
                            Text("Tap to \(label)")
                                .font(JuniorAidFont.headline)
                                .foregroundColor(JuniorAidColors.primaryText)
                                .multilineTextAlignment(.center)
                        }
                        
                        ZStack {
                            Circle()
                                .fill(JuniorAidColors.softSky.opacity(0.1))
                                .frame(width: 150, height: 150)
                            
                            Image(systemName: icon)
                                .font(.system(size: 50))
                                .foregroundColor(JuniorAidColors.deepIndigo)
                                .scaleEffect(isAnimating ? 1.05 : 1.0)
                                .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: isAnimating)
                            
                            Circle()
                                .strokeBorder(JuniorAidColors.deepIndigo.opacity(0.2), lineWidth: 3)
                                .frame(width: 160, height: 160)
                        }
                    }
                }
            }
            .frame(height: 300)
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(ScaleButtonStyle())
        .onAppear {
            isAnimating = true
        }
    }
}

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

#Preview("Pressure Gesture") {
    PressureGesture(duration: 10) {
        print("Complete!")
    }
}

#Preview("Rhythm Tap") {
    RhythmTapGesture(count: 5, bpm: 100) {
        print("Complete!")
    }
}

#Preview("Swipe Path") {
    SwipePathGesture(direction: .down, instruction: "Swipe down for cooling water") {
        print("Complete!")
    }
}

#Preview("Hold to Activate") {
    HoldToActivateGesture(seconds: 3, icon: "phone.fill", label: "call for help") {
        print("Complete!")
    }
}




struct DragAndHoldGesture: View {
    let item: String
    let duration: Double
    let onComplete: () -> Void
    
    @State private var dragOffset: CGSize = .zero
    @State private var isDropped = false
    @State private var isHolding = false
    @State private var holdProgress: CGFloat = 0
    @State private var pulseAnim = false
    
    
    private let targetRadius: CGFloat = 60
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                
                if !isDropped {
                    Circle()
                        .stroke(JuniorAidColors.mintWhisper, style: StrokeStyle(lineWidth: 3, dash: [10, 5]))
                        .frame(width: 120, height: 120)
                        .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                        .opacity(pulseAnim ? 1.0 : 0.5)
                        .onAppear {
                            withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                                pulseAnim = true
                            }
                        }
                    
                    Text((item == "water_droplet" || item == "drop.fill") ? "Drag water here" : "Drag cloth here")
                        .font(JuniorAidFont.caption)
                        .foregroundColor(JuniorAidColors.secondaryText)
                        .position(x: geometry.size.width / 2, y: geometry.size.height / 2 + 80)
                }
                
                
                if !isDropped {
                    
                    let isSymbol = item.contains(".") || item == "water_droplet"
                    
                    Group {
                        if isSymbol {
                            
                            ZStack {
                                Circle()
                                    .fill(JuniorAidColors.softSky.opacity(0.3))
                                    .frame(width: 100, height: 100)
                                    .scaleEffect(pulseAnim ? 1.1 : 1.0)
                                
                                Image(systemName: (item == "water_droplet" || item == "drop.fill") ? "drop.fill" : item)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 60, height: 60)
                                    .foregroundColor((item == "water_droplet" || item == "drop.fill") ? .blue : JuniorAidColors.deepIndigo)
                            }
                        } else {
                            
                            Image(item)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100, height: 100)
                        }
                    }
                    
                    .position(
                        x: item == "clean_cloth_tool" ? geometry.size.width * 0.85 : geometry.size.width / 2,
                        y: geometry.size.height - 80
                    )
                    .offset(dragOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                dragOffset = value.translation
                            }
                            .onEnded { value in
                                let endPos = CGPoint(
                                    x: (geometry.size.width / 2) + value.translation.width,
                                    y: (geometry.size.height - 80) + value.translation.height
                                )
                                
                                let distance = hypot(
                                    endPos.x - geometry.size.width / 2,
                                    endPos.y - geometry.size.height / 2
                                )
                                    
                                    if distance < targetRadius {
                                        
                                        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                            isDropped = true
                                            dragOffset = .zero
                                        }
                                        HapticManager.shared.light()
                                        
                                        
                                        if duration == 0 {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                                onComplete()
                                            }
                                        }
                                    
                                    withAnimation(.spring()) {
                                        dragOffset = .zero
                                    }
                                }
                            }
                    )
                    .onTapGesture {
                        
                        if !isDropped {
                            HapticManager.shared.light()
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                isDropped = true
                                dragOffset = .zero
                            }
                        }
                    }
                }
                
                
                if isDropped {
                    VStack(spacing: Spacing.medium) {
                        
                        if duration > 0 {
                            if isHolding {
                                CountdownText(duration: duration, progress: holdProgress)
                            } else {
                                Text((item == "water_droplet" || item == "drop.fill") ? "Pour water and wash" : "Hold to apply pressure!")
                                    .font(JuniorAidFont.headline)
                                    .foregroundColor(JuniorAidColors.primaryText)
                                    .padding(.top, -60)
                                    .opacity(0.5)
                            }
                        } else {
                             Text("Tap to wrap!")
                                .font(JuniorAidFont.headline)
                                .foregroundColor(JuniorAidColors.primaryText)
                                .padding(.top, -60)
                                .onTapGesture {
                                    HapticManager.shared.light()
                                    onComplete()
                                }
                        }
                        
                        ZStack {
                            
                            if item.contains(".") || item == "water_droplet" {
                                ZStack {
                                    Circle()
                                        .fill(JuniorAidColors.softSky.opacity(0.3))
                                        .frame(width: 120, height: 120)
                                    
                                    Image(systemName: (item == "water_droplet" || item == "drop.fill") ? "drop.fill" : item)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 70, height: 70)
                                        .foregroundColor((item == "water_droplet" || item == "drop.fill") ? .blue : JuniorAidColors.deepIndigo)
                                }
                                .scaleEffect(isHolding ? 0.9 : 1.0)
                            } else {
                                Image(item)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 120, height: 120) 
                                    .scaleEffect(isHolding ? 0.9 : 1.0)
                                    .onTapGesture {
                                        if item == "clean_cloth_tool" {
                                            HapticManager.shared.light()
                                            onComplete()
                                        }
                                    }
                            }
                            
                            
                            if isHolding && duration > 0 {
                                Circle()
                                    .trim(from: 0, to: holdProgress)
                                    .stroke(JuniorAidColors.mintWhisper, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                                    .frame(width: 140, height: 140)
                                    .rotationEffect(.degrees(-90))
                            }
                        }
                        .contentShape(Circle()) 
                        .onLongPressGesture(minimumDuration: duration, maximumDistance: 50) {
                            if duration > 0 {
                                completeGesture()
                            }
                        } onPressingChanged: { pressing in
                            if duration > 0 {
                                handlePressChange(pressing)
                            }
                        }
                    }
                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .frame(height: 350) 
    }
    
    private func handlePressChange(_ pressing: Bool) {
        if pressing {
            isHolding = true
            HapticManager.shared.light()
            withAnimation(.linear(duration: duration)) {
                holdProgress = 1.0
            }
        } else {
            isHolding = false
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                holdProgress = 0
            }
        }
    }
    
    private func completeGesture() {
        HapticManager.shared.success()
        onComplete()
    }
}


struct CountdownText: View, Animatable {
    var duration: Double
    var progress: Double
    
    nonisolated var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }
    
    var body: some View {
        let remainingSeconds = max(1, Int(ceil((1.0 - progress) * duration)))
        
        return Text("\(remainingSeconds)s")
            .font(JuniorAidFont.largeTitle.bold())
            .foregroundColor(JuniorAidColors.primaryText)
            .padding(.top, -60)
            .shadow(color: .white.opacity(0.8), radius: 2)
    }
}
