import SwiftUI



struct HomeView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    @State private var showContent = false
    @State private var showOnboarding = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: AppSpacing.xxxLarge) {
                
                heroSection
                    .padding(.top, AppSpacing.xxLarge)
                
                
                dashboardGrid
                

                
                Spacer(minLength: AppSpacing.xxxLarge)
            }
        }
        .screenBackground()
        .sheet(isPresented: $showOnboarding) {
            OnboardingView()
        }
        .onAppear {
            showContent = true
            checkFirstLaunch()
            if accessibility.voiceNarrationEnabled {
                narrator.speak("Welcome to JuniorAid Plus. Learn how to stay calm and be a hero.")
            }
        }
    }
    
    
    private var heroSection: some View {
        VStack(spacing: AppSpacing.small) {
            
            Image("Mascot")
                .resizable()
                .scaledToFit()
                .frame(height: 260) 
                .opacity(showContent ? 1 : 0)
                .scaleEffect(showContent ? 1 : 0.8)
                .animation(reduceMotion ? .none : AppAnimation.springBouncy.delay(0.1), value: showContent)
            
            VStack(spacing: AppSpacing.xxSmall) {
                Text("JuniorAid+")
                    .font(.custom("FredokaOne-Regular", size: 48))
                    .foregroundStyle(AppColors.primary)
                
                Text("Your Safety Sidekick!")
                    .font(AppTypography.title3Rounded.weight(.semibold))
                    .foregroundStyle(AppColors.secondaryLabel)
            }
            .opacity(showContent ? 1 : 0)
            .offset(y: showContent ? 0 : 20)
            .animation(reduceMotion ? .none : AppAnimation.spring.delay(0.2), value: showContent)
        }
        .padding(.top, AppSpacing.medium)
    }
    
    
    private var dashboardGrid: some View {
        VStack(spacing: AppSpacing.medium) {
            
            
            HomeMenuCard(
                title: "Start Training",
                subtitle: "8 Interactive Scenarios",
                icon: "cross.case.fill",
                color: AppColors.medical,
                delay: 0.1
            ) {
                HapticManager.shared.medium()
                navigator.navigate(to: .actionScenarioList)
                if accessibility.voiceNarrationEnabled {
                    narrator.speak("Emergency Training. Tap to start.")
                }
            }
            
            
            HomeMenuCard(
                title: "SOS Mode",
                subtitle: "Call for Help Instantly",
                icon: "phone.circle.fill",
                color: AppColors.info,
                delay: 0.2
            ) {
                navigator.navigate(to: .sos)
            }
            
            
            HomeMenuCard(
                title: "Safe Touch",
                subtitle: "Learn Good & Bad Touch",
                icon: "hand.raised.fill",
                color: AppColors.warning,
                delay: 0.3
            ) {
                navigator.navigate(to: .touchSafety)
            }
            
            
            HomeMenuCard(
                title: "Good Manners",
                subtitle: "Be Kind & Respectful",
                icon: "heart.circle.fill",
                color: AppColors.accent,
                delay: 0.4
            ) {
                navigator.navigate(to: .mannersSafety)
            }
        }
        .padding(.horizontal, AppSpacing.edgePadding)
        .opacity(showContent ? 1 : 0)
        .offset(y: showContent ? 0 : 40)
        .animation(reduceMotion ? .none : AppAnimation.spring.delay(0.3), value: showContent)
    }
    

    
    
    private func checkFirstLaunch() {
        let hasLaunched = UserDefaults.standard.bool(forKey: "hasLaunchedBefore")
        if !hasLaunched {
            showOnboarding = true
            UserDefaults.standard.set(true, forKey: "hasLaunchedBefore")
        }
    }
}








struct TechBadge: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.caption2)
            Text(text)
                .font(AppTypography.caption2)
        }
        .foregroundStyle(AppColors.secondaryLabel)
        .padding(.horizontal, AppSpacing.xxSmall)
        .padding(.vertical, 4)
        .background(AppColors.tertiaryBackground, in: Capsule())
    }
}

private extension View {
    @ViewBuilder
    func screenBackground() -> some View {
        self.background(Color(red: 0.976, green: 0.961, blue: 0.914))
            
    }
}

#Preview {
    NavigationStack {
        HomeView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
            .environment(AccessibilitySettings())
    }
}



struct HomeMenuCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    var delay: Double = 0
    let action: () -> Void
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isVisible = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: AppSpacing.medium) {
                Image(systemName: icon)
                    .font(.system(size: 40))
                    .foregroundStyle(.white)
                    .frame(width: 70, height: 70)
                    .background(color.gradient)
                    .clipShape(Circle())
                    .shadow(color: color.opacity(0.4), radius: 6, y: 3)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(AppTypography.title3Rounded.weight(.bold))
                        .foregroundStyle(AppColors.label)
                    
                    Text(subtitle)
                        .font(AppTypography.body)
                        .foregroundStyle(AppColors.secondaryLabel)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.title3.bold())
                    .foregroundStyle(AppColors.tertiaryLabel)
            }
            .padding(AppSpacing.medium)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.large) 
                    .fill(AppColors.cardBackground)
                    .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 3)
            }
            .opacity(isVisible ? 1 : 0)
            .scaleEffect(isVisible ? 1 : 0.95)
            .animation(
                reduceMotion ? .none : AppAnimation.spring.delay(delay),
                value: isVisible
            )
        }
        .buttonStyle(ScaleButtonStyle())
        .onAppear {
            isVisible = true
        }
    }
}
