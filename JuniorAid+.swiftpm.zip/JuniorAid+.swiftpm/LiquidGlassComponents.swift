import SwiftUI


#if canImport(UIKit)
import UIKit
#endif

extension HapticManager {
    
    func tick(file: StaticString = #fileID, line: UInt = #line) {
        #if canImport(UIKit)
        
        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.prepare()
        generator.impactOccurred()
        #else
        
        _ = (file, line)
        #endif
    }
}









struct LiquidGlassContainer<Content: View>: View {
    let content: Content
    let padding: CGFloat
    
    init(padding: CGFloat = AppSpacing.cardPadding, @ViewBuilder content: () -> Content) {
        self.padding = padding
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(padding)
            .background {
                
                RoundedRectangle(cornerRadius: AppCornerRadius.card)
                    .fill(.regularMaterial) 
            }
            .appShadow(AppShadows.medium)
    }
}



struct LiquidGlassCard<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(AppSpacing.medium)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.medium)
                    .fill(.thinMaterial) 
            }
            .appShadow(AppShadows.small)
    }
}



struct FloatingActionButton: View {
    let icon: String
    let action: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button(action: performAction) {
            Image(systemName: icon)
                .font(.title2.weight(.semibold))
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.white)
                .frame(width: 56, height: 56)
                .background {
                    Circle()
                        .fill(AppColors.primary.gradient)
                }
                .scaleEffect(isPressed ? 0.92 : 1.0)
        }
        .buttonStyle(.plain)
        .appShadow(AppShadows.large)
        .pressEvents(
            onPress: { isPressed = true },
            onRelease: { isPressed = false }
        )
        .animation(.bouncy(duration: 0.3), value: isPressed)
    }
    
    private func performAction() {
        HapticManager.shared.tick()
        action()
    }
}



struct PressEventsModifier: ViewModifier {
    let onPress: () -> Void
    let onRelease: () -> Void
    
    func body(content: Content) -> some View {
        content
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in onPress() }
                    .onEnded { _ in onRelease() }
            )
    }
}

extension View {
    func pressEvents(onPress: @escaping () -> Void, onRelease: @escaping () -> Void) -> some View {
        modifier(PressEventsModifier(onPress: onPress, onRelease: onRelease))
    }
}



struct LiquidGlassSectionHeader: View {
    let title: String
    let subtitle: String?
    let icon: String?
    
    init(title: String, subtitle: String? = nil, icon: String? = nil) {
        self.title = title
        self.subtitle = subtitle
        self.icon = icon
    }
    
    var body: some View {
        HStack(spacing: AppSpacing.small) {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.title3)
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(AppColors.primary.gradient)
            }
            
            VStack(alignment: .leading, spacing: AppSpacing.xxxSmall) {
                Text(title)
                    .font(AppTypography.title3Rounded.weight(.semibold))
                    .foregroundStyle(AppColors.label)
                
                if let subtitle = subtitle {
                    Text(subtitle)
                        .font(AppTypography.caption)
                        .foregroundStyle(AppColors.secondaryLabel)
                }
            }
            
            Spacer()
        }
        .padding(.horizontal, AppSpacing.edgePadding)
    }
}



struct LiquidGlassListRow<Trailing: View>: View {
    let icon: String
    let title: String
    let subtitle: String?
    let iconColor: Color
    let trailing: Trailing
    let action: () -> Void
    
    @State private var isPressed = false
    
    init(
        icon: String,
        title: String,
        subtitle: String? = nil,
        iconColor: Color = AppColors.primary,
        action: @escaping () -> Void,
        @ViewBuilder trailing: () -> Trailing = { EmptyView() }
    ) {
        self.icon = icon
        self.title = title
        self.subtitle = subtitle
        self.iconColor = iconColor
        self.action = action
        self.trailing = trailing()
    }
    
    var body: some View {
        Button(action: performAction) {
            HStack(spacing: AppSpacing.medium) {
                
                Image(systemName: icon)
                    .font(.title3)
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(iconColor.gradient)
                    .frame(width: 32, height: 32)
                
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(AppTypography.body)
                        .foregroundStyle(AppColors.label)
                    
                    if let subtitle = subtitle {
                        Text(subtitle)
                            .font(AppTypography.caption)
                            .foregroundStyle(AppColors.secondaryLabel)
                    }
                }
                
                Spacer()
                
                
                trailing
                
                
                Image(systemName: "chevron.right")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(AppColors.tertiaryLabel)
            }
            .padding(AppSpacing.small)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.small)
                    .fill(isPressed ? AppColors.secondaryFill : AppColors.secondaryBackground)
            }
            .scaleEffect(isPressed ? 0.98 : 1.0)
        }
        .buttonStyle(.plain)
        .pressEvents(
            onPress: { isPressed = true },
            onRelease: { isPressed = false }
        )
        .animation(.snappy(duration: 0.2), value: isPressed)
    }
    
    private func performAction() {
        HapticManager.shared.tick()
        action()
    }
}



struct LiquidGlassButton: View {
    let title: String
    let icon: String?
    let color: Color
    let action: () -> Void
    
    @State private var isPressed = false
    
    init(title: String, icon: String? = nil, color: Color = AppColors.primary, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.color = color
        self.action = action
    }
    
    var body: some View {
        Button(action: performAction) {
            HStack(spacing: AppSpacing.small) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.headline.weight(.semibold))
                }
                Text(title)
                    .font(AppTypography.buttonLarge)
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, AppSpacing.medium)
            .background {
                Capsule()
                    .fill(color.gradient)
                    .shadow(color: color.opacity(0.4), radius: 10, x: 0, y: 5)
            }
            .scaleEffect(isPressed ? 0.96 : 1.0)
            .overlay {
                if isPressed {
                    Capsule()
                        .fill(.white.opacity(0.1))
                }
            }
        }
        .buttonStyle(.plain)
        .pressEvents(
            onPress: { isPressed = true },
            onRelease: { isPressed = false }
        )
        .animation(.snappy(duration: 0.2), value: isPressed)
    }
    
    private func performAction() {
        HapticManager.shared.tick()
        action()
    }
}



#Preview("Liquid Glass Components") {
    ScrollView {
        VStack(spacing: AppSpacing.large) {
            LiquidGlassSectionHeader(
                title: "Navigation Layer",
                subtitle: "Liquid Glass with refraction",
                icon: "sparkles"
            )
            
            LiquidGlassContainer {
                VStack(spacing: AppSpacing.small) {
                    Text("Liquid Glass Container")
                        .font(AppTypography.headline)
                    Text("Uses .regularMaterial for navigation")
                        .font(AppTypography.caption)
                        .foregroundStyle(AppColors.secondaryLabel)
                }
            }
            .padding(.horizontal)
            
            LiquidGlassSectionHeader(
                title: "Content Layer",
                subtitle: "Thinner material for cards",
                icon: "square.stack.3d.up"
            )
            
            LiquidGlassCard {
                VStack(alignment: .leading, spacing: AppSpacing.small) {
                    Text("Card Title")
                        .font(AppTypography.title3Rounded.weight(.semibold))
                    Text("Card subtitle with thinner material")
                        .font(AppTypography.caption)
                        .foregroundStyle(AppColors.secondaryLabel)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.horizontal)
            
            LiquidGlassSectionHeader(
                title: "Interactive Elements",
                icon: "hand.tap"
            )
            
            VStack(spacing: AppSpacing.xxSmall) {
                LiquidGlassListRow(
                    icon: "heart.fill",
                    title: "List Row with Haptics",
                    subtitle: "Tap to feel feedback",
                    iconColor: .red
                ) {
                    print("Tapped!")
                }
                
                LiquidGlassListRow(
                    icon: "star.fill",
                    title: "Another Row",
                    iconColor: .yellow,
                    action: {},
                    trailing: {
                        Text("Badge")
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(AppColors.primary, in: Capsule())
                    }
                )
            }
            .padding(.horizontal)
            
            FloatingActionButton(icon: "plus") {
                print("Floating action!")
            }
        }
        .padding(.vertical)
    }
    .background(AppColors.background)
}

