import SwiftUI

// MARK: - Manner Scenario Player

struct MannerScenarioPlayer: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    
    let scenario: MannerScenario
    
    @State private var currentStepIndex = 0
    @State private var showCelebration = false
    
    private var currentStep: MannerStep {
        scenario.steps[currentStepIndex]
    }
    
    private var isLastStep: Bool {
        currentStepIndex == scenario.steps.count - 1
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    scenario.category.color.opacity(0.3),
                    scenario.category.color.opacity(0.1),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                progressIndicator
                    .padding(.top, Spacing.medium)
                    .padding(.bottom, Spacing.large)
                
                ScrollView {
                    VStack(spacing: Spacing.xxLarge) {
                        // Title Heading
                        Text(scenario.title)
                            .font(JuniorAidFont.title.bold())
                            .foregroundColor(JuniorAidColors.primaryText)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .padding(.top, Spacing.xxxSmall)
                        
                        visualCue
                        
                        VStack(spacing: Spacing.large) {
                            instructionCard
                            exampleCard
                            
                            if isLastStep {
                                keyTakeawayCard
                            }
                        }
                        
                        navigationButton
                    }
                    .padding(.horizontal, Spacing.large)
                }
            }
            
            if showCelebration {
                CelebrationAnimation()
            }
        }
        .onAppear {
            narrator.speak(currentStep.voiceText)
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    narrator.stop()
                    navigator.pop()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "chevron.left")
                        Text("Back")
                            .font(JuniorAidFont.body)
                    }
                    .foregroundColor(JuniorAidColors.primaryText)
                }
            }
        }
    }
    
    private var progressIndicator: some View {
        HStack(spacing: Spacing.xSmall) {
            ForEach(0..<scenario.steps.count, id: \.self) { index in
                Capsule()
                    .fill(index <= currentStepIndex ?
                          scenario.category.color : scenario.category.color.opacity(0.3))
                    .frame(height: 6)
                    .frame(maxWidth: .infinity)
            }
        }
        .padding(.horizontal, Spacing.large)
    }
    
    private var scenarioHeader: some View {
        EmptyView()
    }
    
    private var visualCue: some View {
        Image(systemName: currentStep.visualCue)
            .font(.system(size: 80))
            .foregroundColor(scenario.category.color.opacity(0.7))
            .padding(Spacing.large)
            .background(
                Circle()
                    .fill(scenario.category.color.opacity(0.2))
                    .frame(width: 150, height: 150)
            )
            .scaleInTransition(delay: 0.1)
    }
    
    private var instructionCard: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: Spacing.small) {
                Text("Learn:")
                    .font(JuniorAidFont.caption)
                    .foregroundColor(JuniorAidColors.secondaryText)
                
                Text(currentStep.instruction)
                    .font(JuniorAidFont.bodyLarge)
                    .foregroundColor(JuniorAidColors.primaryText)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .scaleInTransition(delay: 0.2)
    }
    
    private var exampleCard: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: Spacing.small) {
                HStack {
                    Image(systemName: "lightbulb.fill")
                        .foregroundColor(JuniorAidColors.encouragementYellow)
                    Text("Example:")
                        .font(JuniorAidFont.caption)
                        .foregroundColor(JuniorAidColors.secondaryText)
                }
                
                Text(currentStep.example)
                    .font(JuniorAidFont.body)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .italic()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .scaleInTransition(delay: 0.3)
    }
    
    private var keyTakeawayCard: some View {
        LiquidGlassCard {
            VStack(spacing: Spacing.medium) {
                Image(systemName: "star.fill")
                    .font(.system(size: 40))
                    .foregroundColor(JuniorAidColors.successGreen)
                
                Text("Remember!")
                    .font(JuniorAidFont.headline)
                    .foregroundColor(JuniorAidColors.primaryText)
                
                Text(scenario.keyTakeaway)
                    .font(JuniorAidFont.bodyLarge)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .multilineTextAlignment(.center)
            }
        }
        .scaleInTransition(delay: 0.4)
    }
    
    private var navigationButton: some View {
        Button {
            if isLastStep {
                showCelebration = true
                HapticManager.shared.success()
                narrator.speak("Great job! You learned about \(scenario.title)")
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    navigator.pop()
                }
            } else {
                HapticManager.shared.light()
                withAnimation(SpringAnimations.gentle) {
                    currentStepIndex += 1
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    narrator.speak(currentStep.voiceText)
                }
            }
        } label: {
            Text(isLastStep ? "Complete!" : "Next")
                .font(JuniorAidFont.buttonLarge)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, Spacing.medium)
                .background(
                    Capsule()
                        .fill(scenario.category.color)
                )
        }
        .scaleInTransition(delay: 0.5)
    }
}

#Preview {
    NavigationStack {
        MannerScenarioPlayer(scenario: MannersContent.askingForHelpScenario)
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
    }
}
