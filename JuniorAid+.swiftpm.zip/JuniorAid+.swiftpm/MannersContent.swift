import SwiftUI



class MannersContent {
    static let scenarios: [MannerScenario] = [
        askingForHelpScenario,
        sayingNoScenario,
        trustedPeopleScenario
    ]
    
    static let askingForHelpScenario = MannerScenario(
        title: "Asking for Help",
        category: .askingForHelp,
        description: "Learn how to ask for help politely and clearly",
        visualCue: "person.fill.questionmark",
        steps: [
            MannerStep(
                instruction: "Say 'Excuse me' to get attention",
                voiceText: "Start with 'excuse me' to be polite",
                visualCue: "hand.raised.fill",
                example: "'Excuse me, can you help me?'"
            ),
            MannerStep(
                instruction: "Explain what you need clearly",
                voiceText: "Tell them exactly what help you need",
                visualCue: "bubble.left.fill",
                example: "'I need help finding my parent'"
            ),
            MannerStep(
                instruction: "Say 'please' and 'thank you'",
                voiceText: "Always remember your manners",
                visualCue: "heart.fill",
                example: "'Please help me. Thank you!'"
            )
        ],
        keyTakeaway: "Being polite helps people want to help you!"
    )
    
    static let sayingNoScenario = MannerScenario(
        title: "Saying No Politely",
        category: .sayingNo,
        description: "Learn when and how to say no",
        visualCue: "hand.raised.fill",
        steps: [
            MannerStep(
                instruction: "You can say no if something feels wrong",
                voiceText: "It's okay to say no to things that feel bad or unsafe",
                visualCue: "hand.raised.slash.fill",
                example: "'No, I don't want to do that'"
            ),
            MannerStep(
                instruction: "Be clear and firm",
                voiceText: "Say it clearly so people understand",
                visualCue: "exclamationmark.circle.fill",
                example: "'No thank you, I need to ask my parent first'"
            ),
            MannerStep(
                instruction: "Tell a trusted adult",
                voiceText: "Always tell a grown-up if someone makes you uncomfortable",
                visualCue: "person.2.fill",
                example: "Tell your parent or teacher what happened"
            )
        ],
        keyTakeaway: "You have the right to say no to things that feel wrong!"
    )
    
    static let trustedPeopleScenario = MannerScenario(
        title: "Trusted People",
        category: .trustedPeople,
        description: "Learn who to trust and stay with",
        visualCue: "person.2.fill",
        steps: [
            MannerStep(
                instruction: "Know your trusted adults",
                voiceText: "Trusted adults are family, teachers, and people your parents trust",
                visualCue: "heart.circle.fill",
                example: "Parents, grandparents, teachers, police officers"
            ),
            MannerStep(
                instruction: "Stay where trusted adults can see you",
                voiceText: "Always stay where your grown-up can see you",
                visualCue: "eye.fill",
                example: "Don't wander off in stores or parks"
            ),
            MannerStep(
                instruction: "Never go anywhere with a stranger",
                voiceText: "Even if someone seems nice, never go with them unless your parent says it's okay",
                visualCue: "exclamationmark.shield.fill",
                example: "Always check with your parent first"
            )
        ],
        keyTakeaway: "Stay with people you trust and your parents know!"
    )
}
