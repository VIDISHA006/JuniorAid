import SwiftUI



struct MannersSafetyView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    
    let scenarios = MannersContent.scenarios
    
    var body: some View {
        ZStack {
            JuniorAidColors.backgroundGradient
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: Spacing.xLarge) {
                    header
                        .padding(.top, Spacing.large)
                    
                    ForEach(Array(scenarios.enumerated()), id: \.element.id) { index, scenario in
                        scenarioCard(scenario)
                            .scaleInTransition(delay: Double(index) * 0.1)
                    }
                }
                .padding(Spacing.large)
            }
        }
        .onAppear {
            narrator.speak("Learn about manners and staying safe")
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    navigator.pop()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    private var header: some View {
        VStack(spacing: Spacing.small) {
            Image(systemName: "person.2.fill")
                .font(.system(size: 60))
                .foregroundColor(JuniorAidColors.chokingPastel)
            
            Text("Manners & Safety")
                .font(JuniorAidFont.title)
                .foregroundColor(JuniorAidColors.primaryText)
            
            Text("Learn to stay safe and be polite")
                .font(JuniorAidFont.body)
                .foregroundColor(JuniorAidColors.secondaryText)
                .multilineTextAlignment(.center)
        }
    }
    
    private func scenarioCard(_ scenario: MannerScenario) -> some View {
        Button {
            navigator.navigate(to: .mannerScenarioPlayer(scenario))
            narrator.speak("Let's learn about \(scenario.title)")
        } label: {
            LiquidGlassCard {
                HStack(spacing: Spacing.medium) {
                    Image(systemName: scenario.category.icon)
                        .font(.system(size: 40))
                        .foregroundColor(scenario.category.color)
                        .frame(width: 60, height: 60)
                        .background(
                            Circle()
                                .fill(scenario.category.color.opacity(0.2))
                        )
                    
                    VStack(alignment: .leading, spacing: Spacing.xSmall) {
                        Text(scenario.title)
                            .font(JuniorAidFont.headline)
                            .foregroundColor(JuniorAidColors.primaryText)
                        
                        Text(scenario.description)
                            .font(JuniorAidFont.body)
                            .foregroundColor(JuniorAidColors.secondaryText)
                            .lineLimit(2)
                    }
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 24))
                        .foregroundColor(scenario.category.color)
                }
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    NavigationStack {
        MannersSafetyView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
    }
}
