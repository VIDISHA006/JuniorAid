import SwiftUI




struct MemoryCard: Identifiable, Codable {
    let id: String
    let scenarioName: String
    let keyAction: String
    let icon: String
    let color: Color
    let timestamp: Date

    init(id: String = UUID().uuidString, scenarioName: String, keyAction: String, icon: String, color: Color, timestamp: Date = Date()) {
        self.id = id
        self.scenarioName = scenarioName
        self.keyAction = keyAction
        self.icon = icon
        self.color = color
        self.timestamp = timestamp
    }

    
    enum CodingKeys: String, CodingKey {
        case id, scenarioName, keyAction, icon, timestamp, color
    }

    struct RGBAColor: Codable {
        let r: Double
        let g: Double
        let b: Double
        let a: Double
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        scenarioName = try container.decode(String.self, forKey: .scenarioName)
        keyAction = try container.decode(String.self, forKey: .keyAction)
        icon = try container.decode(String.self, forKey: .icon)
        timestamp = try container.decode(Date.self, forKey: .timestamp)

        if let rgba = try container.decodeIfPresent(RGBAColor.self, forKey: .color) {
            color = Color(.sRGB, red: rgba.r, green: rgba.g, blue: rgba.b, opacity: rgba.a)
        } else {
            
            color = .clear
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(scenarioName, forKey: .scenarioName)
        try container.encode(keyAction, forKey: .keyAction)
        try container.encode(icon, forKey: .icon)
        try container.encode(timestamp, forKey: .timestamp)

        
        #if canImport(UIKit)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if UIColor(color).getRed(&r, green: &g, blue: &b, alpha: &a) {
            try container.encode(RGBAColor(r: Double(r), g: Double(g), b: Double(b), a: Double(a)), forKey: .color)
        }
        #elseif canImport(AppKit)
        if let converted = NSColor(color).usingColorSpace(.sRGB) {
            let r = Double(converted.redComponent)
            let g = Double(converted.greenComponent)
            let b = Double(converted.blueComponent)
            let a = Double(converted.alphaComponent)
            try container.encode(RGBAColor(r: r, g: g, b: b, a: a), forKey: .color)
        }
        #else
        
        #endif
    }
}


struct MemoryCardView: View {
    let card: MemoryCard
    let onReplay: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button {
            onReplay()
        } label: {
            VStack(spacing: Spacing.medium) {
                
                Image(systemName: card.icon)
                    .font(.system(size: 50))
                    .foregroundColor(JuniorAidColors.deepIndigo)
                
                
                Text(card.keyAction)
                    .font(JuniorAidFont.bodyLarge)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                
                
                Text(card.scenarioName)
                    .font(JuniorAidFont.caption)
                    .foregroundColor(JuniorAidColors.secondaryText)
            }
            .padding(Spacing.large)
            .frame(maxWidth: .infinity)
            .frame(height: 200)
            .background(
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .fill(.ultraThinMaterial)
                    .background(
                        RoundedRectangle(cornerRadius: CornerRadius.large)
                            .fill(card.color.opacity(0.1))
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: CornerRadius.large)
                    .stroke(JuniorAidColors.glassStroke, lineWidth: 1)
            )
            .juniorAidShadow(Shadows.medium)
            .scaleEffect(isPressed ? 0.95 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in isPressed = true }
                .onEnded { _ in isPressed = false }
        )
    }
}







struct FreezeFrameView: View {
    let scenarioName: String
    let keyAction: String
    let icon: String
    let color: Color
    let onContinue: () -> Void
    
    @State private var scale: CGFloat = 0.8
    @State private var opacity: Double = 0
    
    var body: some View {
        ZStack {
            
            JuniorAidColors.creamBackground
                .ignoresSafeArea()
            
            VStack(spacing: Spacing.xLarge) {
                Spacer()
                
                
                ZStack {
                    Circle()
                        .fill(JuniorAidColors.successGreen.opacity(0.1))
                        .frame(width: 140, height: 140)
                    
                    Circle()
                        .stroke(JuniorAidColors.successGreen.opacity(0.3), lineWidth: 2)
                        .frame(width: 160, height: 160)
                        
                    Image(systemName: "checkmark")
                        .font(.system(size: 60, weight: .bold))
                        .foregroundColor(JuniorAidColors.successGreen)
                        .scaleEffect(scale)
                }
                .padding(.top, Spacing.xxLarge)
                
                VStack(spacing: Spacing.medium) {
                    Text("Great Job!")
                        .font(JuniorAidFont.largeTitle.bold())
                        .foregroundColor(JuniorAidColors.primaryText)
                    
                    Text("You completed the \(scenarioName) scenario.")
                        .font(JuniorAidFont.body)
                        .foregroundColor(JuniorAidColors.secondaryText)
                        .multilineTextAlignment(.center)
                }
                
                
                VStack(spacing: Spacing.large) {
                    Text("REMEMBER")
                        .font(JuniorAidFont.caption.bold())
                        .foregroundColor(JuniorAidColors.secondaryText)
                        .tracking(2)
                    
                    VStack(spacing: Spacing.medium) {
                        Image(systemName: icon)
                            .font(.system(size: 50))
                            .foregroundColor(JuniorAidColors.deepIndigo)
                        
                        Text(keyAction)
                            .font(JuniorAidFont.title2)
                            .foregroundColor(JuniorAidColors.primaryText)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(Spacing.xLarge)
                .frame(maxWidth: .infinity)
                .background(Color.white)
                .cornerRadius(CornerRadius.large)
                .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 5)
                .padding(.horizontal, Spacing.large)
                
                Spacer()
                
                
                Button {
                    onContinue()
                } label: {
                    Text("Finish")
                        .font(JuniorAidFont.buttonLarge)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, Spacing.large)
                        .background(
                            Capsule()
                                .fill(JuniorAidColors.primary)
                        )
                        .shadow(color: JuniorAidColors.primary.opacity(0.3), radius: 8, y: 4)
                }
                .padding(.horizontal, Spacing.large)
                .padding(.bottom, Spacing.xxxLarge)
            }
            .opacity(opacity)
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                scale = 1.0
                opacity = 1.0
            }
        }
    }
}


struct MemoryGalleryView: View {
    @State private var memoryCards: [MemoryCard] = []
    
    var body: some View {
        ScrollView {
            VStack(spacing: Spacing.large) {
                
                VStack(spacing: Spacing.small) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 60))
                        .foregroundColor(JuniorAidColors.softSky)
                    
                    Text("Your Memory Cards")
                        .font(JuniorAidFont.title)
                        .foregroundColor(JuniorAidColors.primaryText)
                    
                    Text("Tap any card to replay that lesson")
                        .font(JuniorAidFont.body)
                        .foregroundColor(JuniorAidColors.secondaryText)
                }
                .padding(.top, Spacing.large)
                
                
                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: Spacing.medium),
                        GridItem(.flexible(), spacing: Spacing.medium)
                    ],
                    spacing: Spacing.medium
                ) {
                    ForEach(memoryCards) { card in
                        MemoryCardView(card: card) {
                            
                            print("Replay: \(card.scenarioName)")
                        }
                    }
                }
                .padding(Spacing.large)
            }
        }
        .background(JuniorAidColors.backgroundGradient.ignoresSafeArea())
        .onAppear {
            loadMemoryCards()
        }
    }
    
    private func loadMemoryCards() {
        
        
        memoryCards = [
            MemoryCard(
                scenarioName: "Bleeding",
                keyAction: "Press gently and call for help",
                icon: "bandage.fill",
                color: JuniorAidColors.peachMist
            ),
            MemoryCard(
                scenarioName: "Burns",
                keyAction: "Cool water for 10 minutes",
                icon: "drop.fill",
                color: JuniorAidColors.softSky
            ),
            MemoryCard(
                scenarioName: "Choking",
                keyAction: "Tap back, then chest",
                icon: "hand.tap.fill",
                color: JuniorAidColors.lavenderHaze
            )
        ]
    }
}

#Preview("Memory Card") {
    MemoryCardView(
        card: MemoryCard(
            scenarioName: "Bleeding",
            keyAction: "Press gently and call for help",
            icon: "bandage.fill",
            color: JuniorAidColors.peachMist
        )
    ) {
        print("Replay")
    }
    .padding()
}

#Preview("Freeze Frame") {
    FreezeFrameView(
        scenarioName: "Bleeding",
        keyAction: "Press gently and call for help",
        icon: "bandage.fill",
        color: JuniorAidColors.peachMist
    ) {
        print("Continue")
    }
}

#Preview("Memory Gallery") {
    MemoryGalleryView()
}
