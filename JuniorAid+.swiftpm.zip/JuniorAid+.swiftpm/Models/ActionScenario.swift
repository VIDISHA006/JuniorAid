import SwiftUI





struct ActionScenario: Identifiable, Hashable {
    let id: UUID
    let title: String
    let icon: String
    let color: Color
    let description: String
    let steps: [ActionStep]
    let memoryCard: MemoryCardData
    
    init(
        id: UUID = UUID(),
        title: String,
        icon: String,
        color: Color,
        description: String,
        steps: [ActionStep],
        memoryCard: MemoryCardData
    ) {
        self.id = id
        self.title = title
        self.icon = icon
        self.color = color
        self.description = description
        self.steps = steps
        self.memoryCard = memoryCard
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: ActionScenario, rhs: ActionScenario) -> Bool {
        lhs.id == rhs.id
    }
}


enum ScenarioAnimationType: Hashable {
    case pressing
    case swiping(SwipeDirection)
    case leaningForward
    case pinching
    case waterFlowing
    case crawling
    case phoneCall
    case rubbing
    case tapping
    case scraping
    case stabilizing
    case iceApplication
    case kneeling
    case backBlows
    case bleedingHand
    case cleanCloth
    case bleedingHandPress
    case cleanCutHand
    case burnCooling
    case waterHandBurn
    case handClothWrapped
    case fireRoom1
    case fireRoom2
    case pressingNose
    case beeSting1
    case beeSting2
    case dogBiteWash
    case dogBiteDry
    case dogBiteWrap
    case none
}


struct ActionStep: Identifiable, Hashable {
    let id: UUID
    let title: String                 
    let instruction: String           
    let gestureType: GestureType      
    let visualCue: String             
    let coachGuidance: String?        
    let successEffect: SceneEffect
    let voiceNarration: String
    let animation: ScenarioAnimationType
    
    init(
        id: UUID = UUID(),
        title: String,
        instruction: String,
        gestureType: GestureType,
        visualCue: String,
        coachGuidance: String? = nil,
        successEffect: SceneEffect,
        voiceNarration: String,
        animation: ScenarioAnimationType = .none
    ) {
        self.id = id
        self.title = title
        self.instruction = instruction
        self.gestureType = gestureType
        self.visualCue = visualCue
        self.coachGuidance = coachGuidance
        self.successEffect = successEffect
        self.voiceNarration = voiceNarration
        self.animation = animation
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: ActionStep, rhs: ActionStep) -> Bool {
        lhs.id == rhs.id
    }
}


struct SceneEffect: Hashable {
    let characterState: CharacterState
    let environmentTone: EnvironmentTone
    let colorShift: ColorShift
    let message: String 
    
    static let calm = SceneEffect(
        characterState: .breathing,
        environmentTone: .calm,
        colorShift: .warmer,
        message: "Great job! They're feeling better."
    )
    
    static let recovered = SceneEffect(
        characterState: .relaxed,
        environmentTone: .calm,
        colorShift: .warmer,
        message: "You did it! They're safe now."
    )
    
    static let needsHelp = SceneEffect(
        characterState: .concerned,
        environmentTone: .alert,
        colorShift: .neutral,
        message: "Let's get them help quickly."
    )
}

enum ColorShift: Hashable {
    case warmer   
    case cooler   
    case neutral  
}


struct MemoryCardData: Hashable {
    let keyAction: String      
    let icon: String           
    let scenarioName: String   
}


