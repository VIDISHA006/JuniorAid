import SwiftUI

// MARK: - Drill Models
// Data structures for practice drill content

/// Practice drill model for timed emergency response training
struct Drill: Identifiable, Hashable {
    let id: UUID
    let title: String
    let scenarioReference: UUID  // References a Scenario
    let icon: String
    let color: Color
    let description: String
    let steps: [DrillStep]
    let totalDuration: TimeInterval
    let difficulty: DifficultyLevel
    
    init(
        id: UUID = UUID(),
        title: String,
        scenarioReference: UUID,
        icon: String,
        color: Color,
        description: String,
        steps: [DrillStep],
        difficulty: DifficultyLevel
    ) {
        self.id = id
        self.title = title
        self.scenarioReference = scenarioReference
        self.icon = icon
        self.color = color
        self.description = description
        self.steps = steps
        self.totalDuration = steps.reduce(0) { $0 + $1.duration }
        self.difficulty = difficulty
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Drill, rhs: Drill) -> Bool {
        lhs.id == rhs.id
    }
}

/// Individual step in a practice drill
struct DrillStep: Identifiable, Hashable {
    let id: UUID
    let instruction: String
    let voiceGuidance: String
    let duration: TimeInterval
    let visualCue: String
    
    init(
        id: UUID = UUID(),
        instruction: String,
        voiceGuidance: String,
        duration: TimeInterval,
        visualCue: String
    ) {
        self.id = id
        self.instruction = instruction
        self.voiceGuidance = voiceGuidance
        self.duration = duration
        self.visualCue = visualCue
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: DrillStep, rhs: DrillStep) -> Bool {
        lhs.id == rhs.id
    }
}

/// Difficulty level for drills
enum DifficultyLevel: String, CaseIterable {
    case beginner = "Beginner"
    case intermediate = "Intermediate"
    case advanced = "Advanced"
    
    var color: Color {
        switch self {
        case .beginner:
            return JuniorAidColors.successGreen
        case .intermediate:
            return JuniorAidColors.encouragementYellow
        case .advanced:
            return JuniorAidColors.bleedingPastel
        }
    }
    
    var icon: String {
        switch self {
        case .beginner:
            return "star.fill"
        case .intermediate:
            return "star.leadinghalf.filled"
        case .advanced:
            return "star.circle.fill"
        }
    }
}

/// Progress tracking for drills
/// Thread-safe with @MainActor for Swift 6 strict concurrency
@MainActor @Observable
class DrillProgress {
    var completedDrills: Set<UUID> = []
    var drillScores: [UUID: Int] = [:]
    
    func markCompleted(_ drillId: UUID, score: Int) {
        completedDrills.insert(drillId)
        drillScores[drillId] = max(drillScores[drillId] ?? 0, score)
    }
    
    func isCompleted(_ drillId: UUID) -> Bool {
        completedDrills.contains(drillId)
    }
    
    func score(for drillId: UUID) -> Int {
        drillScores[drillId] ?? 0
    }
}
