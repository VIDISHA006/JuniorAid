import SwiftUI

// MARK: - Manners & Safety Models
// Data structures for social safety and manners education

/// Manners and social safety scenario
struct MannerScenario: Identifiable, Hashable {
    let id: UUID
    let title: String
    let category: MannerCategory
    let description: String
    let visualCue: String
    let steps: [MannerStep]
    let keyTakeaway: String
    
    init(
        id: UUID = UUID(),
        title: String,
        category: MannerCategory,
        description: String,
        visualCue: String,
        steps: [MannerStep],
        keyTakeaway: String
    ) {
        self.id = id
        self.title = title
        self.category = category
        self.description = description
        self.visualCue = visualCue
        self.steps = steps
        self.keyTakeaway = keyTakeaway
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: MannerScenario, rhs: MannerScenario) -> Bool {
        lhs.id == rhs.id
    }
}

/// Step in a manners scenario
struct MannerStep: Identifiable, Hashable {
    let id: UUID
    let instruction: String
    let voiceText: String
    let visualCue: String
    let example: String
    
    init(
        id: UUID = UUID(),
        instruction: String,
        voiceText: String,
        visualCue: String,
        example: String
    ) {
        self.id = id
        self.instruction = instruction
        self.voiceText = voiceText
        self.visualCue = visualCue
        self.example = example
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: MannerStep, rhs: MannerStep) -> Bool {
        lhs.id == rhs.id
    }
}

/// Category of manners and safety lessons
enum MannerCategory: String, CaseIterable {
    case askingForHelp = "Asking for Help"
    case sayingNo = "Saying No Politely"
    case trustedPeople = "Staying with Trusted People"
    case publicSafety = "Public Behavior Safety"
    case strangerAwareness = "Stranger Awareness"
    
    var color: Color {
        switch self {
        case .askingForHelp:
            return JuniorAidColors.helpPastel
        case .sayingNo:
            return JuniorAidColors.bleedingPastel
        case .trustedPeople:
            return JuniorAidColors.successGreen.opacity(0.6)
        case .publicSafety:
            return JuniorAidColors.chokingPastel
        case .strangerAwareness:
            return JuniorAidColors.encouragementYellow.opacity(0.6)
        }
    }
    
    var icon: String {
        switch self {
        case .askingForHelp:
            return "person.fill.questionmark"
        case .sayingNo:
            return "hand.raised.fill"
        case .trustedPeople:
            return "person.2.fill"
        case .publicSafety:
            return "building.2.fill"
        case .strangerAwareness:
            return "exclamationmark.shield.fill"
        }
    }
}

/// Interactive manners quiz
struct MannerQuiz: Identifiable, Hashable {
    let id: UUID
    let situation: String
    let question: String
    let choices: [MannerChoice]
    let explanation: String
    
    init(
        id: UUID = UUID(),
        situation: String,
        question: String,
        choices: [MannerChoice],
        explanation: String
    ) {
        self.id = id
        self.situation = situation
        self.question = question
        self.choices = choices
        self.explanation = explanation
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: MannerQuiz, rhs: MannerQuiz) -> Bool {
        lhs.id == rhs.id
    }
}

/// Choice option for manners quiz
struct MannerChoice: Identifiable, Hashable {
    let id: UUID
    let text: String
    let isCorrect: Bool
    let feedback: String
    
    init(
        id: UUID = UUID(),
        text: String,
        isCorrect: Bool,
        feedback: String
    ) {
        self.id = id
        self.text = text
        self.isCorrect = isCorrect
        self.feedback = feedback
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: MannerChoice, rhs: MannerChoice) -> Bool {
        lhs.id == rhs.id
    }
}
