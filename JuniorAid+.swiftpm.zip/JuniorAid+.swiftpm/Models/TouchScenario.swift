import SwiftUI

// MARK: - Touch Safety Models
// Data structures for Good Touch / Bad Touch education

/// Touch safety scenario model
struct TouchScenario: Identifiable, Hashable {
    let id: UUID
    let title: String
    let description: String
    let category: TouchCategory
    let visualCue: String
    let guidance: String
    let voiceText: String
    
    init(
        id: UUID = UUID(),
        title: String,
        description: String,
        category: TouchCategory,
        visualCue: String,
        guidance: String,
        voiceText: String
    ) {
        self.id = id
        self.title = title
        self.description = description
        self.category = category
        self.visualCue = visualCue
        self.guidance = guidance
        self.voiceText = voiceText
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: TouchScenario, rhs: TouchScenario) -> Bool {
        lhs.id == rhs.id
    }
}

/// Touch category classification
enum TouchCategory: String, CaseIterable {
    case safe = "Safe Touch"
    case unsafe = "Unsafe Touch"
    case confusing = "I'm Not Sure"
    
    var color: Color {
        switch self {
        case .safe:
            return JuniorAidColors.safeTouchColor
        case .unsafe:
            return JuniorAidColors.unsafeTouchColor
        case .confusing:
            return JuniorAidColors.confusingTouchColor
        }
    }
    
    var icon: String {
        switch self {
        case .safe:
            return "hand.thumbsup.fill"
        case .unsafe:
            return "hand.raised.fill"
        case .confusing:
            return "questionmark.circle.fill"
        }
    }
    
    var guidance: String {
        switch self {
        case .safe:
            return "This is okay! Safe touches make you feel comfortable."
        case .unsafe:
            return "This is NOT okay. Tell a trusted adult right away."
        case .confusing:
            return "If you're not sure, always tell a trusted adult."
        }
    }
}

/// Interactive touch safety quiz
struct TouchQuizQuestion: Identifiable, Hashable {
    let id: UUID
    let scenario: String
    let visualCue: String
    let correctCategory: TouchCategory
    let explanation: String
    let encouragement: String
    
    init(
        id: UUID = UUID(),
        scenario: String,
        visualCue: String,
        correctCategory: TouchCategory,
        explanation: String,
        encouragement: String
    ) {
        self.id = id
        self.scenario = scenario
        self.visualCue = visualCue
        self.correctCategory = correctCategory
        self.explanation = explanation
        self.encouragement = encouragement
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: TouchQuizQuestion, rhs: TouchQuizQuestion) -> Bool {
        lhs.id == rhs.id
    }
}
