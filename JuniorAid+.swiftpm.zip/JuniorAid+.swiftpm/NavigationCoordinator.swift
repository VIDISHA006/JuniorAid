import SwiftUI




@MainActor @Observable
class NavigationCoordinator {
    var path: [AppRoute] = []
    var showSOSOverlay: Bool = false
    
    func navigate(to route: AppRoute) {
        path.append(route)
    }
    
    func pop() {
        if !path.isEmpty {
            path.removeLast()
        }
    }
    
    func popToRoot() {
        path.removeAll()
    }
    
    func toggleSOS() {
        showSOSOverlay.toggle()
        HapticManager.shared.heavy()
    }
}


enum AppRoute: Hashable {
    case home
    case actionScenarioList        
    case actionScenarioPlayer(ActionScenario) 

    case sos
    case countrySelector
    case touchSafety
    case touchScenarioPlayer([TouchQuizQuestion], Int)
    case mannersSafety
    case mannerScenarioPlayer(MannerScenario)
    case memoryGallery             
    case settings
}
