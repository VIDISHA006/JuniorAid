import SwiftUI

// MARK: - App Navigation Coordinator
// Centralized navigation management using @Observable

@MainActor @Observable
class NavigationCoordinator {
    var path: [AppRoute] = []
    var showSOSOverlay: Bool = false
    
    func navigate(to route: AppRoute) {
        path.append(route)
    }
    
    func pop() {
        if !path.isEmpty {
            path.removeLast()
        }
    }
    
    func popToRoot() {
        path.removeAll()
    }
    
    func toggleSOS() {
        showSOSOverlay.toggle()
        HapticManager.shared.heavy()
    }
}

// MARK: - App Routes
enum AppRoute: Hashable {
    case home
    case actionScenarioList        // NEW: Action-based scenarios
    case actionScenarioPlayer(ActionScenario) // NEW: Gesture-based player

    case sos
    case countrySelector
    case touchSafety
    case touchScenarioPlayer([TouchQuizQuestion], Int)
    case mannersSafety
    case mannerScenarioPlayer(MannerScenario)
    case memoryGallery             // NEW: Memory card collection
    case settings
}
