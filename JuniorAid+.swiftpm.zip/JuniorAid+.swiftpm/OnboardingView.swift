import SwiftUI


struct OnboardingView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    @State private var currentPage = 0
    @State private var showContent = false
    
    var body: some View {
        ZStack {
            
            LinearGradient(
                colors: [AppColors.medical.opacity(0.1), AppColors.safety.opacity(0.1)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: AppSpacing.xxxLarge) {
                Spacer()
                
                
                impactSection
                    .opacity(showContent ? 1 : 0)
                    .offset(y: showContent ? 0 : 30)
                    .animation(reduceMotion ? .none : AppAnimation.springBouncy.delay(0.2), value: showContent)
                
                
                mascotShowcase
                    .opacity(showContent ? 1 : 0)
                    .scaleEffect(showContent ? 1 : 0.8)
                    .animation(reduceMotion ? .none : AppAnimation.springBouncy.delay(0.4), value: showContent)
                
                
                valueProposition
                    .opacity(showContent ? 1 : 0)
                    .offset(y: showContent ? 0 : 20)
                    .animation(reduceMotion ? .none : AppAnimation.spring.delay(0.6), value: showContent)
                
                Spacer()
                
                
                startButton
                    .opacity(showContent ? 1 : 0)
                    .animation(reduceMotion ? .none : AppAnimation.spring.delay(0.8), value: showContent)
            }
            .padding(AppSpacing.large)
        }
        .onAppear {
            showContent = true
        }
    }
    
    private var impactSection: some View {
        VStack(spacing: AppSpacing.small) {
            Text("42,000")
                .font(.system(size: 64, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.medical.gradient)
            
            Text("children are hospitalized from\npreventable accidents each year")
                .font(AppTypography.title3Rounded)
                .foregroundStyle(AppColors.label)
                .multilineTextAlignment(.center)
        }
    }
    
    private var mascotShowcase: some View {
        VStack(spacing: AppSpacing.medium) {
            
            Image("Mascot")
                .resizable()
                .scaledToFit()
                .frame(height: 180)
            
            Text("JuniorAid+")
                .font(AppTypography.largeTitleRounded.weight(.bold))
                .foregroundStyle(AppColors.label)
        }
    }
    
    private var valueProposition: some View {
        VStack(spacing: AppSpacing.small) {
            Text("Teaches life-saving skills")
                .font(AppTypography.title2Rounded.weight(.semibold))
                .foregroundStyle(AppColors.label)
            
            Text("through playful, gesture-based learning")
                .font(AppTypography.body)
                .foregroundStyle(AppColors.secondaryLabel)
                .multilineTextAlignment(.center)
            
            
            HStack(spacing: AppSpacing.small) {
                FeatureBadge(icon: "hand.tap", text: "Interactive")
                FeatureBadge(icon: "speaker.wave.2", text: "Voice Guided")
                FeatureBadge(icon: "wifi.slash", text: "Offline")
            }
            .padding(.top, AppSpacing.medium)
        }
    }
    
    private var startButton: some View {
        Button {
            HapticManager.shared.success()
            dismiss()
        } label: {
            HStack(spacing: AppSpacing.small) {
                Text("Start Learning")
                    .font(AppTypography.headline)
                Image(systemName: "arrow.right")
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(AppColors.medical.gradient, in: RoundedRectangle(cornerRadius: AppCornerRadius.button))
        }
        .buttonStyle(.plain)
    }
}


struct FeatureBadge: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(spacing: AppSpacing.xxSmall) {
            Image(systemName: icon)
                .font(.caption)
            Text(text)
                .font(AppTypography.caption)
        }
        .foregroundStyle(AppColors.secondaryLabel)
        .padding(.horizontal, AppSpacing.small)
        .padding(.vertical, AppSpacing.xxSmall)
        .background(AppColors.cardBackground, in: Capsule())
    }
}

#Preview {
    OnboardingView()
        .environment(NavigationCoordinator())
}
