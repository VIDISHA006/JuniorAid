





import PackageDescription
import AppleProductTypes

let package = Package(
    name: "JuniorAid+",
    platforms: [
        .iOS(.v17)
    ],
    products: [
        .iOSApplication(
            name: "JuniorAid+",
            targets: ["AppModule"],
            bundleIdentifier: "com.junioraid.app",
            displayVersion: "2.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .images),
            accentColor: .presetColor(.indigo),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ],
    swiftLanguageModes: [.version("6")]
)
