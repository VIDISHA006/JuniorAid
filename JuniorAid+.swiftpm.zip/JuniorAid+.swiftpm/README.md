# JuniorAid+ 🚨

**Learn. Stay calm. Be a hero.**

> A gesture-based, offline-first emergency education app for children ages 6-12.  
> **Built for Swift Student Challenge 2026**

---

## 🎯 The Problem

**42,000 children** are hospitalized from preventable accidents each year. When emergencies happen, children are often present but don't know how to help—creating fear instead of confidence.

## 💡 The Solution

JuniorAid+ teaches life-saving skills through **playful, gesture-based learning** that works **100% offline**—exactly when it's needed most.

### ✨ What Makes It Unique

- 🤲 **Learn by Doing**: Press to apply pressure, tap rhythms for CPR timing, swipe to cool burns
- 🔇 **Works Offline**: No internet needed—critical during real emergencies
- 🎨 **Child-First Design**: Animations over text, encouragement over fear
- ♿ **Fully Accessible**: Voice narration, haptics, Dynamic Type, VoiceOver

---

## 📱 Features

| Module | Description | Technical Highlight |
|--------|-------------|---------------------|
| **Emergency Scenarios** | 8 interactive lessons (Bleeding, Burns, Choking, etc.) | Custom gesture recognizers |
| **Practice Drills** | Timer-based muscle memory training | Task-based Swift 6 concurrency |
| **Touch Safety** | Good Touch/Bad Touch education | Emotionally calibrated UI |
| **Emergency Numbers** | Country-specific emergency contacts (Offline) | Local-first data architecture |

---

## 🚀 Quick Start

### Swift Playgrounds (Recommended)
```bash
1. Open JuniorAid+.swiftpm in Swift Playgrounds
2. Tap Run ▶️
3. Experience the onboarding, then try Emergency Scenarios
```

### Xcode
```bash
1. Open JuniorAid+.swiftpm in Xcode 16+
2. Select iPhone/iPad simulator (iOS 17+)
3. Press ⌘R
```

---

## 🏗️ Technical Stack

- **SwiftUI** with iOS 17+ modern APIs (`@Observable`, `sensoryFeedback()`)
- **Gesture Recognition** for tactile learning (DragGesture, LongPressGesture)
- **AVSpeechSynthesizer** for accessible voice narration
- **Haptic Engine** for sensory feedback
- **100% Offline** architecture (no network dependencies)
- **Apple HIG** compliant design system
- **Swift 6** strict concurrency

---

## 🎓 Educational Philosophy

**JuniorAid+ doesn't teach with textbooks—it teaches through action.**

Children learn by:
1. **Seeing** → Animations show what to do
2. **Choosing** → Interactive decision-making
3. **Doing** → Gesture-based practice creates muscle memory
4. **Repeating** → Calm retry system builds confidence

This creates **embodied learning**—kids don't just know what to do, they *feel* prepared.

---

## 🏆 Swift Student Challenge 2026

### Why This App Stands Out

1. **Social Impact**: Addresses real child safety crisis
2. **Technical Innovation**: Gesture-based learning (unique approach)
3. **Quality & Polish**: Apple HIG compliance, accessibility-first
4. **Offline-First**: Works when connectivity fails (true reliability)

### Key Metrics
- **37 Swift files**, ~4,000+ lines of code
- **8 emergency scenarios** with branching logic
- **4 practice drills** with timer/haptic integration
- **100% offline** functionality
- **Fully accessible** (VoiceOver, Dynamic Type, Reduce Motion)

---

## 📂 Project Structure

```
JuniorAid+.swiftpm/
├── OnboardingView.swift          # Impactful intro for judges
├── HomeView.swift                # Redesigned for clarity
├── DesignSystem.swift            # HIG-compliant tokens
├── Components.swift              # Reusable HIG components
├── GestureInteractions.swift     # Custom gesture library
├── ActionScenarioContent.swift   # Gesture-based scenarios
├── ScenarioContent.swift         # Quiz-based scenarios
├── EmergencyData.swift           # Offline emergency numbers
├── Models/                       # Data structures
└── ... (27 more files)
```

---

## 🎨 Design Decisions

- **Minimal yet Friendly**: Clean HIG design with warmth
- **Animation-Driven**: Smooth 60fps interactions
- **Semantic Colors**: WCAG AA contrast guaranteed
- **SF Symbols**: Hierarchical rendering for depth
- **No Fear, Only Confidence**: Positive reinforcement system

---

## 📚 Documentation

- [SSC Optimization Plan](file:///.gemini/antigravity/brain/5b36219c-cc33-409e-9503-57f6d26dddf4/ssc_optimization_plan.md) - Strategy for 3-minute judging
- [Walkthrough](file:///.gemini/antigravity/brain/5b36219c-cc33-409e-9503-57f6d26dddf4/walkthrough.md) - Feature details

---

## 💭 Core Belief

> **"If a child uses this app, they will feel calmer and safer in real emergencies."**

---

**Built with SwiftUI, care, and a commitment to child safety.** ✨

*Swift Student Challenge 2026 Submission*
