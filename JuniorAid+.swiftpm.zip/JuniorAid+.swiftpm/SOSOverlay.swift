import SwiftUI

// MARK: - SOS Overlay
// Always-accessible floating SOS button

struct SOSOverlay: View {
    @Environment(NavigationCoordinator.self) private var navigator
    
    @State private var isPulsing = false
    @State private var position: CGPoint = CGPoint(x: UIScreen.main.bounds.width - 80, y: 100)
    @State private var dragOffset: CGSize = .zero
    
    var body: some View {
        ZStack( alignment: .topTrailing) {
            // Floating SOS button
            floatingSOSButton
                .position(x: position.x + dragOffset.width, y: position.y + dragOffset.height)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            dragOffset = value.translation
                        }
                        .onEnded { value in
                            // Update position
                            position.x += value.translation.width
                            position.y += value.translation.height
                            
                            // Keep button on screen
                            position.x = max(40, min(UIScreen.main.bounds.width - 40, position.x))
                            position.y = max(60, min(UIScreen.main.bounds.height - 60, position.y))
                            
                            dragOffset = .zero
                        }
                )
        }
        .allowsHitTesting(true)
    }
    
    private var floatingSOSButton: some View {
        Button {
            navigator.navigate(to: .sos)
            HapticManager.shared.heavy()
        } label: {
            ZStack {
                // Pulsing glow
                Circle()
                    .fill(JuniorAidColors.sosGlow)
                    .frame(width: 70, height: 70)
                    .scaleEffect(isPulsing ? 1.3 : 1.0)
                    .opacity(isPulsing ? 0 : 0.6)
                
                // Main button
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                JuniorAidColors.sosRed,
                                JuniorAidColors.sosRed.opacity(0.8)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 60, height: 60)
                    .overlay(
                        Circle()
                            .stroke(Color.white, lineWidth: 3)
                    )
                    .juniorAidShadow(Shadows.strong)
                
                // SOS text
                Text("SOS")
                    .font(JuniorAidFont.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
        }
        .buttonStyle(PlainButtonStyle())
        .onAppear {
            withAnimation(
                .easeInOut(duration: 1.5)
                .repeatForever(autoreverses: false)
            ) {
                isPulsing = true
            }
        }
    }
}

#Preview {
    ZStack {
        Color.gray.opacity(0.1)
            .ignoresSafeArea()
        
        SOSOverlay()
            .environment(NavigationCoordinator())
    }
}
