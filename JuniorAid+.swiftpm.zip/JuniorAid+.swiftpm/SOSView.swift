import SwiftUI




struct SOSView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    @Environment(AccessibilitySettings.self) private var accessibility
    
    @State private var pulseAnimation = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: AppSpacing.xLarge) {
                
                sosHeader
                    .padding(.top, AppSpacing.xxLarge)
                
                
                emergencyCallCard
                    .padding(.horizontal, AppSpacing.edgePadding)
                
                
                VStack(spacing: AppSpacing.medium) {
                    guidanceCard
                    reassuranceCard
                }
                .padding(.horizontal, AppSpacing.edgePadding)
                .padding(.bottom, AppSpacing.xxxLarge)
            }
        }
        .background(AppColors.background.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            pulseAnimation = true
            if accessibility.voiceNarrationEnabled {
                narrator.speak("Emergency help. Stay calm. We're here to help you.")
            }
        }
    }
    
    
    
    private var sosHeader: some View {
        VStack(spacing: AppSpacing.medium) {
            
            ZStack {
                Circle()
                    .stroke(AppColors.medical.opacity(0.2), lineWidth: 2)
                    .frame(width: 140, height: 140)
                    .scaleEffect(pulseAnimation ? 1.2 : 0.8)
                    .opacity(pulseAnimation ? 0 : 0.5)
                    .animation(
                        .easeInOut(duration: 2).repeatForever(autoreverses: false),
                        value: pulseAnimation
                    )
                
                Circle()
                    .stroke(AppColors.medical.opacity(0.1), lineWidth: 2)
                    .frame(width: 180, height: 180)
                    .scaleEffect(pulseAnimation ? 1.2 : 0.8)
                    .opacity(pulseAnimation ? 0 : 0.4)
                    .animation(
                        .easeInOut(duration: 2).repeatForever(autoreverses: false).delay(0.5),
                        value: pulseAnimation
                    )
                
                
                Image(systemName: "cross.case.fill")
                    .font(.system(size: 70))
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(AppColors.medical.gradient)
                    .background(
                        Circle()
                            .fill(AppColors.cardBackground)
                            .frame(width: 110, height: 110)
                            .shadow(color: AppColors.medical.opacity(0.2), radius: 10, y: 5)
                    )
            }
            .padding(.bottom, AppSpacing.small)
            
            VStack(spacing: 8) {
                Text("Emergency Help")
                    .font(AppTypography.title.weight(.bold))
                    .foregroundStyle(AppColors.label)
                
                Text("Stay calm. You're doing great.")
                    .font(AppTypography.body)
                    .foregroundStyle(AppColors.secondaryLabel)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    private var emergencyCallCard: some View {
        Button {
            HapticManager.shared.heavy()
            navigator.navigate(to: .countrySelector)
        } label: {
            HStack(spacing: AppSpacing.medium) {
                Image(systemName: "phone.fill")
                    .font(.system(size: 36))
                    .foregroundStyle(.white)
                    .frame(width: 64, height: 64)
                    .background(Color.white.opacity(0.2))
                    .clipShape(Circle())
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Call for Help")
                        .font(AppTypography.title2Rounded.weight(.bold))
                        .foregroundStyle(.white)
                    
                    Text("View Emergency Numbers")
                        .font(AppTypography.body)
                        .foregroundStyle(.white.opacity(0.9))
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.title3.bold())
                    .foregroundStyle(.white.opacity(0.7))
            }
            .padding(AppSpacing.large)
            .background {
                RoundedRectangle(cornerRadius: AppCornerRadius.large)
                    .fill(AppColors.medical.gradient)
                    .shadow(color: AppColors.medical.opacity(0.4), radius: 10, y: 5)
            }
        }
        .buttonStyle(ScaleButtonStyle())
    }
    
    private var guidanceCard: some View {
        VStack(alignment: .leading, spacing: AppSpacing.medium) {
            Label("What to Say", systemImage: "bubble.left.fill")
                .font(AppTypography.headline)
                .foregroundStyle(AppColors.label)
            
            VStack(alignment: .leading, spacing: 12) {
                guidanceItem("My name is...", icon: "person.fill", color: .blue)
                guidanceItem("I am at...", icon: "location.fill", color: .green)
                guidanceItem("The emergency is...", icon: "exclamationmark.triangle.fill", color: .orange)
            }
        }
        .padding(AppSpacing.large)
        .background(AppColors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppCornerRadius.medium))
        .shadow(color: Color.black.opacity(0.05), radius: 5, y: 2)
    }
    
    private func guidanceItem(_ text: String, icon: String, color: Color) -> some View {
        HStack(spacing: AppSpacing.small) {
            Image(systemName: icon)
                .font(.body)
                .foregroundStyle(color)
                .frame(width: 24)
            
            Text(text)
                .font(AppTypography.body)
                .foregroundStyle(AppColors.secondaryLabel)
            
            Spacer()
        }
        .padding(AppSpacing.small)
        .background(AppColors.tertiaryBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppCornerRadius.small))
    }
    
    private var reassuranceCard: some View {
        HStack(spacing: AppSpacing.medium) {
            Image(systemName: "heart.fill")
                .font(.title2)
                .foregroundStyle(AppColors.accent)
            
            Text("You are brave. Adults are on their way to keep you safe.")
                .font(AppTypography.subheadline)
                .foregroundStyle(AppColors.secondaryLabel)
                .fixedSize(horizontal: false, vertical: true)
                .lineLimit(nil)
            
            Spacer()
        }
        .padding(AppSpacing.medium)
        .background(AppColors.accent.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: AppCornerRadius.medium))
        .overlay(
            RoundedRectangle(cornerRadius: AppCornerRadius.medium)
                .strokeBorder(AppColors.accent.opacity(0.3), lineWidth: 1)
        )
    }
}

#Preview {
    NavigationStack {
        SOSView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
            .environment(AccessibilitySettings())
    }
}
