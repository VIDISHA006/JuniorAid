import SwiftUI




struct ScenarioAnimationView: View {
    let type: ScenarioAnimationType
    let color: Color
    
    var body: some View {
        ZStack {
            
            
            switch type {
            case .pressing:
                PressingAnimation(color: color)
            case .swiping(let direction):
                SwipingAnimation(direction: direction, color: color)
            case .leaningForward:
                LeaningForwardAnimation(color: color)
            case .pinching:
                PinchingAnimation(color: color)
            case .waterFlowing:
                WaterFlowingAnimation()
            case .crawling:
                CrawlingAnimation(color: color)
            case .phoneCall:
                PhoneCallAnimation(color: color)
            case .rubbing:
                RubbingAnimation(color: color)
            case .tapping:
                TappingAnimation(color: color)
            case .scraping:
                ScrapingAnimation(color: color)
            case .stabilizing:
                StabilizingAnimation()
            case .iceApplication:
                IceApplicationAnimation()
            case .kneeling:
                KneelingAnimation(color: color)
            case .backBlows:
                BackBlowsAnimation(color: color)
            case .bleedingHand:
                BleedingHandAnimation()
            case .cleanCloth:
                CleanClothAnimation()
            case .bleedingHandPress:
                BleedingHandPressAnimation()
            case .cleanCutHand:
                CleanCutHandAnimation()
            case .burnCooling:
                BurnCoolingAnimation()
            case .waterHandBurn:
                WaterHandBurnAnimation()
            case .handClothWrapped:
                HandClothWrappedAnimation()
            case .fireRoom1:
                FireRoom1Animation()
            case .fireRoom2:
                FireRoom2Animation()
            case .pressingNose:
                PressingNoseAnimation()
            case .beeSting1:
                BeeSting1Animation()
            case .beeSting2:
                BeeSting2Animation()
            case .dogBiteWash:
                DogBiteWashAnimation()
            case .dogBiteDry:
                DogBiteDryAnimation()
            case .dogBiteWrap:
                DogBiteWrapAnimation()
            case .none:
                EmptyView()
            }
        }
        .frame(height: 180)
        .clipped()
    }
}


struct PressingAnimation: View {
    let color: Color
    @State private var isPressed = false
    
    var body: some View {
        Image(systemName: "hand.point.down.fill")
            .font(.system(size: 80))
            .foregroundColor(color)
            .rotation3DEffect(
                .degrees(isPressed ? 10 : -10),
                axis: (x: 1, y: 0, z: 0)
            )
            .scaleEffect(isPressed ? 0.9 : 1.1)
            .offset(y: isPressed ? 10 : -20)
            .shadow(color: color.opacity(0.3), radius: isPressed ? 5 : 15, y: isPressed ? 5 : 20)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) {
                    isPressed = true
                }
            }
    }
}


struct SwipingAnimation: View {
    let direction: SwipeDirection
    let color: Color
    @State private var offset: CGFloat = -40
    
    var body: some View {
        Image(systemName: "hand.point.up.fill")
            .font(.system(size: 70))
            .foregroundColor(color)
            .rotation3DEffect(
                .degrees(20),
                axis: (x: 0, y: 1, z: 0)
            )
            .offset(
                x: direction == .right ? offset : (direction == .left ? -offset : 0),
                y: direction == .down ? offset : (direction == .up ? -offset : 0)
            )
            .onAppear {
                withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: false)) {
                    offset = 40
                }
            }
    }
}


struct LeaningForwardAnimation: View {
    let color: Color
    @State private var isLeaning = false
    
    var body: some View {
        VStack(spacing: -10) {
            
            ZStack {
                Circle()
                    .fill(color)
                    .frame(width: 50, height: 50)
                
                
                HStack(spacing: 8) {
                    Circle()
                        .fill(.white)
                        .frame(width: 8, height: 8)
                    Circle()
                        .fill(.white)
                        .frame(width: 8, height: 8)
                }
                .offset(y: -5)
            }
            .offset(y: isLeaning ? 10 : 0)
            .scaleEffect(isLeaning ? 1.1 : 1.0) 
            
            
            RoundedRectangle(cornerRadius: 15)
                .fill(color.opacity(0.7))
                .frame(width: 60, height: 80)
                .rotation3DEffect(
                    .degrees(isLeaning ? 30 : 0),
                    axis: (x: 1, y: 0, z: 0),
                    anchor: .bottom
                )
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                isLeaning = true
            }
        }
    }
}


struct PinchingAnimation: View {
    let color: Color
    @State private var isPinching = false
    
    var body: some View {
        HStack(spacing: isPinching ? 5 : 40) {
            Image(systemName: "hand.point.right.fill")
                .rotationEffect(.degrees(45))
            Image(systemName: "hand.point.left.fill")
                .rotationEffect(.degrees(-45))
        }
        .font(.system(size: 60))
        .foregroundColor(color)
        .rotation3DEffect(
            .degrees(20),
            axis: (x: 1, y: 0, z: 0)
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                isPinching = true
            }
        }
    }
}


struct WaterFlowingAnimation: View {
    @State private var isFlowing = false
    
    var body: some View {
        ZStack {
            ForEach(0..<5) { index in
                Image(systemName: "drop.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.blue.opacity(0.6))
                    .offset(y: isFlowing ? 100 : -100)
                    .scaleEffect(isFlowing ? 0.5 : 1.0)
                    .animation(
                        .linear(duration: 1.5)
                        .repeatForever(autoreverses: false)
                        .delay(Double(index) * 0.3),
                        value: isFlowing
                    )
            }
        }
        .frame(height: 150)
        .mask(Rectangle())
        .onAppear {
            isFlowing = true
        }
    }
}


struct CrawlingAnimation: View {
    let color: Color
    @State private var offset: CGFloat = 50
    
    var body: some View {
        Image(systemName: "figure.crawl")
            .font(.system(size: 80))
            .foregroundColor(color)
            .rotation3DEffect(
                .degrees(10),
                axis: (x: 0, y: 1, z: 0)
            )
            .offset(x: offset)
            .onAppear {
                withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
                    offset = -50
                }
            }
    }
}


struct PhoneCallAnimation: View {
    let color: Color
    @State private var isRinging = false
    
    var body: some View {
        ZStack {
            
            Circle()
                .fill(color.opacity(0.2))
                .frame(width: 120, height: 120)
                .scaleEffect(isRinging ? 1.2 : 0.8)
                .opacity(isRinging ? 0.0 : 0.5)
            
            
            Image(systemName: "phone.circle.fill")
                .font(.system(size: 90))
                .foregroundColor(color)
                .rotationEffect(.degrees(isRinging ? 15 : -15))
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                isRinging = true
            }
        }
    }
}


struct RubbingAnimation: View {
    let color: Color
    @State private var rotation: Double = 0
    
    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(0.3))
                .frame(width: 100, height: 100)
            
            Image(systemName: "hand.raised.fill")
                .font(.system(size: 60))
                .foregroundColor(color)
                .rotationEffect(.degrees(rotation))
                .offset(x: 10, y: 10)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                rotation = 30
            }
        }
    }
}


struct TappingAnimation: View {
    let color: Color
    @State private var isTapped = false
    
    var body: some View {
        Image(systemName: "hand.point.up.left.fill")
            .font(.system(size: 80))
            .foregroundColor(color)
            .offset(y: isTapped ? 10 : -20)
            .rotation3DEffect(
                .degrees(isTapped ? -20 : 0),
                axis: (x: 1, y: 0, z: 0)
            )
            .onAppear {
                withAnimation(.easeInOut(duration: 0.4).repeatForever(autoreverses: true)) {
                    isTapped = true
                }
            }
    }
}


struct ScrapingAnimation: View {
    let color: Color
    @State private var offset: CGFloat = -30
    
    var body: some View {
        ZStack {
            
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.orange.opacity(0.2))
                .frame(width: 150, height: 80)
            
            
            RoundedRectangle(cornerRadius: 4)
                .fill(color)
                .frame(width: 10, height: 60)
                .rotationEffect(.degrees(20))
                .offset(x: offset)
                .rotation3DEffect(
                    .degrees(10),
                    axis: (x: 0, y: 1, z: 0)
                )
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: false)) {
                offset = 30
            }
        }
    }
}


struct StabilizingAnimation: View {
    var body: some View {
        Image("hand_bone")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct IceApplicationAnimation: View {
    @State private var isApplied = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.blue.opacity(0.4))
                .frame(width: 80, height: 80)
                .overlay {
                    Image(systemName: "snowflake")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                }
                .rotation3DEffect(
                    .degrees(isApplied ? 0 : 360),
                    axis: (x: 1, y: 1, z: 0)
                )
                .offset(y: isApplied ? 0 : -50)
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6).repeatForever(autoreverses: true)) {
                isApplied = true
            }
        }
    }
}


struct KneelingAnimation: View {
    let color: Color
    @State private var isKneeling = false
    
    var body: some View {
        VStack(spacing: -5) {
            
            ZStack {
                Circle()
                    .fill(color)
                    .frame(width: 50, height: 50)
                
                
                HStack(spacing: 8) {
                    Circle()
                        .fill(.white)
                        .frame(width: 8, height: 8)
                    Circle()
                        .fill(.white)
                        .frame(width: 8, height: 8)
                }
                .offset(y: -5)
            }
            .offset(y: isKneeling ? 20 : 0)
            
            
            RoundedRectangle(cornerRadius: 15)
                .fill(color.opacity(0.7))
                .frame(width: 60, height: 80)
                .rotation3DEffect(
                    .degrees(isKneeling ? 45 : 0),
                    axis: (x: 1, y: 0, z: 0),
                    anchor: .bottom
                )
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                isKneeling = true
            }
        }
    }
}


struct BackBlowsAnimation: View {
    let color: Color
    var body: some View {
        Image("choking_image")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5)
    }
}



struct BleedingHandAnimation: View {
    var body: some View {
        Image("bleeding_hand_wound")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}



struct CleanClothAnimation: View {
    var body: some View {
        Image("clean_cloth_tool")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct BleedingHandPressAnimation: View {
    var body: some View {
        Image("bleeding_hand_wound")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct CleanCutHandAnimation: View {
    var body: some View {
        Image("clean_cut_hand")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct BurnCoolingAnimation: View {
    var body: some View {
        Image("burn_hand")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct WaterHandBurnAnimation: View {
    var body: some View {
        Image("water_hand_burn")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct HandClothWrappedAnimation: View {
    var body: some View {
        Image("hand_cloth_wrapped")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}

struct FireRoom1Animation: View {
    var body: some View {
        Image("fire_room1")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct FireRoom2Animation: View {
    var body: some View {
        Image("fire_room2")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}

struct PressingNoseAnimation: View {
    var body: some View {
        Image("pressing_nose")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}

struct BeeSting1Animation: View {
    var body: some View {
        Image("bee_sting1")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct BeeSting2Animation: View {
    var body: some View {
        Image("bee_sting2")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct DogBiteWashAnimation: View {
    var body: some View {
        Image("dog_bite_hand")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct DogBiteDryAnimation: View {
    var body: some View {
        Image("water_dog_bite_hand")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}


struct DogBiteWrapAnimation: View {
    var body: some View {
        Image("hand_cloth_wrapped")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(0)
            .scaleEffect(1.5) 
    }
}
