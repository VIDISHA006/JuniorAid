import SwiftUI

struct SplashScreenView: View {
    @State private var isActive = false
    @State private var pulse = false
    
    var body: some View {
        ZStack {
            AppColors.background
                .ignoresSafeArea()
            
            // Logo Image - Centered and Large
            Image("Logo")
                .resizable()
                .scaledToFit()
                .frame(width: 350, height: 350) // Increased size
                .clipShape(Circle())
                .scaleEffect(isActive ? 1.0 : 0.5)
                .scaleEffect(pulse ? 1.05 : 1.0)
                .rotationEffect(.degrees(isActive ? 0 : -10)) // Slight rotation entrance
                .opacity(isActive ? 1.0 : 0.0)
                .animation(.bouncy(duration: 0.8, extraBounce: 0.2), value: isActive)
                .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
        }
        .onAppear {
            isActive = true
            // Start pulsing after initial entrance
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                pulse = true
            }
        }
    }
}

#Preview {
    SplashScreenView()
}
