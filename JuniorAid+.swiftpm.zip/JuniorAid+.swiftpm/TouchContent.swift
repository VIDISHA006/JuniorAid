import SwiftUI

// MARK: - Touch Safety Content

class TouchContent {
    static let quizQuestions: [TouchQuizQuestion] = [
        TouchQuizQuestion(
            scenario: "A parent gives you a hug",
            visualCue: "heart.fill",
            correctCategory: .safe,
            explanation: "Hugs from family who love you are safe touches that make you feel warm and happy.",
            encouragement: "You're right! This is a safe, loving touch."
        ),
        TouchQuizQuestion(
            scenario: "A doctor checks your heartbeat with your parent there",
            visualCue: "stethoscope",
            correctCategory: .safe,
            explanation: "Doctors sometimes need to check your body to keep you healthy. It's safe when a parent is there.",
            encouragement: "Correct! This is safe when a trusted adult is with you."
        ),
        TouchQuizQuestion(
            scenario: "Someone touches you in a way that feels uncomfortable or wrong",
            visualCue: "hand.raised.fill",
            correctCategory: .unsafe,
            explanation: "If any touch makes you feel bad, scared, or uncomfortable, it's NOT okay. Tell a trusted adult right away.",
            encouragement: "Exactly right. Always tell a trusted adult about uncomfortable touches."
        ),
        TouchQuizQuestion(
            scenario: "A stranger asks you to keep a touch secret",
            visualCue: "exclamationmark.shield.fill",
            correctCategory: .unsafe,
            explanation: "Safe touches are never secrets. If someone asks you to keep a touch secret, that's NOT safe. Tell a trusted adult.",
            encouragement: "Perfect! Safe touches are never secrets."
        ),
        TouchQuizQuestion(
            scenario: "Someone touches you and you're not sure if it's okay",
            visualCue: "questionmark.circle.fill",
            correctCategory: .confusing,
            explanation: "If you're ever not sure, always talk to a trusted adult. They can help you understand.",
            encouragement: "Great choice! When you're not sure, always ask a trusted adult."
        )
    ]
}
