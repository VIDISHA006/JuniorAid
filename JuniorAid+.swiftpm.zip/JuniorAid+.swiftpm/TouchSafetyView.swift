import SwiftUI



struct TouchSafetyView: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    
    var body: some View {
        ZStack {
           JuniorAidColors.backgroundGradient
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: Spacing.xLarge) {
                    header
                        .padding(.top, Spacing.large)
                    
                    categoriesExplainer
                    
                    startQuizButton
                }
                .padding(Spacing.large)
            }
        }
        .onAppear {
            narrator.speak("Let's learn about safe and unsafe touch")
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    navigator.pop()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    private var header: some View {
        VStack(spacing: Spacing.small) {
            Image(systemName: "hand.raised.fill")
                .font(.system(size: 60))
                .foregroundColor(JuniorAidColors.safeTouchColor)
            
            Text("Good Touch / Bad Touch")
                .font(JuniorAidFont.title)
                .foregroundColor(JuniorAidColors.primaryText)
            
            Text("Learn to recognize safe and unsafe touches")
                .font(JuniorAidFont.body)
                .foregroundColor(JuniorAidColors.secondaryText)
                .multilineTextAlignment(.center)
        }
    }
    
    private var categoriesExplainer: some View {
        VStack(spacing: Spacing.medium) {
            categoryCard(.safe)
            categoryCard(.unsafe)
            categoryCard(.confusing)
        }
    }
    
    private func categoryCard(_ category: TouchCategory) -> some View {
        LiquidGlassCard {
            HStack(spacing: Spacing.medium) {
                Image(systemName: category.icon)
                    .font(.system(size: 40))
                    .foregroundColor(category.color)
                
                VStack(alignment: .leading, spacing: Spacing.xSmall) {
                    Text(category.rawValue)
                        .font(JuniorAidFont.headline)
                        .foregroundColor(JuniorAidColors.primaryText)
                    
                    Text(category.guidance)
                        .font(JuniorAidFont.body)
                        .foregroundColor(JuniorAidColors.secondaryText)
                }
                
                Spacer()
            }
        }
    }
    
    private var startQuizButton: some View {
        LiquidGlassButton(
            title: "Start Learning",
            icon: "play.fill",
            color: JuniorAidColors.safeTouchColor
        ) {
            navigator.navigate(to: .touchScenarioPlayer(TouchContent.quizQuestions, 0))
            narrator.speak("Let's practice together")
        }
    }
}

#Preview {
    NavigationStack {
        TouchSafetyView()
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
    }
}
