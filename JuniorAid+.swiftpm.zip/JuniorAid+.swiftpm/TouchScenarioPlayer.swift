import SwiftUI

// MARK: - Touch Scenario Player

struct TouchScenarioPlayer: View {
    @Environment(NavigationCoordinator.self) private var navigator
    @Environment(VoiceNarrator.self) private var narrator
    
    let questions: [TouchQuizQuestion]
    @State private var currentIndex: Int
    @State private var selectedCategory: TouchCategory?
    @State private var showFeedback = false
    @State private var showCelebration = false
    
    init(questions: [TouchQuizQuestion], currentIndex: Int) {
        self.questions = questions
        self._currentIndex = State(initialValue: currentIndex)
    }
    
    private var currentQuestion: TouchQuizQuestion {
        questions[currentIndex]
    }
    
    private var isLastQuestion: Bool {
        currentIndex == questions.count - 1
    }
    
    var body: some View {
        ZStack {
            JuniorAidColors.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                progressIndicator
                    .padding(.top, Spacing.medium)
                    .padding(.bottom, Spacing.large)
                
                ScrollView {
                    VStack(spacing: Spacing.xxLarge) {
                        // Title Heading
                        Text("Touch Safety Drill")
                            .font(JuniorAidFont.title.bold())
                            .foregroundColor(JuniorAidColors.primaryText)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .padding(.top, Spacing.xxxSmall)
                        
                        visualCue
                        
                        VStack(spacing: Spacing.large) {
                            scenarioCard
                            
                            if !showFeedback {
                                categoriesButtons
                            }
                            
                            if showFeedback {
                                feedbackSection
                            }
                        }
                    }
                    .padding(.horizontal, Spacing.large)
                    .padding(.bottom, Spacing.xxLarge)
                }
            }
            
            if showCelebration {
                CelebrationAnimation()
            }
        }
        .onAppear {
            narrator.speak(currentQuestion.scenario)
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    narrator.stop() // Added narrator stop
                    navigator.pop()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "chevron.left")
                        Text("Back")
                            .font(JuniorAidFont.body)
                    }
                    .foregroundColor(JuniorAidColors.primaryText)
                }
            }
        }
    }
    
    private var progressIndicator: some View {
        HStack(spacing: Spacing.xSmall) {
            ForEach(0..<questions.count, id: \.self) { index in
                Capsule()
                    .fill(index <= currentIndex ?
                          JuniorAidColors.safeTouchColor : JuniorAidColors.safeTouchColor.opacity(0.3))
                    .frame(height: 6)
                    .frame(maxWidth: .infinity)
            }
        }
        .padding(.horizontal, Spacing.large)
    }
    
    private var visualCue: some View {
        Image(systemName: currentQuestion.visualCue)
            .font(.system(size: 80))
            .foregroundColor(JuniorAidColors.secondaryText)
            .padding(Spacing.xLarge)
    }
    
    private var scenarioCard: some View {
        LiquidGlassCard {
            Text(currentQuestion.scenario)
                .font(JuniorAidFont.title2)
                .foregroundColor(JuniorAidColors.primaryText)
                .multilineTextAlignment(.center)
        }
    }
    
    private var categoriesButtons: some View {
        VStack(spacing: Spacing.medium) {
            Text("How does this feel?")
                .font(JuniorAidFont.headline)
                .foregroundColor(JuniorAidColors.secondaryText)
            
            ForEach(TouchCategory.allCases, id: \.self) { category in
                categoryButton(category)
            }
        }
    }
    
    private func categoryButton(_ category: TouchCategory) -> some View {
        Button {
            handleSelection(category)
        } label: {
            HStack {
                Image(systemName: category.icon)
                    .font(.system(size: 32))
                
                Text(category.rawValue)
                    .font(JuniorAidFont.bodyLarge)
                
                Spacer()
            }
            .foregroundColor(JuniorAidColors.primaryText)
            .padding(Spacing.large)
            .background(
                RoundedRectangle(cornerRadius: CornerRadius.medium)
                    .fill(category.color.opacity(0.4))
                    .overlay(
                        RoundedRectangle(cornerRadius: CornerRadius.medium)
                            .stroke(category.color, lineWidth: 2)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private var feedbackSection: some View {
        LiquidGlassCard {
            VStack(spacing: Spacing.large) {
                Image(systemName: selectedCategory == currentQuestion.correctCategory ?
                      "checkmark.circle.fill" : "lightbulb.fill")
                    .font(.system(size: 60))
                    .foregroundColor(selectedCategory == currentQuestion.correctCategory ?
                                    JuniorAidColors.successGreen : JuniorAidColors.encouragementYellow)
                
                Text(selectedCategory == currentQuestion.correctCategory ?
                     currentQuestion.encouragement : currentQuestion.explanation)
                    .font(JuniorAidFont.bodyLarge)
                    .foregroundColor(JuniorAidColors.primaryText)
                    .multilineTextAlignment(.center)
                
                Button {
                    if isLastQuestion {
                        showCelebration = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            navigator.pop()
                        }
                    } else {
                        moveToNext()
                    }
                } label: {
                    Text(isLastQuestion ? "Complete!" : "Continue")
                        .font(JuniorAidFont.buttonMedium)
                        .foregroundColor(.white)
                        .padding(.horizontal, Spacing.xLarge)
                        .padding(.vertical, Spacing.medium)
                        .background(
                            Capsule()
                                .fill(JuniorAidColors.successGreen)
                        )
                }
            }
        }
    }
    
    private func handleSelection(_ category: TouchCategory) {
        selectedCategory = category
        
        if category == currentQuestion.correctCategory {
            HapticManager.shared.success()
            narrator.speak(currentQuestion.encouragement)
        } else {
            HapticManager.shared.warning()
            narrator.speak(currentQuestion.explanation)
        }
        
        withAnimation(SpringAnimations.gentle.delay(0.3)) {
            showFeedback = true
        }
    }
    
    private func moveToNext() {
        withAnimation(SpringAnimations.gentle) {
            currentIndex += 1
            showFeedback = false
            selectedCategory = nil
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            narrator.speak(currentQuestion.scenario)
        }
    }
}

#Preview {
    NavigationStack {
        TouchScenarioPlayer(questions: TouchContent.quizQuestions, currentIndex: 0)
            .environment(NavigationCoordinator())
            .environment(VoiceNarrator())
    }
}
