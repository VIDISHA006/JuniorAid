import SwiftUI
import AVFoundation

// MARK: - Voice Narrator
// Text-to-speech system for accessibility and guidance
// Thread-safe with @MainActor for Swift 6 strict concurrency

@Observable
@MainActor
class VoiceNarrator {
    private let synthesizer = AVSpeechSynthesizer()
    var isEnabled: Bool = true
    var speechRate: Float = 0.5  // Calm, moderate pace
    var isSpeaking: Bool = false
    
    func speak(_ text: String) {
        // Only speak if voice narration is enabled
        guard isEnabled else {
            return
        }
        
        // Stop any current speech
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = speechRate
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.pitchMultiplier = 1.0
        utterance.volume = 1.0
        
        isSpeaking = true
        synthesizer.speak(utterance)
        
        // Use Task for safe async update on MainActor
        let estimatedDuration = Double(text.count) * 0.05
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(estimatedDuration))
            self.isSpeaking = false
        }
    }
    
    func stop() {
        synthesizer.stopSpeaking(at: .immediate)
        isSpeaking = false
    }
    
    func pause() {
        synthesizer.pauseSpeaking(at: .word)
    }
    
    func resume() {
        synthesizer.continueSpeaking()
    }
    
    func setRate(_ rate: Float) {
        speechRate = max(0.3, min(0.7, rate))  // Keep it calm
    }
}
